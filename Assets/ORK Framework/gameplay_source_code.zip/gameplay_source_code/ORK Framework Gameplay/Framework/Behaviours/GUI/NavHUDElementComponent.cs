
using UnityEngine;
using UnityEngine.UI;
using ORKFramework;
using ORKFramework.UI;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class NavHUDElementComponent : MonoBehaviour
	{
		private RectTransform rectTransform;

		private GameObject contentObject;

		private NavigationHUDContent content;

		private HUDNavigation setting;

		public float degreePosition = 0;

		private bool isVisible = true;

		public void Init(RectTransform rectTransform, GameObject contentObject,
			NavigationHUDContent content, HUDNavigation setting, float degreePosition)
		{
			this.rectTransform = rectTransform;
			this.contentObject = contentObject;
			this.content = content;
			this.setting = setting;
			this.degreePosition = degreePosition;
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		void Update()
		{
			// position
			float position = this.degreePosition - this.content.ForwardAngle;
			ValueHelper.SecureRotation2(ref position);
			this.rectTransform.anchoredPosition = new Vector2(
				position * this.content.OneDegreeWidth + this.content.HalfWidth,
				this.rectTransform.anchoredPosition.y);

			// degree visibility
			if(this.isVisible)
			{
				if((this.degreePosition >= this.content.LeftEnd && this.degreePosition <= this.content.RightEnd) ||
					(this.degreePosition + 360 >= this.content.LeftEnd && this.degreePosition + 360 <= this.content.RightEnd) ||
					(this.degreePosition - 360 >= this.content.LeftEnd && this.degreePosition - 360 <= this.content.RightEnd))
				{
					if(!this.contentObject.activeInHierarchy)
					{
						this.contentObject.SetActive(true);
					}
				}
				else if(this.contentObject.activeInHierarchy)
				{
					this.contentObject.SetActive(false);
				}
			}
		}

		public bool IsVisible
		{
			get { return this.isVisible; }
			set
			{
				if(this.isVisible != value)
				{
					this.isVisible = value;
					this.contentObject.SetActive(this.isVisible);
				}
			}
		}
	}
}
