﻿
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using System.Collections.Generic;

namespace ORKFramework
{
	public class UIClickComponent : MonoBehaviour, IPointerClickHandler
	{
		public Notify onLeftClick;

		public Notify onMiddleClick;

		public Notify onRightClick;

		public void OnPointerClick(PointerEventData eventData)
		{
			if(PointerEventData.InputButton.Left == eventData.button)
			{
				if(this.onLeftClick != null)
				{
					this.onLeftClick();
				}
			}
			else if(PointerEventData.InputButton.Middle == eventData.button)
			{
				if(this.onMiddleClick != null)
				{
					this.onMiddleClick();
				}
			}
			else if(PointerEventData.InputButton.Right == eventData.button)
			{
				if(this.onRightClick != null)
				{
					this.onRightClick();
				}
			}
		}
	}
}
