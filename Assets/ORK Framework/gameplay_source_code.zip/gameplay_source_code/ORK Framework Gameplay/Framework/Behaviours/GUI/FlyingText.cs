
using UnityEngine;
using UnityEngine.UI;
using ORKFramework;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class FlyingText : MonoBehaviour, IEventStarter
	{
		private FlyingTextSettings settings;

		private GameObject targetObject;

		private Vector3 screenPosition;


		// move
		private MoveEvent moveEvent;


		// color for fading
		private Color color = new Color(1, 1, 1, 1);


		// text
		private string text;

		private TextFormat textFormat;

		private Color textColor;

		private Color shadowColor;


		// count to value
		private string valueFormat = "0";

		private bool counting = false;

		private int value = 0;

		private int currentValue = 0;

		private int startValue = 0;

		private int countDistance = 0;

		private float time = 0;

		private Function countInterpolate;


		// new UI
		private Text textComp;

		private CanvasRenderer textRenderer;


		/*
		============================================================================
		Get/set functions
		============================================================================
		*/
		public Color Color
		{
			get { return this.color; }
			set
			{
				if(this.color != value)
				{
					this.color = value;

					if(this.textRenderer != null)
					{
						this.textRenderer.SetColor(this.color);
					}
				}
			}
		}


		/*
		============================================================================
		Show functions
		============================================================================
		*/
		public void ShowNumber(int value, string text, GameObject targetObject, FlyingTextSettings settings, TextFormat textFormat, string valueFormat)
		{
			this.targetObject = targetObject;
			this.settings = settings;
			this.textFormat = textFormat;

			this.text = text;
			this.InitSettings();
			this.value = value;
			this.valueFormat = valueFormat;
			this.startValue = (int)((this.value / 100.0f) * this.settings.startCountFrom);
			this.countDistance = this.value - this.startValue;
			this.countInterpolate = Interpolate.Ease(this.settings.countInterpolate);
			this.counting = true;
			this.CreateObject();
		}

		public void ShowText(string value, GameObject targetObject, FlyingTextSettings settings, TextFormat textFormat)
		{
			this.targetObject = targetObject;
			this.settings = settings;
			this.textFormat = textFormat;

			this.text = value;
			this.InitSettings();
			this.CreateObject();
		}


		/*
		============================================================================
		Init functions
		============================================================================
		*/
		private void InitSettings()
		{
			// style text codes
			// color
			if(text.IndexOf(TextCode.TextColor, 0, System.StringComparison.Ordinal) >= 0)
			{
				int value = TextHelper.NextSpecial(ref this.text, TextCode.TextColor, 0);
				if(value >= 0)
				{
					this.textFormat.colorID = value;
					this.text = this.text.Replace(TextCode.TextColor + value + "#", "");
				}
			}
			if(text.IndexOf(TextCode.TextShadow, 0, System.StringComparison.Ordinal) >= 0)
			{
				int value = TextHelper.NextSpecial(ref this.text, TextCode.TextShadow, 0);
				if(value >= 0)
				{
					this.textFormat.shadowColorID = value;
					this.text = this.text.Replace(TextCode.TextShadow + value + "#", "");
				}
			}
			// font size
			if(text.IndexOf(TextCode.TextSize, 0, System.StringComparison.Ordinal) >= 0)
			{
				int value = TextHelper.NextSpecial(ref this.text, TextCode.TextSize, 0);
				if(value >= 0)
				{
					this.textFormat.fontSize = value;
					this.text = this.text.Replace(TextCode.TextSize + value + "#", "");
				}
			}
			// font style
			if(text.IndexOf(TextCode.TextStyle_Normal, 0, System.StringComparison.Ordinal) >= 0)
			{
				this.textFormat.fontStyle = FontStyle.Normal;
				this.text = this.text.Replace(TextCode.TextStyle_Normal, "");
			}
			else if(text.IndexOf(TextCode.TextStyle_BoldItalic, 0, System.StringComparison.Ordinal) >= 0)
			{
				this.textFormat.fontStyle = FontStyle.BoldAndItalic;
				this.text = this.text.Replace(TextCode.TextStyle_BoldItalic, "");
			}
			else if(text.IndexOf(TextCode.TextStyle_Bold, 0, System.StringComparison.Ordinal) >= 0)
			{
				this.textFormat.fontStyle = FontStyle.Bold;
				this.text = this.text.Replace(TextCode.TextStyle_Bold, "");
			}
			else if(text.IndexOf(TextCode.TextStyle_Italic, 0, System.StringComparison.Ordinal) >= 0)
			{
				this.textFormat.fontStyle = FontStyle.Italic;
				this.text = this.text.Replace(TextCode.TextStyle_Italic, "");
			}

			this.textColor = this.textFormat.GetTextColor();
			if(this.textFormat.showShadow)
			{
				this.shadowColor = this.textFormat.GetShadowColor();
			}

			this.screenPosition = VectorHelper.WorldToScreenPosition(this.transform.position, false);

			if(this.settings.useFlash && this.settings.flash != null)
			{
				EventFader fader = ComponentHelper.Get<EventFader>(this.targetObject);
				fader.Flash(this.settings.flash, this.settings.flashChildren, this.settings.shared,
					this.settings.setProp ? this.settings.prop : "_Color", this.settings.isFloat);
			}

			ORKMoveEvent eventAsset = this.settings.moveEvent;
			if(eventAsset != null)
			{
				List<GameObject> tmp = new List<GameObject>();
				tmp.Add(this.gameObject);
				this.moveEvent = new MoveEvent(tmp);
				this.moveEvent.SetData(eventAsset.GetData().ToDataObject());
				this.moveEvent.StartEvent(this, this.gameObject);
			}
		}

		private void CreateObject()
		{
			if(ORK.GUI.IsNewUI)
			{
				Vector2 pos = new Vector2(this.screenPosition.x, this.screenPosition.y);
				Vector2 v = UIHelper.CalculateTextSize(this.text, ref this.textFormat);
				pos = ORK.Core.UIMatrix.Matrix.MultiplyPoint3x4(pos);

				this.textComp = UIHelper.CreateText(this.text,
					new Rect(pos.x, -pos.y, v.x, v.y),
					this.textFormat, ORK.GUI.NotificationLayer);

				this.textComp.alignment = TextAnchor.MiddleCenter;
				this.textComp.horizontalOverflow = HorizontalWrapMode.Overflow;
				this.textComp.verticalOverflow = VerticalWrapMode.Overflow;
				this.textComp.rectTransform.pivot = new Vector2(0.5f, 0.5f);
				this.textComp.rectTransform.rotation = this.transform.rotation;
				this.textComp.rectTransform.localScale = Vector3.Scale(this.transform.localScale, ORK.Core.UIMatrix.Scale);

				this.textRenderer = this.textComp.GetComponent<CanvasRenderer>();
				if(this.textRenderer != null)
				{
					this.textRenderer.SetColor(this.color);
				}
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		private void Update()
		{
			if(this.text != null && this.settings != null)
			{
				float t = ORK.Game.DeltaTime;
				this.time += t;

				if(this.moveEvent != null)
				{
					this.moveEvent.Tick(t);
				}
				else if(this.time >= this.settings.destroyTime)
				{
					UnityWrapper.Destroy(this.gameObject);
				}

				if(this.countInterpolate != null)
				{
					if(this.time <= this.settings.countTime)
					{
						this.currentValue = (int)Interpolate.Ease(this.countInterpolate,
							this.startValue, this.countDistance, this.time, this.settings.countTime);
					}
					if(this.time >= this.settings.countTime)
					{
						this.currentValue = this.value;
						this.countInterpolate = null;
						this.text = this.text.Replace("%", this.currentValue.ToString(this.valueFormat));
						this.counting = false;
					}
				}
				this.screenPosition = VectorHelper.WorldToScreenPosition(this.transform.position, false);

				// new UI
				if(this.textComp != null)
				{
					if(this.counting)
					{
						this.textComp.text = this.text.Replace("%", this.currentValue.ToString(this.valueFormat));
					}
					else
					{
						this.textComp.text = this.text;
					}

					Vector2 pos = new Vector2(this.screenPosition.x, this.screenPosition.y);

					Vector2 v = UIHelper.CalculateTextSize(this.textComp.text, ref this.textFormat);

					pos = ORK.Core.UIMatrix.Matrix.MultiplyPoint3x4(pos);

					this.textComp.rectTransform.anchoredPosition = new Vector2(pos.x, -pos.y);
					this.textComp.rectTransform.sizeDelta = new Vector2(v.x, v.y);
					this.textComp.rectTransform.rotation = this.transform.rotation;
					this.textComp.rectTransform.localScale = Vector3.Scale(this.transform.localScale, ORK.Core.UIMatrix.Scale);
				}
			}
		}

		private void OnGUI()
		{
			if(!ORK.GUI.IsNewUI &&
				this.text != null &&
				this.settings != null)
			{
				GUI.color = this.color;

				GUISkin tmp = GUI.skin;
				if(this.settings.GUISkin)
				{
					GUI.skin = this.settings.GUISkin;
				}
				else if(ORK.BattleTexts.GUISkin)
				{
					GUI.skin = ORK.BattleTexts.GUISkin;
				}

				GUIContent content = new GUIContent(this.text);

				if(this.counting)
				{
					content.text = content.text.Replace("%", this.currentValue.ToString(this.valueFormat));
				}

				GUIStyle textStyle = new GUIStyle(GUI.skin.label);
				textStyle.wordWrap = false;
				if(this.textFormat.font != null)
				{
					textStyle.font = this.textFormat.font;
				}
				textStyle.fontSize = this.textFormat.fontSize;
				textStyle.fontStyle = this.textFormat.fontStyle;

				Vector2 pos = ORK.Core.UIMatrix.Matrix.MultiplyPoint3x4(
					new Vector2(this.screenPosition.x, this.screenPosition.y));

				Matrix4x4 tmpMatrix = GUI.matrix;
				GUI.matrix = Matrix4x4.TRS(pos,
					Quaternion.Euler(0, 0, -this.transform.eulerAngles.z),
					Vector3.Scale(this.transform.localScale, ORK.Core.UIMatrix.Scale));

				Vector2 v = textStyle.CalcSize(content);
				pos = new Vector2(-v.x / 2, -v.y / 2);

				if(this.textFormat.showShadow)
				{
					textStyle.normal.textColor = this.shadowColor;
					GUI.Label(this.textFormat.GetShadowRect(pos, v), content, textStyle);
				}

				textStyle.normal.textColor = this.textColor;
				GUI.Label(new Rect(pos.x, pos.y, v.x, v.y), content, textStyle);

				GUI.matrix = tmpMatrix;
				GUI.skin = tmp;
			}
		}


		/*
		============================================================================
		Event functions
		============================================================================
		*/
		public void EventEnded()
		{
			UnityWrapper.Destroy(this.gameObject);
		}

		public void DontDestroy()
		{

		}

		public void OnSceneLoaded()
		{

		}

		public GameObject GameObject
		{
			get { return this.gameObject; }
		}

		private void OnDestroy()
		{
			if(this.textComp != null)
			{
				this.textComp.rectTransform.pivot = new Vector2(0, 1);
				this.textComp.rectTransform.rotation = Quaternion.identity;
				this.textComp.rectTransform.localScale = Vector3.one;
				ORK.GUI.NewUIPool.AddTextLabel(this.textComp);
			}
		}
	}
}
