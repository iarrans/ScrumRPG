
using UnityEngine;
using UnityEngine.UI;
using ORKFramework.UI;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework.Behaviours
{
	public class UIChoiceButtonComponent : MonoBehaviour
	{
		private GUIBox box;

		private ChoiceContent content;

		private Button button;

		private ButtonClick callback;

		private UIClickComponent clickComponent;

		private int buttonIndex = 0;

		private bool isTab = false;


		// fade
		private bool startInactive = false;

		private NewUIButtonSettings buttonSettings;

		private NewUIChoiceButtonEvents buttonEvents;

		private CanvasRenderer canvasRenderer;

		private List<CanvasRenderer> childRenderer;

		public static bool IsColorTint(UIChoiceButtonComponent component)
		{
			return component != null &&
				component.button != null &&
				Selectable.Transition.ColorTint == component.button.transition;
		}

		public void Initialize(GUIBox box, ChoiceContent content, Button button,
			ButtonClick callback, int buttonIndex, bool isTab,
			NewUIButtonSettings buttonSettings, NewUIChoiceButtonEvents buttonEvents)
		{
			this.box = box;
			this.content = content;
			this.buttonSettings = buttonSettings;
			this.buttonEvents = buttonEvents;

			this.button = button;
			this.callback = callback;
			this.buttonIndex = buttonIndex;
			this.isTab = isTab;
			if(this.button != null)
			{
				this.clickComponent = ComponentHelper.Get<UIClickComponent>(this.button.gameObject);
				this.clickComponent.onLeftClick = this.ClickDelegate;
				this.clickComponent.onMiddleClick = this.ClickDelegate;
				this.clickComponent.onRightClick = this.ClickDelegate;
			}

			this.startInactive = !this.content.Active;

			if(this.buttonSettings != null)
			{
				this.canvasRenderer = this.button != null && this.button.image != null && this.button.image.canvasRenderer != null ?
					this.button.image.canvasRenderer :
					this.GetComponent<CanvasRenderer>();

				if(this.buttonSettings.fadeMode == ChildColorFadeMode.None)
				{
					if(this.childRenderer != null)
					{
						this.childRenderer.Clear();
					}
				}
				else
				{
					ArrayHelper.GetBlank(ref this.childRenderer);
					this.GetComponentsInChildren<CanvasRenderer>(this.childRenderer);
					this.childRenderer.Remove(this.canvasRenderer);
				}
			}
		}

		public void Select()
		{
			if(this.button != null)
			{
				this.button.Select();
			}
		}

		public void Deselect()
		{
			if(this.button != null)
			{
				this.button.OnDeselect(null);
			}
		}

		public void Selected()
		{
			if(this.buttonEvents != null)
			{
				ORKGameEvent eventAsset = this.buttonEvents.selectEvent;
				if(eventAsset != null)
				{
					ORK.GameEventTicker.StartEvent(eventAsset, this.box.gameObject, this.gameObject, null, null, true, null);
				}
			}
		}

		public void Deselected()
		{
			if(this.buttonEvents != null)
			{
				ORKGameEvent eventAsset = this.buttonEvents.deselectEvent;
				if(eventAsset != null)
				{
					ORK.GameEventTicker.StartEvent(eventAsset, this.box.gameObject, this.gameObject, null, null, true, null);
				}
			}
		}

		public void Accepted()
		{
			if(this.buttonEvents != null)
			{
				ORKGameEvent eventAsset = this.buttonEvents.acceptEvent;
				if(eventAsset != null)
				{
					ORK.GameEventTicker.StartEvent(eventAsset, this.box.gameObject, this.gameObject, null, null, true, null);
				}
			}
		}

		private void ClickDelegate()
		{
			if(this.callback != null &&
				this.box.Controlable &&
				this.content.Active &&
				(!this.box.focusable ||
					!ORK.GUI.FocusBlocked ||
					this.box.Focused) &&
				(!this.box.UnfocusedClick ||
					this.box.Settings.unfocusedChoice))
			{
				this.callback(this.buttonIndex);
			}
		}

		public void FireOnClick()
		{
			if(this.button != null)
			{
				this.button.onClick.Invoke();
			}
		}

		public void Clear()
		{
			if(ORK.GUI.EventSystem != null &&
				ORK.GUI.EventSystem.currentSelectedGameObject == this.gameObject)
			{
				ORK.GUI.EventSystem.SetSelectedGameObject(null);
			}

			if(this.content != null)
			{
				this.content.buttonRectTransform = null;
			}
			if(this.clickComponent != null)
			{
				this.clickComponent.onLeftClick = null;
				this.clickComponent.onMiddleClick = null;
				this.clickComponent.onRightClick = null;
				this.clickComponent = null;
			}

			this.box = null;
			this.content = null;
			this.button = null;
			this.buttonSettings = null;
			this.buttonEvents = null;
			this.canvasRenderer = null;
			if(this.childRenderer != null)
			{
				this.childRenderer.Clear();
			}
		}

		void LateUpdate()
		{
			if(this.box != null &&
				this.canvasRenderer != null &&
				this.buttonSettings != null)
			{
				if(this.button != null)
				{
					if(this.isTab ?
						this.buttonIndex == this.box.Content.TabsSelection :
						this.buttonIndex == this.box.Content.Selection)
					{
						this.button.OnSelect(null);
					}
					else
					{
						this.button.OnDeselect(null);
					}
				}

				Color boxColor = this.box.controlable && this.box.focusable &&
					!this.box.IsClosing && !this.box.Focused &&
					this.box.InactiveColor.setColor ?
						this.box.InactiveColor.color : this.box.color;

				Color color = this.canvasRenderer.GetColor();
				if(!this.box.controlable &&
					Selectable.Transition.ColorTint == this.button.transition)
				{
					color = this.button.colors.normalColor;
					this.canvasRenderer.SetColor(color * boxColor);
				}
				if(!this.box.IsOpened)
				{
					this.canvasRenderer.SetColor(color * boxColor);
					color *= boxColor;
				}
				if(this.startInactive)
				{
					if(!this.content.Active &&
						Selectable.Transition.ColorTint == this.button.transition)
					{
						color = this.button.colors.disabledColor;
						this.canvasRenderer.SetColor(color * boxColor);
					}
					else
					{
						this.startInactive = false;
					}
				}

				if(this.buttonSettings.useInactiveColor &&
					!this.content.Active)
				{
					color = this.buttonSettings.inactiveColor;
					color *= boxColor;
				}
				else
				{
					if(this.box.controlable && this.box.focusable &&
						!this.box.Focused && this.box.InactiveColor.setColor)
					{
						color = this.box.InactiveColor.color;
						this.canvasRenderer.SetColor(color);
					}
				}

				if(this.childRenderer != null &&
					this.childRenderer.Count > 0)
				{
					if(this.buttonSettings.fadeMode == ChildColorFadeMode.Alpha)
					{
						for(int i = 0; i < this.childRenderer.Count; i++)
						{
							if(this.childRenderer[i] != null)
							{
								this.childRenderer[i].SetAlpha(color.a);
							}
						}
					}
					else if(this.buttonSettings.fadeMode == ChildColorFadeMode.Color)
					{
						for(int i = 0; i < this.childRenderer.Count; i++)
						{
							if(this.childRenderer[i] != null)
							{
								this.childRenderer[i].SetColor(color);
							}
						}
					}
				}
			}
		}
	}
}
