﻿
using UnityEngine;
using ORKFramework.UI;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/UI/Object HUD")]
	public class ObjectHUDComponent : MonoBehaviour, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		private ORKDataFile serialize_setting;


		// in-game
		private bool initialized = false;

		private bool registered = false;

		protected virtual void Start()
		{
			this.initialized = true;
			this.Register();
		}

		protected virtual void Update()
		{
			for(int i = 0; i < this.settings.hud.Length; i++)
			{
				this.settings.hud[i].Tick(this.gameObject);
			}
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		protected virtual void OnEnable()
		{
			if(this.initialized)
			{
				this.Register();
			}
		}

		protected virtual void OnDisable()
		{
			if(this.initialized)
			{
				this.Unregister();
			}
		}

		public virtual void Register()
		{
			if(!this.registered)
			{
				for(int i = 0; i < this.settings.hud.Length; i++)
				{
					this.settings.hud[i].Register(this.gameObject);
				}
				this.registered = true;
			}
		}

		public virtual void Unregister()
		{
			if(this.registered)
			{
				for(int i = 0; i < this.settings.hud.Length; i++)
				{
					this.settings.hud[i].Unregister(this.gameObject);
				}
				this.registered = false;
			}
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[ORKEditorArray(false, "Add Object HUD", "Adds an 'Object' HUD to this component.", "",
				"Remove", "Removes this HUD.", "",
				isMove=true, isCopy=true, noRemoveCount=1,
				foldout=true, foldoutText=new string[]
				{
					"Object HUD", "Select the 'Object' type HUD and define optional conditions.", ""
				})]
			public ObjectHUDSelection[] hud = new ObjectHUDSelection[]
			{
				new ObjectHUDSelection()
			};

			public Settings()
			{

			}
		}
	}
}
