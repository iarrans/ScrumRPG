
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera: First Person")]
	public class FirstPersonCamera : BaseCameraControl
	{
		public string onChild = "";

		public Vector3 offset = Vector3.zero;

		public bool lockCursor = false;


		// vertical
		public int verticalAxis = 0;

		public BoolValue verticalInvert = new BoolValue();

		public FloatValue verticalSensitivity = new FloatValue(15);


		// horizontal
		public int horizontalAxis = 0;

		public BoolValue horizontalInvert = new BoolValue();

		public FloatValue horizontalSensitivity = new FloatValue(15);

		protected virtual void LateUpdate()
		{
			GameObject targetObject = this.CameraTarget;
			if(targetObject != null)
			{
				Transform target = targetObject.transform;

				if(this.lockCursor)
				{
					Cursor.lockState = CursorLockMode.Locked;
					Cursor.visible = false;
				}

				// horizontal
				float rotX = ORK.InputKeys.Get(this.horizontalAxis).GetAxis() *
					this.horizontalSensitivity.GetValue(ORK.Game.ActiveGroup.Leader);
				if(this.horizontalInvert.GetValue())
				{
					rotX *= -1;
				}
				// vertical
				float rotY = ORK.InputKeys.Get(this.verticalAxis).GetAxis() *
					this.verticalSensitivity.GetValue(ORK.Game.ActiveGroup.Leader);
				if(this.verticalInvert.GetValue())
				{
					rotY *= -1;
				}

				// X on player
				target.Rotate(0, rotX, 0);

				//  Y on camera
				Vector3 tmp = this.transform.eulerAngles;
				tmp.y = target.eulerAngles.y;
				tmp.z = 0;
				tmp.x -= rotY;

				target = TransformHelper.GetChild(this.onChild, target);

				this.UpdatePosition(
					target.position + target.TransformDirection(this.offset),
					Quaternion.Euler(tmp));
			}
		}

		protected virtual void OnDisable()
		{
			if(this.lockCursor)
			{
				Cursor.lockState = CursorLockMode.None;
				Cursor.visible = true;
			}
		}
	}
}
