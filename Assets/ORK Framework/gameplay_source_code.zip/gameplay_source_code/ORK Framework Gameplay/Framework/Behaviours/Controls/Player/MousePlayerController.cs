
using ORKFramework;
using UnityEngine;
using UnityEngine.AI;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Player: Mouse Controller")]
	public class MousePlayerController : BasePlayerControl
	{
		public bool moveDead = true;

		public MouseTouchControl mouseTouch = new MouseTouchControl(true);


		// click
		public float raycastDistance = 100.0f;

		public LayerMask layerMask = -1;


		// move
		public GameObject cursorObject;

		public bool cursorRespawn = false;

		public Vector3 cursorOffset = Vector3.zero;

		public float speedSmoothing = 10.0f;

		public bool useCharacterSpeed = false;

		public float runSpeed = 8.0f;

		public float gravity = Physics.gravity.y;

		public float minimumMoveDistance = 0.2f;

		[UnityEngine.Serialization.FormerlySerializedAs("ignoreYDistance")]
		public bool ignoreHeightDistance = true;

		public MouseControlMoveType mouseMoveType = MouseControlMoveType.CharacterController;


		// nav mesh
		public float navMeshSampleDistance = 1.0f;

		public int navMeshSampleAreaMask = NavMesh.AllAreas;


		// outside field
		public bool autoRemoveCursor = true;

		public bool autoRemoveCursorTarget = true;

		public bool autoStopMove = true;


		// secure move
		public bool secureMove = false;

		public float secureTime = 0.5f;


		// ingame
		private Vector3 targetPosition = Vector3.zero;

		private CharacterController controller;

		private NavMeshAgent navMeshAgent;

		private GameObject targetCursor;

		private bool moveToTarget = false;

		private Vector3 moveDirection = Vector3.zero;

		private bool moveStopped = false;

		private float moveSpeed = 0.0f;

		private ActorEventMover mover = null;

		private Combatant combatant = null;

		protected virtual void Start()
		{
			if(MouseControlMoveType.CharacterController == this.mouseMoveType)
			{
				this.controller = this.GetComponent<CharacterController>();
			}
			else if(MouseControlMoveType.NavMeshAgent == this.mouseMoveType)
			{
				this.navMeshAgent = this.GetComponent<NavMeshAgent>();

				if(this.navMeshAgent != null &&
					!this.navMeshAgent.isOnNavMesh)
				{
					this.navMeshAgent.enabled = false;
					this.navMeshAgent.enabled = true;
				}
			}
			this.combatant = ComponentHelper.GetCombatant(this.transform.root.gameObject);
		}

		protected virtual void Update()
		{
			if(this.combatant == null ||
				((this.moveDead || !this.combatant.Status.IsDead) &&
					!this.combatant.Status.Effects.StopMovement))
			{
				if(this.useCharacterSpeed && this.combatant != null)
				{
					this.runSpeed = this.combatant.Object.GetMoveSpeed(MoveSpeedType.Run);
				}

				// get click
				Vector3 point = Vector3.zero;
				if(this.mouseTouch.Interacted(ref point))
				{
					bool doMove = true;
					Ray ray = ORK.Game.Camera.ScreenPointToRay(point);
					RaycastOutput hit;
					if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit, this.raycastDistance, this.layerMask))
					{
						if(ORK.Game.Scene.WithinNoClickMove(hit.point))
						{
							this.ClearCursor();
							doMove = false;
						}
						else
						{
							BaseInteraction[] interactions = hit.transform.gameObject.GetComponentsInChildren<BaseInteraction>();
							for(int i = 0; i < interactions.Length; i++)
							{
								if(interactions[i] != null &&
									EventStartType.Interact == interactions[i].startType)
								{
									doMove = false;
									break;
								}
							}

							if(doMove)
							{
								if(MouseControlMoveType.EventMover == this.mouseMoveType)
								{
									this.moveStopped = false;
									this.targetPosition = hit.point;
									this.PlaceCursor();
									float distance = Vector3.Distance(this.targetPosition, this.transform.position);
									if(this.mover == null)
									{
										this.mover = ComponentHelper.Get<ActorEventMover>(this.gameObject);
									}
									this.mover.MoveToPosition(
										this.transform, true, true, true, true, this.targetPosition,
										EaseType.Linear, distance / this.runSpeed);
								}
								else if(this.combatant != null)
								{
									this.combatant.Object.Component.LastMoveTime = Time.time;
								}
							}
						}
					}
					else
					{
						doMove = false;
					}

					if(doMove &&
						MouseControlMoveType.CharacterController == this.mouseMoveType)
					{
						this.moveStopped = false;
						this.targetPosition = hit.point;
						this.moveToTarget = true;
						this.PlaceCursor();
					}
					else if(doMove &&
						MouseControlMoveType.NavMeshAgent == this.mouseMoveType)
					{
						NavMeshHit navHit;
						if(NavMesh.SamplePosition(hit.point, out navHit, this.navMeshSampleDistance, this.navMeshSampleAreaMask))
						{
							this.moveStopped = false;
							this.targetPosition = navHit.position;
							this.moveToTarget = true;
							this.PlaceCursor();
							if(this.navMeshAgent != null &&
								this.navMeshAgent.isOnNavMesh)
							{
								this.moveSpeed = Mathf.Lerp(this.moveSpeed, this.runSpeed,
									this.speedSmoothing * ORK.Game.DeltaMovementTime);
								this.navMeshAgent.speed = this.moveSpeed;
								this.navMeshAgent.SetDestination(this.targetPosition);
								this.navMeshAgent.isStopped = false;
							}
						}
						else
						{
							this.moveToTarget = false;
						}
					}
					else
					{
						this.moveToTarget = false;
					}
				}

				// move to target
				if(this.moveToTarget)
				{
					if(MouseControlMoveType.CharacterController == this.mouseMoveType)
					{
						if(this.controller != null)
						{
							if(this.minimumMoveDistance >= VectorHelper.Distance(this.transform.position, this.targetPosition, this.ignoreHeightDistance) ||
								(this.secureMove && this.combatant != null &&
									this.combatant.Object.Component.LastMoveTime + this.secureTime < Time.time))
							{
								this.moveSpeed = 0;
								this.controller.Move(Vector3.zero);

								if(this.autoRemoveCursorTarget && this.targetCursor != null)
								{
									UnityWrapper.Destroy(this.targetCursor);
								}
							}
							else
							{
								float t = ORK.Game.DeltaMovementTime;
								this.SetDirection(this.targetPosition);
								this.moveSpeed = Mathf.Lerp(this.moveSpeed, this.runSpeed, this.speedSmoothing * t);
								Vector3 movement = this.moveDirection * this.moveSpeed + new Vector3(0, this.gravity, 0);
								movement *= t;
								this.controller.Move(movement);
							}
						}
					}
					else if(MouseControlMoveType.NavMeshAgent == this.mouseMoveType)
					{
						if(this.navMeshAgent != null &&
							this.navMeshAgent.isOnNavMesh)
						{
							if(this.minimumMoveDistance >= VectorHelper.Distance(this.transform.position, this.targetPosition, this.ignoreHeightDistance) ||
								(this.secureMove && this.combatant != null &&
									this.combatant.Object.Component.LastMoveTime + this.secureTime < Time.time))
							{
								this.moveSpeed = 0;
								this.navMeshAgent.isStopped = true;

								if(this.autoRemoveCursorTarget && this.targetCursor != null)
								{
									UnityWrapper.Destroy(this.targetCursor);
								}
							}
							else
							{
								this.moveSpeed = Mathf.Lerp(this.moveSpeed, this.runSpeed,
									this.speedSmoothing * ORK.Game.DeltaMovementTime);
								this.navMeshAgent.speed = this.moveSpeed;
							}
						}
					}
				}
			}
			else
			{
				if(this.autoRemoveCursor && this.targetCursor != null)
				{
					UnityWrapper.Destroy(this.targetCursor);
				}

				if(this.autoStopMove && !this.moveStopped)
				{
					if(this.mover != null)
					{
						this.mover.StopMoving();
					}
					this.moveSpeed = 0;
					this.moveStopped = true;
					this.moveToTarget = false;

					if(MouseControlMoveType.CharacterController == this.mouseMoveType)
					{
						if(this.controller != null)
						{
							this.controller.Move(Vector3.zero);
						}
					}
					else if(MouseControlMoveType.NavMeshAgent == this.mouseMoveType)
					{
						if(this.navMeshAgent != null &&
							this.navMeshAgent.isOnNavMesh)
						{
							this.navMeshAgent.isStopped = true;
						}
					}
				}
			}
		}

		protected virtual void SetDirection(Vector3 pos)
		{
			pos.y = this.transform.position.y;
			this.transform.LookAt(pos);
			this.moveDirection = this.transform.TransformDirection(Vector3.forward);
		}

		protected virtual void OnDisable()
		{
			if(this.autoRemoveCursor && this.targetCursor != null)
			{
				UnityWrapper.Destroy(this.targetCursor);
			}
			this.mouseTouch.Clear();

			if(MouseControlMoveType.CharacterController == this.mouseMoveType)
			{
				if(this.controller != null)
				{
					this.controller.Move(Vector3.zero);
				}
			}
			else if(MouseControlMoveType.NavMeshAgent == this.mouseMoveType)
			{
				if(this.navMeshAgent != null &&
					this.navMeshAgent.isOnNavMesh)
				{
					this.navMeshAgent.isStopped = true;
				}
			}
		}


		/*
		============================================================================
		Cursor functions
		============================================================================
		*/
		public virtual void PlaceCursor()
		{
			if(this.cursorObject != null)
			{
				if(this.cursorRespawn && this.targetCursor != null)
				{
					UnityWrapper.Destroy(this.targetCursor);
					this.targetCursor = UnityWrapper.Instantiate(this.cursorObject,
						this.targetPosition + this.cursorOffset, this.cursorObject.transform.rotation);
				}
				else if(this.targetCursor == null)
				{
					this.targetCursor = UnityWrapper.Instantiate(this.cursorObject,
						this.targetPosition + this.cursorOffset, this.cursorObject.transform.rotation);
				}
				this.targetCursor.transform.position = this.targetPosition + this.cursorOffset;
			}
		}

		public virtual void ClearCursor()
		{
			if(this.targetCursor != null)
			{
				UnityWrapper.Destroy(this.targetCursor);
			}
			if(this.mover != null)
			{
				this.mover.StopMoving();
			}
			this.moveSpeed = 0;
			this.moveStopped = true;
			this.moveToTarget = false;
			if(this.controller != null)
			{
				this.controller.Move(Vector3.zero);
			}
		}

		public override void MoveToInteractionStartet(BaseInteraction interaction)
		{
			this.ClearCursor();
		}
	}
}
