
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera Border")]
	public class CameraBorder : MonoBehaviour
	{
		// set height to upper border
		public bool useBorderHeight = false;


		// set start rotation
		public bool setRotation = false;

		public float rotation = 0;

		public bool blockRotationInput = false;

		public bool blockPanning = false;

		public bool blockZooming = false;


		// set padding
		public bool setPadding = false;

		public Vector4 positionPadding = new Vector4(0, 0, 0, 0);


		// collider
		private Collider colliderComponent;

		private Collider2D collider2DComponent;

		void Start()
		{
			this.colliderComponent = this.GetComponent<Collider>();
			this.collider2DComponent = this.GetComponent<Collider2D>();
		}

		public float DistanceToCameraTarget(Vector3 position)
		{
			if(this.colliderComponent != null)
			{
				return Vector3.Distance(position,
					this.colliderComponent.ClosestPointOnBounds(position));
			}
			else if(this.collider2DComponent != null)
			{
				return Vector3.Distance(position,
					this.collider2DComponent.bounds.ClosestPoint(position));
			}
			return Mathf.Infinity;
		}

		public void UpdatePosition(ref Vector3 position, Vector4 padding, HorizontalPlaneType horizontalPlane)
		{
			if(this.colliderComponent != null)
			{
				if(this.setPadding)
				{
					padding = this.positionPadding;
				}

				// clamp to border
				// x-axis
				if(position.x < this.colliderComponent.bounds.min.x + padding.x)
				{
					position.x = this.colliderComponent.bounds.min.x + padding.x;
				}
				else if(position.x > this.colliderComponent.bounds.max.x - padding.z)
				{
					position.x = this.colliderComponent.bounds.max.x - padding.z;
				}
				if(HorizontalPlaneType.XZ == horizontalPlane)
				{
					// z-axis
					if(position.z > this.colliderComponent.bounds.max.z - padding.y)
					{
						position.z = this.colliderComponent.bounds.max.z - padding.y;
					}
					else if(position.z < this.colliderComponent.bounds.min.z + padding.w)
					{
						position.z = this.colliderComponent.bounds.min.z + padding.w;
					}
				}
				else if(HorizontalPlaneType.XY == horizontalPlane)
				{
					// y-axis
					if(position.y > this.colliderComponent.bounds.max.y - padding.y)
					{
						position.y = this.colliderComponent.bounds.max.y - padding.y;
					}
					else if(position.y < this.colliderComponent.bounds.min.y + padding.w)
					{
						position.y = this.colliderComponent.bounds.min.y + padding.w;
					}
				}
			}
			else if(this.collider2DComponent != null)
			{
				if(this.setPadding)
				{
					padding = this.positionPadding;
				}

				// clamp to border
				// x-axis
				if(position.x < this.collider2DComponent.bounds.min.x + padding.x)
				{
					position.x = this.collider2DComponent.bounds.min.x + padding.x;
				}
				else if(position.x > this.collider2DComponent.bounds.max.x - padding.z)
				{
					position.x = this.collider2DComponent.bounds.max.x - padding.z;
				}
				if(HorizontalPlaneType.XZ == horizontalPlane)
				{
					// z-axis
					if(position.z > this.collider2DComponent.bounds.max.z - padding.y)
					{
						position.z = this.collider2DComponent.bounds.max.z - padding.y;
					}
					else if(position.z < this.collider2DComponent.bounds.min.z + padding.w)
					{
						position.z = this.collider2DComponent.bounds.min.z + padding.w;
					}
				}
				else if(HorizontalPlaneType.XY == horizontalPlane)
				{
					// y-axis
					if(position.y > this.collider2DComponent.bounds.max.y - padding.y)
					{
						position.y = this.collider2DComponent.bounds.max.y - padding.y;
					}
					else if(position.y < this.collider2DComponent.bounds.min.y + padding.w)
					{
						position.y = this.collider2DComponent.bounds.min.y + padding.w;
					}
				}
			}
		}

		public void UpdateCameraHeight(ref Vector3 position, HorizontalPlaneType horizontalPlane, bool useZooming)
		{
			if(this.colliderComponent != null && this.useBorderHeight)
			{
				if(HorizontalPlaneType.XZ == horizontalPlane)
				{
					if(!useZooming || position.y > this.colliderComponent.bounds.max.y)
					{
						position.y = this.colliderComponent.bounds.max.y;
					}
				}
				else if(HorizontalPlaneType.XY == horizontalPlane)
				{
					if(!useZooming || position.z < this.colliderComponent.bounds.min.z)
					{
						position.z = this.colliderComponent.bounds.min.z;
					}
				}
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "CameraBorder.psd");
		}
	}
}
