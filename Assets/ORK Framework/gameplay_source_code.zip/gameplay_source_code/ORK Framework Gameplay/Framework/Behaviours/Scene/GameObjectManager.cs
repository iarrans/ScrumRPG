﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/Game Object Manager")]
	public class GameObjectManager : MonoBehaviour, ISerializationCallbackReceiver
	{
		public GameObject[] gameObjects = new GameObject[0];

		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		private ORKDataFile serialize_setting;


		// in-game
		private bool initialized = false;

		private bool registered = false;

		private bool changed = true;

		private bool lastConditionCheck = false;

		private bool firstChange = true;

		protected virtual void Start()
		{
			this.initialized = true;
			this.Register();
		}

		protected virtual void Update()
		{
			if(this.registered &&
				this.changed)
			{
				this.changed = false;
				bool tmp = this.lastConditionCheck;
				this.lastConditionCheck = this.settings.requirements.Check(this.gameObject);

				if(tmp != this.lastConditionCheck ||
					this.firstChange)
				{
					this.firstChange = false;
					for(int i = 0; i < this.gameObjects.Length; i++)
					{
						if(this.gameObjects[i] != null &&
							this.gameObjects[i].activeInHierarchy != this.lastConditionCheck)
						{
							this.gameObjects[i].SetActive(this.lastConditionCheck);
						}
					}
				}
			}
		}

		public virtual void ConditionsChanged()
		{
			this.changed = true;
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		protected virtual void OnEnable()
		{
			this.firstChange = true;
			if(this.initialized)
			{
				this.Register();
			}
		}

		protected virtual void OnDisable()
		{
			if(this.initialized)
			{
				this.Unregister();
			}
		}

		public virtual void Register()
		{
			if(!this.registered)
			{
				this.settings.requirements.Register(this.gameObject, this.ConditionsChanged);
				this.registered = true;
				this.changed = true;
			}
		}

		public virtual void Unregister()
		{
			if(this.registered)
			{
				this.settings.requirements.Unregister(this.gameObject, this.ConditionsChanged);
				this.registered = false;
			}
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			public ObjectRequirement requirements = new ObjectRequirement();

			public Settings()
			{

			}
		}
	}
}
