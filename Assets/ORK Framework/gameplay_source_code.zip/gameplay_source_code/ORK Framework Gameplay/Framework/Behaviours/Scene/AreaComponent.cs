
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/Area Name")]
	public class AreaComponent : MonoBehaviour
	{
		[ORKEditorInfo(ORKDataType.Area)]
		public int areaID = 0;

		public bool show = true;

		public bool autoName = true;


		// trigger
		public bool startByCollider = true;

		public bool startByTrigger = true;


		// trigger/collider
		public bool startByRootObject = false;

		public bool useOtherObject = false;

		public EventStartObject startObjectCheck;


		protected virtual void OnTriggerEnter(Collider other)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject || other.transform == other.transform.root) &&
				((this.startByCollider && !other.isTrigger) ||
					(this.startByTrigger && other.isTrigger)) &&
				this.CheckStartObject(other.gameObject))
			{
				ORK.Game.SetArea(this.areaID, this.show);
			}

			/*GameObject player = ORK.Game.GetPlayer();
			if(player != null && other.transform.root == player.transform.root)
			{
				ORK.Game.SetArea(this.areaID, this.show);
			}*/
		}

		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			if(this.isActiveAndEnabled &&
				(!this.startByRootObject ||
					other.transform == other.transform.root) &&
				((this.startByCollider && !other.isTrigger) ||
					(this.startByTrigger && other.isTrigger)) &&
				this.CheckStartObject(other.gameObject))
			{
				ORK.Game.SetArea(this.areaID, this.show);
			}
			/*GameObject player = ORK.Game.GetPlayer();
			if(player != null && other.transform.root == player.transform.root)
			{
				ORK.Game.SetArea(this.areaID, this.show);
			}*/
		}

		public virtual bool CheckStartObject(GameObject gameObject)
		{
			return gameObject != null &&
				((!this.useOtherObject &&
					(gameObject == ORK.Game.GetPlayer() ||
						(ORK.Game.GetPlayer() != null &&
						gameObject.transform.root == ORK.Game.GetPlayer().transform.root))) ||
				(this.useOtherObject && this.startObjectCheck.CheckObject(gameObject)));
		}

		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "Area.psd");
		}

		public virtual void SetAutoName()
		{
			this.name = "Area: " + ORK.Areas.GetName(this.areaID);
		}
	}
}
