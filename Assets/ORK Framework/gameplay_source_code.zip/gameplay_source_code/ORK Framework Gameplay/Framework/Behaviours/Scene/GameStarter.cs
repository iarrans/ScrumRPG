
using ORKFramework;
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/ORK Game Starter")]
	public class GameStarter : MonoBehaviour
	{
		public bool useAssetBundle = false;

		public ORKProjectAsset project;

		public ORKProjectAssetBundleLoader assetBundle = new ORKProjectAssetBundleLoader();


		// call main menu
		public bool loadMainMenuScene = false;

		public bool callMainMenu = false;

		public float callAfter = 0;


		// start game
		public bool startGame = false;

		protected virtual void Awake()
		{
			if(!ORK.Initialized)
			{
				if(this.useAssetBundle)
				{
					if(this.assetBundle.loadAsync)
					{
						this.StartCoroutine(this.assetBundle.GetProjectAssetAsync(this.LoadProject));
					}
					else
					{
						this.LoadProject(this.assetBundle.GetProjectAsset());
					}
				}
				else
				{
					this.LoadProject(this.project);
				}
			}
		}

		protected virtual void LoadProject(ORKProjectAsset projectAsset)
		{
			if(!ORK.Initialized)
			{
				if(projectAsset != null)
				{
					ORK.Initialize(projectAsset);
				}
				else
				{
					Debug.LogError("ORK Project Asset not found!");
				}

				if(!ORK.Game.Running)
				{
					if(this.loadMainMenuScene)
					{
						ORK.Game.LoadMainMenuScene();
					}
					else if(this.callMainMenu)
					{
						this.StartCoroutine(this.CallMainMenu());
					}
					else if(this.startGame)
					{
						ORK.Game.NewGame(false);
					}
				}
			}
		}

		protected virtual IEnumerator CallMainMenu()
		{
			if(this.callAfter > 0)
			{
				yield return new WaitForSeconds(this.callAfter);
			}
			ORK.MainMenu.menu.Show();
		}

		public virtual float AsyncProgress
		{
			get
			{
				if(this.useAssetBundle &&
					this.assetBundle.loadAsync)
				{
					return this.assetBundle.Progress;
				}
				return 0;
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "GameStarter.psd");
		}
	}
}
