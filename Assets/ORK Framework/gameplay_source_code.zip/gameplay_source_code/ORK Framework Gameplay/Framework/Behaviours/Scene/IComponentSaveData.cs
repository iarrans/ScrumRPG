﻿
namespace ORKFramework
{
	/// <summary>
	/// Interface used for saving/loading component data of a combatant with a save game.
	/// Will automatically save the data of components implementing this interface that are attached to a combatant's game object.
	/// Please note that only members of the player group are saved, but this can also be used to store data of remembered combatant spawner combatants.
	/// </summary>
	public interface IComponentSaveData : ISaveData
	{
		/// <summary>
		/// The data of a component is stored with a save key to know which component will get which data.
		/// The save key mustn't contain any spaces.
		/// </summary>
		/// <returns>The key used for saving this data.</returns>
		string GetSaveKey();
	}
}
