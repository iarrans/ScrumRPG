
using UnityEngine;
using ORKFramework;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Events/Variable Event")]
	public class VariableEvent : BaseInteraction
	{
		public bool repeatExecution = false;

		public bool deactivateAfter = false;


		// time settings
		public float timeBefore = 0.0f;

		public float timeAfter = 0.0f;


		/*
		============================================================================
		Start functions
		============================================================================
		*/
		protected override void Start()
		{
			if(!this.CheckAutoDestroy())
			{
				this.CheckAutoStart();
			}
		}

		private void CheckAutoStart()
		{
			if(EventStartType.Autostart == this.startType)
			{
				if(this.CheckConditions())
				{
					this.DoAutoStart();
				}
				else if(this.repeatExecution)
				{
					this.StartCoroutine(CheckAutoStart2());
				}
			}
		}

		private IEnumerator CheckAutoStart2()
		{
			if(this.timeAfter > 0)
			{
				yield return new WaitForSeconds(this.timeAfter);
			}
			else
			{
				yield return new WaitForSeconds(0.1f);
			}
			this.CheckAutoStart();
		}

		public override void StartEvent(GameObject startingObject)
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;

			if(!this.eventStarted)
			{
				this.eventStarted = true;

				this.StartCoroutine(StartEvent2());
			}
		}

		private IEnumerator StartEvent2()
		{
			if(this.timeBefore > 0)
			{
				yield return new WaitForSeconds(this.timeBefore);
			}

			this.SetVariables();

			if(this.timeAfter > 0)
			{
				yield return new WaitForSeconds(this.timeAfter);
			}
			else
			{
				yield return new WaitForSeconds(0);
			}
			this.eventStarted = false;

			if(this.deactivateAfter)
			{
				this.gameObject.SetActive(false);
			}
			else
			{
				if(EventStartType.Autostart == this.startType &&
					this.repeatExecution)
				{
					this.CheckAutoStart();
				}
				if(this.repeatDestroy)
				{
					this.CheckAutoDestroy();
				}
			}
		}

		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "VariableEvent.psd");
		}


		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public override InteractionType Type
		{
			get { return InteractionType.VariableEvent; }
		}
	}
}
