
using ORKFramework;
using ORKFramework.Events;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ORKFramework.Behaviours
{
	public delegate void SceneChangeInfoNotify(bool inOldScene, bool beforeFade, SceneLoadType loadType);

	[AddComponentMenu("ORK Framework/Scenes/Scene Changer")]
	public class SceneChanger : BaseInteraction
	{
		// scene settings
		public SceneTarget[] target = new SceneTarget[] {new SceneTarget()};


		// audio
		public AudioClip audioClip;

		public float volume = 1;

		public bool waitForAudio = false;


		// clear scene data
		public SceneChangeClear clear = SceneChangeClear.None;

		public bool clearDrops = false;

		public bool clearCollects = false;

		public bool clearBattles = false;

		public bool clearPosition = false;

		public bool clearSpawner = false;


		// screen fade settings
		public bool useFadeOut = true;

		public FadeColorSettings fadeOut = new FadeColorSettings(0.5f, 0, 1);

		public bool waitFaidIn = false;

		public bool useFadeIn = true;

		public FadeColorSettings fadeIn = new FadeColorSettings(0.5f, 1, 0);


		// ingame
		public bool delayLoaded = false;

		private bool check = false;

		private DataObject saveGameData = null;

		private bool newGame = false;

		private int randomIndex = 0;


		// notify event
		private IEventStarter eventStarter;

		public void SetStarter(IEventStarter starter)
		{
			this.eventStarter = starter;
		}

		public void LoadSaveGame(string sc, DataObject data, int sID)
		{
			SceneTarget tmpTarget = new SceneTarget(sc, sID);
			tmpTarget.loadSceneMode = ORK.SaveGameMenu.loadSceneMode;
			tmpTarget.loadAsync = ORK.SaveGameMenu.loadAsync;

			this.target = new SceneTarget[] { tmpTarget };
			this.saveGameData = data;
			this.useFadeOut = ORK.SaveGameMenu.useFadeOut;
			this.fadeOut = ORK.SaveGameMenu.fadeOut;
			this.useFadeIn = ORK.SaveGameMenu.useFadeIn;
			this.fadeIn = ORK.SaveGameMenu.fadeIn;
		}

		public void NewGameScene()
		{
			SceneTarget tmpTarget = new SceneTarget(ORK.MainMenu.newGameScene, -1);
			tmpTarget.loadSceneMode = ORK.MainMenu.newGameLoadSceneMode;
			tmpTarget.loadAsync = ORK.MainMenu.newGameLoadAsync;

			this.target = new SceneTarget[] { tmpTarget };
			this.useFadeOut = ORK.MainMenu.useFadeOut;
			this.fadeOut = ORK.MainMenu.fadeOut;
			this.useFadeIn = ORK.MainMenu.useFadeIn;
			this.fadeIn = ORK.MainMenu.fadeIn;
			this.newGame = true;
		}

		public override void StartEvent(GameObject startingObject)
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;

			if(!this.eventStarted)
			{
				this.eventStarted = true;

				if(this.saveGameData != null)
				{
					ORK.Control.Clear();
					ORK.Game.Running = true;
				}
				// clear battle when not from an event (e.g. battle start)
				if(this.eventStarter == null)
				{
					ORK.Battle.ClearBattle();
				}
				this.StartCoroutine(this.ChangeScene2());
			}
		}

		private IEnumerator ChangeScene2()
		{
			this.randomIndex = UnityWrapper.Range(0, this.target.Length);
			if(this.target[this.randomIndex].Exists)
			{
				this.transform.SetParent(null);
				GameObject.DontDestroyOnLoad(this.transform.root);
				ORK.Control.SetChangingScene(1);

				// play audio
				if(this.audioClip != null &&
					ComponentHelper.PlayOneShot(this.gameObject, this.audioClip, this.volume) &&
					this.waitForAudio)
				{
					yield return new WaitForSeconds(this.audioClip.length);
				}

				SceneLoadType loadType = SceneLoadType.SceneChange;
				if(this.newGame)
				{
					loadType = SceneLoadType.NewGame;
				}
				else if(this.saveGameData != null)
				{
					loadType = SceneLoadType.LoadGame;
				}
				else if(this.eventStarter != null &&
					(this.eventStarter is BattleStartEvent ||
					this.eventStarter is BattleEndEvent ||
					this.eventStarter is BattleEvent ||
					this.eventStarter is PhaseChangeEvent))
				{
					loadType = SceneLoadType.Battle;
				}

				ORK.Control.FireSceneChangeInfo(true, true, loadType);

				// faid screen
				if(this.useFadeOut && this.fadeOut != null)
				{
					ORK.GUI.ScreenFader.FadeScreen(this.fadeOut);
					yield return new WaitForSeconds(this.fadeOut.time);
				}
				this.check = true;

				ORK.Control.FireSceneChangeInfo(true, false, loadType);

				yield return null;

				// clear scene data
				if(SceneChangeClear.Current == this.clear ||
					SceneChangeClear.Both == this.clear)
				{
					ORK.Game.Scene.ClearScene(SceneManager.GetActiveScene().name,
						this.clearDrops, this.clearCollects, this.clearBattles,
						this.clearPosition, this.clearSpawner);
				}
				if(SceneChangeClear.Next == this.clear ||
					SceneChangeClear.Both == this.clear)
				{
					ORK.Game.Scene.ClearScene(this.target[this.randomIndex].GetSceneName(),
						this.clearDrops, this.clearCollects, this.clearBattles,
						this.clearPosition, this.clearSpawner);
				}

				if(ORK.GameControls.playerControl.sceneChangeDestroyPlayer)
				{
					GameObject player = ORK.Game.GetPlayer();
					if(player != null)
					{
						UnityWrapper.Destroy(player);
					}
				}

				AssetSourceCache.Instance.Clear(
					ORK.GameSettings.assetSettings.unloadResourcesOnSceneChange,
					ORK.GameSettings.assetSettings.unloadAssetBundlesOnSceneChange);

				// load scene
				if(this.target[this.randomIndex].LoadScene())
				{
					this.delayLoaded = true;
					this.StartCoroutine(this.OnSceneLoaded2());
					ORKCore.Instance.FireSceneLoaded();
				}
				else
				{
					ORKCore.Instance.SceneLoaded += this.OnSceneLoaded;
				}
			}
			else
			{
				if(this.newGame)
				{
					ORK.GlobalEvents.InitGlobalEvents();
					ORK.Game.Running = true;
					ORK.Game.CallStartEvent();
				}
				else if(this.saveGameData != null)
				{
					ORK.SaveGame.Loaded(this.saveGameData);
					ORK.Game.Running = true;
				}
				this.eventStarted = false;
			}
		}

		private void OnSceneLoaded()
		{
			if(this.randomIndex >= 0 &&
				this.randomIndex < this.target.Length &&
				this.target[this.randomIndex].IsLoaded)
			{
				ORKCore.Instance.SceneLoaded -= this.OnSceneLoaded;
				this.StartCoroutine(this.OnSceneLoaded2());
			}
		}

		private IEnumerator OnSceneLoaded2()
		{
			if(this.check)
			{
				if(this.delayLoaded)
				{
					yield return null;
				}

				this.SetVariables();

				SceneLoadType loadType = SceneLoadType.SceneChange;

				if(this.newGame)
				{
					loadType = SceneLoadType.NewGame;
					ORK.GlobalEvents.InitGlobalEvents();
					ORK.Game.Running = true;
					ORK.Game.CallStartEvent();
				}
				else if(this.saveGameData != null)
				{
					loadType = SceneLoadType.LoadGame;
					ORK.SaveGame.Loaded(this.saveGameData);
					ORK.Game.Running = true;
				}
				else if(this.eventStarter != null &&
					(this.eventStarter is BattleStartEvent ||
					this.eventStarter is BattleEndEvent ||
					this.eventStarter is BattleEvent ||
					this.eventStarter is PhaseChangeEvent))
				{
					loadType = SceneLoadType.Battle;
				}

				// battle scene changes
				if(this.eventStarter != null &&
					this.eventStarter is BattleStartEvent &&
					this.eventStarter.GameObject != null)
				{
					this.target[this.randomIndex].Spawn(this.eventStarter.GameObject);

				}
				// spawn player
				else
				{
					this.target[this.randomIndex].SpawnPlayer();
				}

				if(this.eventStarter != null)
				{
					this.eventStarter.OnSceneLoaded();
				}

				if(!this.useFadeIn || this.fadeIn == null || !this.waitFaidIn)
				{
					ORK.Control.SetChangingScene(-1);
				}

				ORK.Control.FireSceneChangeInfo(false, true, loadType);

				// fade in
				if(this.useFadeIn && this.fadeIn != null)
				{
					ORK.GUI.ScreenFader.FadeScreen(this.fadeIn);
					if(this.waitFaidIn)
					{
						yield return new WaitForSeconds(this.fadeIn.time);
						ORK.Control.SetChangingScene(-1);
					}
				}

				ORK.Control.FireSceneChangeInfo(false, false, loadType);

				yield return null;

				if(ComponentHelper.IsAlive(this.eventStarter))
				{
					this.eventStarter.EventEnded();
				}

				UnityWrapper.Destroy(this.gameObject);
			}
		}

		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "SceneChanger.psd");
		}


		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public override InteractionType Type
		{
			get { return InteractionType.SceneChange; }
		}
	}
}
