
using ORKFramework;
using UnityEngine;
using UnityEngine.AI;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class CombatantComponent : MonoBehaviour
	{
		public Combatant combatant;

		public AddCombatant addCombatantComponent;

		public bool preventDestroyReset = false;

		protected bool registered = false;


		// movement variables
		protected bool inAir = false;

		protected float verticalSpeed = 0;

		protected float horizontalSpeed = 0;

		protected Vector3 lastPosition;

		protected float lastMoveTime = 0;

		protected Vector3 lastDirectionLocal = Vector3.zero;


		// movement components
		protected CharacterController controllerComp;

		protected Rigidbody rigidbodyComp;

		protected Rigidbody2D rigidbody2DComp;

		protected NavMeshAgent navMeshAgent;

		protected virtual void Start()
		{
			// find character controller
			this.controllerComp = this.GetComponent<CharacterController>();
			if(this.controllerComp == null)
			{
				this.controllerComp = this.transform.root.GetComponentInChildren<CharacterController>();
			}
			// find rigidbody
			this.rigidbodyComp = this.GetComponent<Rigidbody>();
			if(this.rigidbodyComp == null)
			{
				this.rigidbodyComp = this.transform.root.GetComponentInChildren<Rigidbody>();
			}
			// find rigidbody2D
			this.rigidbody2DComp = this.GetComponent<Rigidbody2D>();
			if(this.rigidbody2DComp == null)
			{
				this.rigidbody2DComp = this.transform.root.GetComponentInChildren<Rigidbody2D>();
			}
			// find navmesh agent
			this.navMeshAgent = this.GetComponent<NavMeshAgent>();
			if(this.navMeshAgent == null)
			{
				this.navMeshAgent = this.transform.root.GetComponentInChildren<NavMeshAgent>();
			}

			this.lastPosition = this.transform.position;

			// set damage dealer/zone combatant
			if(this.combatant != null)
			{
				DamageBase[] damage = this.gameObject.GetComponentsInChildren<DamageBase>();
				for(int i = 0; i < damage.Length; i++)
				{
					damage[i].Combatant = this.combatant;
				}
			}
		}


		/*
		============================================================================
		Combatant register functions
		============================================================================
		*/
		protected virtual void OnEnable()
		{
			if(this.combatant != null && !this.registered)
			{
				ORK.Game.Combatants.Add(this.combatant, false);
				this.registered = true;
			}
		}

		protected virtual void OnDisable()
		{
			if(!this.preventDestroyReset &&
				this.combatant != null &&
				this.registered)
			{
				ORK.Game.Combatants.Remove(this.combatant);
				this.registered = false;
			}
		}

		protected virtual void OnDestroy()
		{
			if(!this.preventDestroyReset &&
				this.combatant != null)
			{
				this.combatant.Grid.Cell = null;

				if(this.combatant.GameObject == this.gameObject)
				{
					this.combatant.Object.StorePosition();
					this.combatant.Object.StoreComponentData();
					this.combatant.UI.Clear();
				}
			}
		}


		/*
		============================================================================
		Tick functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(this.combatant != null && !ORK.Game.Paused)
			{
				if(!this.registered)
				{
					this.OnEnable();
				}

				if(!this.combatant.Status.IsDead &&
					this.combatant.GameObject != null)
				{
					// check leave arena
					if(ORK.Control.InBattle)
					{
						if(ORK.Battle.LeftBattleArena(this.combatant))
						{
							ORK.Battle.RemoveCombatant(this.combatant, false, ORK.Battle.System.leaveArenaDestroyNonPlayer);
						}
					}
					// check start battle
					else if(ORK.Control.CanInteract &&
						!ORK.Game.ActiveGroup.AllDeadBattle() &&
						ORK.Game.ActiveGroup.Leader != null &&
						ORK.Game.ActiveGroup.Leader.GameObject != null &&
						this.combatant.IsEnemy(ORK.Game.ActiveGroup.Leader) &&
						// check auto start
						this.combatant.Setting.AutoStartBattles.Check(this.combatant, ORK.Game.ActiveGroup.Leader))
					{
						List<GameObject> tmp = new List<GameObject>();
						tmp.Add(this.combatant.GameObject);
						tmp.Add(ORK.Game.ActiveGroup.Leader.GameObject);

						Vector3 center = TransformHelper.GetCenterPosition(tmp);
						BattleComponent battle = null;

						if(this.combatant.Group.SpawnOrigin != null &&
							this.combatant.Group.SpawnOrigin.Spawner != null)
						{
							battle = this.combatant.Group.SpawnOrigin.Spawner.GetBattleComponent(center,
								ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles,
								this.combatant.Setting.AutoStartBattles);
						}
						else if(this.addCombatantComponent != null)
						{
							battle = this.addCombatantComponent.GetBattleComponent(center,
								ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles,
								this.combatant.Setting.AutoStartBattles);
						}
						else
						{
							battle = new GameObject("_Battle").AddComponent<BattleComponent>();
							battle.transform.SetPositionAndRotation(center,
								ORK.Game.ActiveGroup.Leader.GameObject.transform.rotation);
							battle.battleType = this.combatant.Group.BattleType;
							battle.useSceneID = false;
							battle.DontDestroy();
						}

						if(battle != null)
						{
							battle.StartGroup(this.combatant.Group, null);
						}
					}
				}
			}
		}

		protected virtual void LateUpdate()
		{
			if(this.combatant != null && !ORK.Game.Paused)
			{
				this.UpdateMovementDelta();
			}
		}


		/*
		============================================================================
		Movement functions
		============================================================================
		*/
		protected virtual void UpdateMovementDelta()
		{
			// position change
			if(this.combatant.Setting.moveSettings.usePositionChange)
			{
				this.SetVelocity((this.transform.position - this.lastPosition) / Time.deltaTime);
			}
			else
			{
				if(this.navMeshAgent != null)
				{
					this.SetVelocity(this.navMeshAgent.velocity);
				}
				else if(this.controllerComp != null)
				{
					this.SetVelocity(this.controllerComp.velocity);
				}
				else if(this.rigidbodyComp != null)
				{
					this.SetVelocity(this.rigidbodyComp.velocity);
				}
				else if(this.rigidbody2DComp != null)
				{
					this.SetVelocity(this.rigidbody2DComp.velocity);
				}
				else
				{
					this.SetVelocity((this.transform.position - this.lastPosition) / Time.deltaTime);
				}
			}

			this.FindGround(this.combatant.Setting.moveSettings.FindGround);

			if(this.transform.position != this.lastPosition)
			{
				this.lastPosition = this.transform.position;
				this.lastMoveTime = Time.time;
			}
		}

		protected virtual void FindGround(FindGroundSettings settings)
		{
			if(FindGroundType.CharacterController == settings.type)
			{
				if(this.controllerComp != null &&
					this.navMeshAgent == null)
				{
					this.inAir = !this.controllerComp.isGrounded;
				}
			}
			else if(FindGroundType.Raycast == settings.type)
			{
				this.inAir = !settings.Raycast(this.transform);
			}
		}

		public virtual bool InAir
		{
			get { return this.inAir; }
			set { this.inAir = value; }
		}

		public virtual float HorizontalSpeed
		{
			get { return this.horizontalSpeed; }
		}

		public virtual float VerticalSpeed
		{
			get { return this.verticalSpeed; }
		}

		protected virtual void SetVelocity(Vector3 velocity)
		{
			if(HorizontalPlaneType.XZ == ORK.GameSettings.horizontalPlane)
			{
				this.verticalSpeed = velocity.y;
				velocity.y = 0;
				this.horizontalSpeed = velocity.magnitude;
			}
			else
			{
				this.verticalSpeed = velocity.z;
				velocity.z = 0;
				this.horizontalSpeed = velocity.magnitude;
			}
			this.lastDirectionLocal = this.transform.InverseTransformDirection(velocity.normalized);
		}

		public virtual float LastMoveTime
		{
			get { return this.lastMoveTime; }
			set { this.lastMoveTime = value; }
		}

		public virtual Vector3 LastDirectionLocal
		{
			get { return this.lastDirectionLocal; }
		}


		/*
		============================================================================
		Drop functions
		============================================================================
		*/
		public virtual bool DropInteract(DragInfo drag)
		{
			if(drag == null)
			{
				return ORK.Battle.CombatantClicked(this.combatant);
			}
			else if(drag.Origin != null)
			{
				return drag.Origin.DroppedOnCombatant(this.combatant, drag);
			}
			return false;
		}
	}
}
