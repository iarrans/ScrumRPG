
using UnityEngine;

namespace ORKFramework
{
	public class AreasSettings : BaseLanguageSettings<Area>
	{
		public AreasSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "areas"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Area; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.AreaTypes.GetName(this.data[i].typeID) + "/" + i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}
	}
}

