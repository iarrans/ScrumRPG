
using UnityEngine;

namespace ORKFramework
{
	public class AbilitiesSettings : BaseLanguageSettings<Ability>
	{
		public AbilitiesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "abilities"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Ability; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.AbilityTypes.GetName(this.data[i].abilityType) +
						"/" + i + ": " + this.data[i].GetName();
				}
				else
				{
					names[i] = this.data[i].GetName();
				}
			}
			return names;
		}
	}
}
