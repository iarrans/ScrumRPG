
using UnityEngine;
using ORKFramework.UI;
using ORKFramework.Menu;

namespace ORKFramework
{
	public class MenuSettings : BaseSettings
	{
		// gui system settings
		[ORKEditorHelp("GUI System Type", "Select which GUI system will be used:\n" +
			"- Legacy GUI: The old legacy Unity GUI.\n" +
			"- New UI: The new UI.", "")]
		[ORKEditorInfo("Base Settings", "Base display and control settings.", "",
			labelText="GUI System Settings")]
		public GUISystemType guiSystemType = GUISystemType.LegacyGUI;

		[ORKEditorLayout("guiSystemType", GUISystemType.NewUI, endCheckGroup=true)]
		public NewUISettings newUI = new NewUISettings();


		// general gui settings
		[ORKEditorHelp("Key Scroll Speed", "The amount of pixels the scrollbar is moved when using keys.\n" +
			"Can be overridden by each GUI box individually.", "")]
		[ORKEditorInfo(separator=true, labelText="General GUI Settings")]
		public float scrollSpeed = 3;

		// focus click
		[ORKEditorHelp("Focus Cursor Over", "Focus will be on the GUI box the mouse cursor is currently over.", "")]
		[ORKEditorInfo(separator=true)]
		public bool focusCursorOver = false;

		[ORKEditorHelp("Focus Left Click", "Clicking with the left mouse button on a GUI box will change focus to it.", "")]
		public bool focusLeftClick = true;

		[ORKEditorHelp("Focus Middle Click", "Clicking with the middle mouse button on a GUI box will change focus to it.", "")]
		public bool focusMiddleClick = false;

		[ORKEditorHelp("Focus Right Click", "Clicking with the right mouse button on a GUI box will change focus to it.", "")]
		public bool focusRightClick = false;

		// cursor over
		[ORKEditorHelp("Mouse Over Selection", "Hovering the mouse cursor above a choice will select it (not accept).\n" +
			"This only happens on the currently focused GUI box.", "")]
		[ORKEditorInfo(separator=true)]
		public bool choiceMouseOver = false;

		[ORKEditorHelp("Unlocked Mouse Over", "The mouse over selection is only used when the cursor isn't locked.", "")]
		[ORKEditorLayout("choiceMouseOver", true)]
		public bool choiceMouseOverUnlocked = true;

		[ORKEditorHelp("Unfocused Mouse Over", "The mouse over selection is used on onfocused GUI boxes.\n" +
			"If disabled, only the currently focused GUI box will use mouse over selection.", "")]
		public bool choiceMouseOverUnfocused = false;

		[ORKEditorHelp("Drag Mouse Over", "The mouse over selection is used while dragging content.\n" +
			"If disabled, the mouse over selection won't be used when dragging content.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool choiceMouseOverDrag = true;

		[ORKEditorHelp("Default Mask Material", "Select the default material that will be used for texture alpha masks.\n" +
			"The default mask material can be overridden by each image that can use alpha masks.", "")]
		public AssetSource<Material> defaultMaskMaterial = new AssetSource<Material>();


		// icon size setting
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Default Icon Size")]
		public IconSizeSetting defaultIconSize = new IconSizeSetting();


		// preview settings
		[ORKEditorInfo("Tooltip Settings", "These settings handle displaying tooltips.\n" +
			"Many tooltips can be enabled/disabled for individual parts, e.g. in menu screens.\n"+
			"Tooltips can be displayed using 'Tooltip' HUDs.", "",
			endFoldout=true)]
		public TooltipSettings tooltip = new TooltipSettings();


		// preview settings
		[ORKEditorInfo("Status Preview Settings", "These settings handle the status previews for combatants.\n" +
			"Status previews can e.g. be displayed in HUDs when using the 'Preview' value origin for status values.", "",
			endFoldout=true)]
		public PreviewSettings preview = new PreviewSettings();


		// drag and drop
		[ORKEditorHelp("Layer Mask", "Select the layer the raycast will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		[ORKEditorInfo("Drag/Drop Settings", "Define drag/drop interaction settings.", "",
			labelText="Raycast Settings")]
		public LayerMask dropLayerMask = -1;

		[ORKEditorHelp("Distance", "The distance the raycast will use (from the camera).", "")]
		public float dropRayDistance = 100.0f;

		[ORKEditorHelp("From Root", "Drop interactions will be taken from the root game object of the game object something was dropped on.", "")]
		public bool dropInteractFromRoot = false;

		[ORKEditorHelp("In Children", "Drop interactions will also be taken from child objects of the game object something was dropped on.", "")]
		public bool dropInteractInChildren = true;

		[ORKEditorHelp("In Parent", "Drop interactions will also be taken from parent objects of the game object something was dropped on.", "")]
		[ORKEditorLayout("dropInteractFromRoot", false, endCheckGroup=true)]
		public bool dropInteractInParent = false;

		// drop on
		[ORKEditorHelp("Drop Give Player", "Dropping an item on members of the player group can give it to the combatant.", "")]
		[ORKEditorInfo(separator=true)]
		public bool dropGivePlayer = true;

		[ORKEditorHelp("Drop Give Allies", "Dropping an item on allies of the player group can give it to the combatant.", "")]
		public bool dropGiveAllies = true;

		[ORKEditorHelp("Drop Give Enemies", "Dropping an item on enemies of the player group can give it to the combatant.", "")]
		public bool dropGiveEnemies = true;

		// drag selections
		[ORKEditorHelp("Drag Set Selection", "Dragging a choice button will select it.", "")]
		[ORKEditorInfo(separator=true)]
		public bool dragSetSelection = false;

		[ORKEditorHelp("Drop Set Selection", "Dropping a drag on a choice button will select it.", "")]
		public bool dropSetSelection = false;

		[ORKEditorHelp("Block Tooltips", "Block tooltips while dragging.", "")]
		public bool dragBlockTooltips = false;

		[ORKEditorHelp("Drag Start Distance", "The distance the pressed down cursor has to be moved to start dragging.", "")]
		[ORKEditorLimit(1.0f, false)]
		public float dragStartDistance = 1;

		// drag notification
		[ORKEditorHelp("Show Drag", "Display a notification box while dragging.", "")]
		[ORKEditorInfo(separator=true, labelText="Dragging Notification")]
		public bool showDrag = true;

		[ORKEditorHelp("Drag Box", "Select the GUI box used to display drag information (e.g. name of an ability).", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("showDrag", true)]
		public int dragBoxID = 0;

		[ORKEditorHelp("Cancel Drag Key", "Select the input key used to cancel dragging.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int dragCancelKey = 0;

		// drag layout
		[ORKEditorHelp("Use Choice Layout", "Dragging a choice (e.g. in menus) will use the same layout/look as the dragged choice.", "")]
		[ORKEditorInfo("Drag Content Layout", "Define the layout of the drag info.", "")]
		public bool dragUseChoiceLayout = false;

		[ORKEditorInfo(separator=true, endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true)]
		public ContentLayout dragContentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.Info);


		// default GUI box settings
		// default skin settings
		[ORKEditorInfo("Default GUI Box Settings", "Define various default settings for GUI boxes.\n" +
			"Each GUI box can individually override these settings.", "",
			"Default GUI Skins", "Select the Unity GUISkins used to display GUI boxes.\n" +
			"These settings can be overridden by each GUI box individually.", "", endFoldout=true)]
		public GUIBoxSkins skins = new GUIBoxSkins();

		// default audio settings
		[ORKEditorInfo("Default Audio Settings", "The audio clips played when interacting with menus or dialogues (e.g. cursor move, accept).\n" +
			"You can set the volume of every clip.\n" +
			"These settings can be overridden by each GUI box individually.", "", endFoldout=true)]
		public MenuAudioClips audio = new MenuAudioClips();

		// default inactive colors
		[ORKEditorInfo("Default Inactive Colors", "GUI boxes that aren't focused (e.g. parts of menus or shops currently not in use) " +
			"can be tinted to give the user a better visual feedback of which box he is controlling.\n" +
			"This is only used for focusable (controlable) GUI boxes, i.e. HUDs or information menu/shop parts wont be tinted.\n" +
			"These settings can be overridden by each GUI box individually.", "", endFoldout=true)]
		public InactiveColor inactive = new InactiveColor();

		// default ok/cancel buttons
		[ORKEditorInfo("Default Ok/Cancel Buttons", "The default 'Ok' and 'Cancel' buttons are used in all GUI boxes that don't override the default settings.\n" +
			"The buttons are used in dialogues, questions (e.g. load/save) and quantity selections.", "", endFoldout=true)]
		public GUIBoxButtons okCancel = new GUIBoxButtons();

		// default portrait position
		[ORKEditorInfo("Default Portrait Position", "The default position of speaker portraits.\n" +
			"These settings can be overriden by GUI boxes, combatant portraits and the portrait settings in dialogue event steps.", "",
			endFoldout=true)]
		public PortraitPosition portraitPosition = new PortraitPosition();

		// header settings
		[ORKEditorInfo("Default Choice Header Settings", "The default choice header settings.\n" +
			"Header texts can optionally be displayed above choice buttons in menu screens, shops and battle menus." +
			"These settings can be overriden by each GUI box individually.", "",
			endFoldout=true)]
		public HeaderSettings headerSettings = new HeaderSettings();

		// default choice icon settings
		[ORKEditorInfo("Default Choice Icon Settings", "The default choice icon settings.\n" +
			"The choice icon is displayed at a currently selected choice.", "",
			endFoldout=true, endFolds=2)]
		public ChoiceIconSettings choiceIcon = new ChoiceIconSettings();


		// hud settings
		[ORKEditorHelp("HUD Effect Time", "The time in seconds used to display status effects in HUDs.\n" +
			"This is used to switch between the current status effects of a combatant, if only one effect " +
			"is displayed by a HUD, or if there are not enough cells to display all effects.", "")]
		[ORKEditorInfo("HUD Settings", "Base settings regarding HUDs.", "")]
		public float hudSETime = 2;

		[ORKEditorHelp("HUD Check Time", "The time in seconds used to check individual combatant HUDs.\n" +
			"The check will review faction and enemy state of the combatants and change the HUD accordingly.", "")]
		public float hudCheckTime = 1;

		[ORKEditorHelp("HUD Layer Mask", "Select the layers that will be checked for objects in HUDs.\n" +
			"This is used e.g. when a combatant's HUD is only displayed while the mouse is above it, " +
			"or the cursor changes of scene objects.", "")]
		public LayerMask hudMask = -1;

		[ORKEditorHelp("Raycast Distance", "The distance used by the raycast to determine the current HUD object.", "")]
		public float hudDistance = 100;

		[ORKEditorHelp("Use Turn Flash", "The HUD of a combatant who start's his turn will flash.", "")]
		[ORKEditorInfo(separator=true, labelText="Turn Flash HUD")]
		public bool useTurnFlash = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useTurnFlash", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings hudTurnFlash;


		// menu background
		[ORKEditorInfo("Menu Backgrounds", "Menu screens can display background images.\n" +
			"You can select the default backgrounds for all menu screens here.\n" +
			"Each menu screen can override the default background images.\n" +
			"General background images are displayed in all menu screens and can't be overridden. " +
			"They're displayed behind the default backgrounds.", "")]
		[ORKEditorArray(false, "Add Default Background", "Adds a default background image.", "",
			"Remove", "Removes this default background image.", "", foldout=true,
			foldoutText=new string[] {"Default Background", "Define the default background image that will be displayed.\n" +
				"Default backgrounds can be overridden by menu screens.", ""})]
		public BackgroundImage[] defaultMenuBG = new BackgroundImage[0];

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add General Background", "Adds a general background image.", "",
			"Remove", "Removes this general background image.", "", foldout=true,
			foldoutText=new string[] {"General Background", "Define the general background image that will be displayed in all menu screens.\n" +
				"This background can't be overridden and will be displayed behind the " +
				"default backgrounds or the menu screen's individual background.", ""})]
		public BackgroundImage[] generalMenuBG = new BackgroundImage[0];


		// shop background
		[ORKEditorInfo("Shop Backgrounds", "Shops can display background images.\n" +
			"You can select the default backgrounds for all shops here.\n" +
			"Each shop layout and shop can override the default background images.\n" +
			"General background images are displayed in all shops and can't be overridden. " +
			"They're displayed behind the default backgrounds.", "")]
		[ORKEditorArray(false, "Add Default Background", "Adds a default background image.", "",
			"Remove", "Removes this default background image.", "", foldout=true,
			foldoutText=new string[] {"Default Background", "Define the default background image that will be displayed.\n" +
				"Default backgrounds can be overridden by shop layouts and shops.", ""})]
		public BackgroundImage[] defaultShopBG = new BackgroundImage[0];

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add General Background", "Adds a general background image.", "",
			"Remove", "Removes this general background image.", "", foldout=true,
			foldoutText=new string[] {"General Background", "Define the general background image that will be displayed in all shops.\n" +
				"This background can't be overridden and will be displayed behind the " +
				"default backgrounds or the shop layout's or shop's individual background.", ""})]
		public BackgroundImage[] generalShopBG = new BackgroundImage[0];


		// save background
		[ORKEditorInfo("Save Backgrounds", "The save point, save and load menu can display background images.\n" +
			"You can select the default backgrounds for all save menus here.\n" +
			"Each save menu can override the default background images.\n" +
			"General background images are displayed in all save menus and can't be overridden. " +
			"They're displayed behind the default backgrounds.", "")]
		[ORKEditorArray(false, "Add Default Background", "Adds a default background image.", "",
			"Remove", "Removes this default background image.", "", foldout=true,
			foldoutText=new string[] {"Default Background", "Define the default background image that will be displayed.\n" +
				"Default backgrounds can be overridden by the save point, save and load menus.", ""})]
		public BackgroundImage[] defaultSaveBG = new BackgroundImage[0];

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add General Background", "Adds a general background image.", "",
			"Remove", "Removes this general background image.", "", foldout=true,
			foldoutText=new string[] {"General Background", "Define the general background image that will be displayed in save menus.\n" +
				"This background can't be overridden and will be displayed behind the " +
				"default backgrounds or the save point's, save or load menu's individual background.", ""})]
		public BackgroundImage[] generalSaveBG = new BackgroundImage[0];


		// buttons
		[ORKEditorInfo("Default Buttons", "Default button settings, the buttons are used system wide.", "",
			endFoldout=true)]
		public DefaultButtonSettings defaultButtons = new DefaultButtonSettings();


		// combatant choice
		// menu user
		[ORKEditorHelp("Menu User", "Used when the user of a menu is selected.", "")]
		[ORKEditorInfo("Default Combatant Selections", "Define the default combatant selection options.", "",
			ORKDataType.CombatantSelection)]
		public int comUserID = 0;

		// ability
		[ORKEditorHelp("Ability Target", "Used when the target of an ability is selected.", "")]
		[ORKEditorInfo(ORKDataType.CombatantSelection)]
		public int comAbilityID = 0;

		// item
		[ORKEditorHelp("Item Target", "Used when the target of an item is selected.", "")]
		[ORKEditorInfo(ORKDataType.CombatantSelection)]
		public int comItemID = 0;

		// equipment
		[ORKEditorHelp("Equip Target", "Used when equipping an equipment on another combatant.", "")]
		[ORKEditorInfo(ORKDataType.CombatantSelection)]
		public int comEquipID = 0;

		// give
		[ORKEditorHelp("Give Target", "Used when giving items to another combatant.", "")]
		[ORKEditorInfo(ORKDataType.CombatantSelection, endFoldout=true)]
		public int comGiveID = 0;


		// default quantity selections
		[ORKEditorInfo("Default Quantity Selections", "Define the default quantity selection options.", "",
			labelText="Remove Selection")]
		public QuantityDefault quantityRemove = new QuantityDefault();

		[ORKEditorInfo(separator=true, labelText="Drop Selection")]
		public QuantityDefault quantityDrop = new QuantityDefault();

		[ORKEditorInfo(separator=true, labelText="Give Selection")]
		public QuantityDefault quantityGive = new QuantityDefault();

		[ORKEditorInfo(separator=true, labelText="Buy Selection")]
		public QuantityDefault quantityBuy = new QuantityDefault();

		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Sell Quantity")]
		public QuantityDefault quantitySell = new QuantityDefault();


		// prefab view
		[ORKEditorInfo("Prefab View Settings", "These settings define how portraits using prefabs handled.", "",
			endFoldout=true)]
		public PrefabViewSettings prefabView = new PrefabViewSettings();

		public MenuSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("useCostDisplay"))
			{
				ORK.TextDisplaySettings.useCostDisplay.SetData(data.GetFile("useCostDisplay"));
				ORK.TextDisplaySettings.useCostDisplay.SetData(data.GetFile("bonusDisplay"));
				ORK.TextDisplaySettings.useCostDisplay.SetData(data.GetFile("targetInfoDisplay"));
				ORK.TextDisplaySettings.useCostDisplay.SetData(data.GetFile("combatantChoice"));
			}
			if(data.Contains<bool>("selectionTooltip"))
			{
				data.Get("selectionTooltip", ref this.tooltip.selectionTooltip);
			}
			this.defaultMaskMaterial.Upgrade(data, "defaultMaskMaterial");

			if(data.Contains<DataObject>("cursorSettings"))
			{
				ORK.CursorSettings.SetData(data.GetFile("cursorSettings"));
			}
			if(data.Contains<int>("dragCancelKeyID"))
			{
				data.Get("dragCancelKeyID", ref this.dragCancelKey);
			}
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "menuSettings"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public virtual bool CanGive(Combatant combatant)
		{
			if(combatant != null &&
				ORK.Game.ActiveGroup.Leader != null)
			{
				if(this.dropGivePlayer &&
					combatant.Group.IsPlayerGroup())
				{
					return true;
				}
				else if(combatant.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					return this.dropGiveEnemies;
				}
				else
				{
					return this.dropGiveAllies;
				}
			}
			return false;
		}
	}
}
