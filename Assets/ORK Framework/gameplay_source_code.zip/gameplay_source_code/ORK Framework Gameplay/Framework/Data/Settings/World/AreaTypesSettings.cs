
using UnityEngine;

namespace ORKFramework
{
	public class AreaTypesSettings : BaseLanguageSettings<AreaType>
	{
		public AreaTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "areaTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.AreaType; }
		}
	}
}

