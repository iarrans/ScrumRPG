
using UnityEngine;

namespace ORKFramework
{
	public class LogTypesSettings : BaseLanguageSettings<LogType>
	{
		public LogTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "logTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.LogType; }
		}
	}
}

