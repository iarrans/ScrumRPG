﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TextCodeSettings : BaseSettings
	{
		[ORKEditorArray(false, "Add Custom Text Code", "Adds a custom text code.", "",
			"Remove", "Removes this custom text code.", "",
			isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Custom Text Code", "Define the text code and its replacement text.", ""
		})]
		public CustomTextCode[] textCode = new CustomTextCode[0];

		public TextCodeSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "textCodes"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}


		/*
		============================================================================
		Text code functions
		============================================================================
		*/
		public string[] GetTextCodes()
		{
			string[] tmp = new string[this.textCode.Length];
			for(int i = 0; i < this.textCode.Length; i++)
			{
				tmp[i] = this.textCode[i].textCode;
			}
			return tmp;
		}

		public void ReplaceCustomTextCodes(ref string text)
		{
			for(int i = 0; i < this.textCode.Length; i++)
			{
				this.textCode[i].Replace(ref text);
			}
		}
	}
}
