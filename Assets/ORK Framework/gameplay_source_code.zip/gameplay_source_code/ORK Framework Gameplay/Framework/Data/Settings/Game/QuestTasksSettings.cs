
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class QuestTasksSettings : BaseLanguageSettings<QuestTaskSetting>
	{
		public QuestTasksSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "questTasks"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.QuestTask; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.QuestTypes.GetName(ORK.Quests.Get(this.data[i].questID).questTypeID) + "/" +
						ORK.Quests.GetName(this.data[i].questID) + "/" + i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}


		/*
		============================================================================
		Task functions
		============================================================================
		*/
		public List<int> GetQuestTasks(int questID)
		{
			List<int> list = new List<int>();

			for(int i = 0; i < this.data.Length; i++)
			{
				if(this.data[i].questID == questID)
				{
					list.Add(i);
				}
			}

			return list;
		}
	}
}
