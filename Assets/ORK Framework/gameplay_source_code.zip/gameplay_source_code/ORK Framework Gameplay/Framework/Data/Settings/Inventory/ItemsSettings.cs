
using UnityEngine;

namespace ORKFramework
{
	public class ItemsSettings : BaseLanguageSettings<Item>
	{
		public ItemsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "items"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Item; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.ItemTypes.GetName(this.data[i].itemType) + "/" + i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}
	}
}
