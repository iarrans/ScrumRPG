﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DataCache
	{
		public DataCache()
		{

		}

		private EditorSettings editorSettings;
		public EditorSettings EditorSettings
		{
			get
			{
				if(this.editorSettings == null)
				{
					this.editorSettings = ORKCore.Data.Get<EditorSettings>();
				}
				return this.editorSettings;
			}
		}

		private BackupSettings backups;
		public BackupSettings Backups
		{
			get
			{
				if(this.backups == null)
				{
					this.backups = ORKCore.Data.Get<BackupSettings>();
				}
				return this.backups;
			}
		}

		private PluginsSettings plugins;
		public PluginsSettings Plugins
		{
			get
			{
				if(this.plugins == null)
				{
					this.plugins = ORKCore.Data.Get<PluginsSettings>();
				}
				return this.plugins;
			}
		}

		private LanguagesSettings languages;
		public LanguagesSettings Languages
		{
			get
			{
				if(this.languages == null)
				{
					this.languages = ORKCore.Data.Get<LanguagesSettings>();
				}
				return this.languages;
			}
		}

		private ColorsSettings colors;
		public ColorsSettings Colors
		{
			get
			{
				if(this.colors == null)
				{
					this.colors = ORKCore.Data.Get<ColorsSettings>();
				}
				return this.colors;
			}
		}

		private InputKeysSettings inputKeys;
		public InputKeysSettings InputKeys
		{
			get
			{
				if(this.inputKeys == null)
				{
					this.inputKeys = ORKCore.Data.Get<InputKeysSettings>();
				}
				return this.inputKeys;
			}
		}

		private ControlMapsSettings controlMaps;
		public ControlMapsSettings ControlMaps
		{
			get
			{
				if(this.controlMaps == null)
				{
					this.controlMaps = ORKCore.Data.Get<ControlMapsSettings>();
				}
				return this.controlMaps;
			}
		}

		private FormulaTypesSettings formulaTypes;
		public FormulaTypesSettings FormulaTypes
		{
			get
			{
				if(this.formulaTypes == null)
				{
					this.formulaTypes = ORKCore.Data.Get<FormulaTypesSettings>();
				}
				return this.formulaTypes;
			}
		}

		private FormulasSettings formulas;
		public FormulasSettings Formulas
		{
			get
			{
				if(this.formulas == null)
				{
					this.formulas = ORKCore.Data.Get<FormulasSettings>();
				}
				return this.formulas;
			}
		}

		private RequirementsSettings requirements;
		public RequirementsSettings Requirements
		{
			get
			{
				if(this.requirements == null)
				{
					this.requirements = ORKCore.Data.Get<RequirementsSettings>();
				}
				return this.requirements;
			}
		}

		private AnimationTypesSettings animationTypes;
		public AnimationTypesSettings AnimationTypes
		{
			get
			{
				if(this.animationTypes == null)
				{
					this.animationTypes = ORKCore.Data.Get<AnimationTypesSettings>();
				}
				return this.animationTypes;
			}
		}

		private AnimationsSettings animations;
		public AnimationsSettings Animations
		{
			get
			{
				if(this.animations == null)
				{
					this.animations = ORKCore.Data.Get<AnimationsSettings>();
				}
				return this.animations;
			}
		}

		private DamageTypesSettings damageTypes;
		public DamageTypesSettings DamageTypes
		{
			get
			{
				if(this.damageTypes == null)
				{
					this.damageTypes = ORKCore.Data.Get<DamageTypesSettings>();
				}
				return this.damageTypes;
			}
		}

		private SoundTypesSettings soundTypes;
		public SoundTypesSettings SoundTypes
		{
			get
			{
				if(this.soundTypes == null)
				{
					this.soundTypes = ORKCore.Data.Get<SoundTypesSettings>();
				}
				return this.soundTypes;
			}
		}

		private PortraitTypesSettings portraitTypes;
		public PortraitTypesSettings PortraitTypes
		{
			get
			{
				if(this.portraitTypes == null)
				{
					this.portraitTypes = ORKCore.Data.Get<PortraitTypesSettings>();
				}
				return this.portraitTypes;
			}
		}

		private VariableConditionTemplatesSettings variableConditionTemplates;
		public VariableConditionTemplatesSettings VariableConditionTemplates
		{
			get
			{
				if(this.variableConditionTemplates == null)
				{
					this.variableConditionTemplates = ORKCore.Data.Get<VariableConditionTemplatesSettings>();
				}
				return this.variableConditionTemplates;
			}
		}

		private StatusRequirementTemplatesSettings statusRequirementTemplates;
		public StatusRequirementTemplatesSettings StatusRequirementTemplates
		{
			get
			{
				if(this.statusRequirementTemplates == null)
				{
					this.statusRequirementTemplates = ORKCore.Data.Get<StatusRequirementTemplatesSettings>();
				}
				return this.statusRequirementTemplates;
			}
		}

		private ConsoleTypesSettings consoleTypes;
		public ConsoleTypesSettings ConsoleTypes
		{
			get
			{
				if(this.consoleTypes == null)
				{
					this.consoleTypes = ORKCore.Data.Get<ConsoleTypesSettings>();
				}
				return this.consoleTypes;
			}
		}

		private DifficultiesSettings difficulties;
		public DifficultiesSettings Difficulties
		{
			get
			{
				if(this.difficulties == null)
				{
					this.difficulties = ORKCore.Data.Get<DifficultiesSettings>();
				}
				return this.difficulties;
			}
		}

		private GameSettings gameSettings;
		public GameSettings GameSettings
		{
			get
			{
				if(this.gameSettings == null)
				{
					this.gameSettings = ORKCore.Data.Get<GameSettings>();
				}
				return this.gameSettings;
			}
		}

		private ConsoleSettings consoleSettings;
		public ConsoleSettings ConsoleSettings
		{
			get
			{
				if(this.consoleSettings == null)
				{
					this.consoleSettings = ORKCore.Data.Get<ConsoleSettings>();
				}
				return this.consoleSettings;
			}
		}

		private GameControlsSettings gameControls;
		public GameControlsSettings GameControls
		{
			get
			{
				if(this.gameControls == null)
				{
					this.gameControls = ORKCore.Data.Get<GameControlsSettings>();
				}
				return this.gameControls;
			}
		}

		private SceneConnectionSettings sceneConnections;
		public SceneConnectionSettings SceneConnections
		{
			get
			{
				if(this.sceneConnections == null)
				{
					this.sceneConnections = ORKCore.Data.Get<SceneConnectionSettings>();
				}
				return this.sceneConnections;
			}
		}

		private AreaTypesSettings areaTypes;
		public AreaTypesSettings AreaTypes
		{
			get
			{
				if(this.areaTypes == null)
				{
					this.areaTypes = ORKCore.Data.Get<AreaTypesSettings>();
				}
				return this.areaTypes;
			}
		}

		private AreasSettings areas;
		public AreasSettings Areas
		{
			get
			{
				if(this.areas == null)
				{
					this.areas = ORKCore.Data.Get<AreasSettings>();
				}
				return this.areas;
			}
		}

		private TeleportsSettings teleports;
		public TeleportsSettings Teleports
		{
			get
			{
				if(this.teleports == null)
				{
					this.teleports = ORKCore.Data.Get<TeleportsSettings>();
				}
				return this.teleports;
			}
		}

		private CameraPositionsSettings cameraPositions;
		public CameraPositionsSettings CameraPositions
		{
			get
			{
				if(this.cameraPositions == null)
				{
					this.cameraPositions = ORKCore.Data.Get<CameraPositionsSettings>();
				}
				return this.cameraPositions;
			}
		}

		private MusicClipsSettings musicClips;
		public MusicClipsSettings MusicClips
		{
			get
			{
				if(this.musicClips == null)
				{
					this.musicClips = ORKCore.Data.Get<MusicClipsSettings>();
				}
				return this.musicClips;
			}
		}

		private GlobalEventsSettings globalEvents;
		public GlobalEventsSettings GlobalEvents
		{
			get
			{
				if(this.globalEvents == null)
				{
					this.globalEvents = ORKCore.Data.Get<GlobalEventsSettings>();
				}
				return this.globalEvents;
			}
		}

		private AttackAttributesSettings attackAttributes;
		public AttackAttributesSettings AttackAttributes
		{
			get
			{
				if(this.attackAttributes == null)
				{
					this.attackAttributes = ORKCore.Data.Get<AttackAttributesSettings>();
				}
				return this.attackAttributes;
			}
		}

		private DefenceAttributesSettings defenceAttributes;
		public DefenceAttributesSettings DefenceAttributes
		{
			get
			{
				if(this.defenceAttributes == null)
				{
					this.defenceAttributes = ORKCore.Data.Get<DefenceAttributesSettings>();
				}
				return this.defenceAttributes;
			}
		}

		private StatusTypesSettings statusTypes;
		public StatusTypesSettings StatusTypes
		{
			get
			{
				if(this.statusTypes == null)
				{
					this.statusTypes = ORKCore.Data.Get<StatusTypesSettings>();
				}
				return this.statusTypes;
			}
		}

		private StatusValuesSettings statusValues;
		public StatusValuesSettings StatusValues
		{
			get
			{
				if(this.statusValues == null)
				{
					this.statusValues = ORKCore.Data.Get<StatusValuesSettings>();
				}
				return this.statusValues;
			}
		}

		private StatusEffectTypesSettings statusEffectTypes;
		public StatusEffectTypesSettings StatusEffectTypes
		{
			get
			{
				if(this.statusEffectTypes == null)
				{
					this.statusEffectTypes = ORKCore.Data.Get<StatusEffectTypesSettings>();
				}
				return this.statusEffectTypes;
			}
		}

		private StatusEffectsSettings statusEffects;
		public StatusEffectsSettings StatusEffects
		{
			get
			{
				if(this.statusEffects == null)
				{
					this.statusEffects = ORKCore.Data.Get<StatusEffectsSettings>();
				}
				return this.statusEffects;
			}
		}

		private StatusBonusesSettings statusBonuses;
		public StatusBonusesSettings StatusBonuses
		{
			get
			{
				if(this.statusBonuses == null)
				{
					this.statusBonuses = ORKCore.Data.Get<StatusBonusesSettings>();
				}
				return this.statusBonuses;
			}
		}

		private AbilityTypesSettings abilityTypes;
		public AbilityTypesSettings AbilityTypes
		{
			get
			{
				if(this.abilityTypes == null)
				{
					this.abilityTypes = ORKCore.Data.Get<AbilityTypesSettings>();
				}
				return this.abilityTypes;
			}
		}

		private AbilitiesSettings abilities;
		public AbilitiesSettings Abilities
		{
			get
			{
				if(this.abilities == null)
				{
					this.abilities = ORKCore.Data.Get<AbilitiesSettings>();
				}
				return this.abilities;
			}
		}

		private AbilityTreesSettings abilityTrees;
		public AbilityTreesSettings AbilityTrees
		{
			get
			{
				if(this.abilityTrees == null)
				{
					this.abilityTrees = ORKCore.Data.Get<AbilityTreesSettings>();
				}
				return this.abilityTrees;
			}
		}

		private StatusDevelopmentsSettings statusDevelopments;
		public StatusDevelopmentsSettings StatusDevelopments
		{
			get
			{
				if(this.statusDevelopments == null)
				{
					this.statusDevelopments = ORKCore.Data.Get<StatusDevelopmentsSettings>();
				}
				return this.statusDevelopments;
			}
		}

		private AbilityDevelopmentsSettings abilityDevelopments;
		public AbilityDevelopmentsSettings AbilityDevelopments
		{
			get
			{
				if(this.abilityDevelopments == null)
				{
					this.abilityDevelopments = ORKCore.Data.Get<AbilityDevelopmentsSettings>();
				}
				return this.abilityDevelopments;
			}
		}

		private InventorySettings inventorySettings;
		public InventorySettings InventorySettings
		{
			get
			{
				if(this.inventorySettings == null)
				{
					this.inventorySettings = ORKCore.Data.Get<InventorySettings>();
				}
				return this.inventorySettings;
			}
		}

		private ItemTypesSettings itemTypes;
		public ItemTypesSettings ItemTypes
		{
			get
			{
				if(this.itemTypes == null)
				{
					this.itemTypes = ORKCore.Data.Get<ItemTypesSettings>();
				}
				return this.itemTypes;
			}
		}

		private CurrenciesSettings currencies;
		public CurrenciesSettings Currencies
		{
			get
			{
				if(this.currencies == null)
				{
					this.currencies = ORKCore.Data.Get<CurrenciesSettings>();
				}
				return this.currencies;
			}
		}

		private ItemsSettings items;
		public ItemsSettings Items
		{
			get
			{
				if(this.items == null)
				{
					this.items = ORKCore.Data.Get<ItemsSettings>();
				}
				return this.items;
			}
		}

		private EquipmentPartsSettings equipmentParts;
		public EquipmentPartsSettings EquipmentParts
		{
			get
			{
				if(this.equipmentParts == null)
				{
					this.equipmentParts = ORKCore.Data.Get<EquipmentPartsSettings>();
				}
				return this.equipmentParts;
			}
		}

		private WeaponsSettings weapons;
		public WeaponsSettings Weapons
		{
			get
			{
				if(this.weapons == null)
				{
					this.weapons = ORKCore.Data.Get<WeaponsSettings>();
				}
				return this.weapons;
			}
		}

		private ArmorsSettings armors;
		public ArmorsSettings Armors
		{
			get
			{
				if(this.armors == null)
				{
					this.armors = ORKCore.Data.Get<ArmorsSettings>();
				}
				return this.armors;
			}
		}

		private CraftingTypesSettings craftingTypes;
		public CraftingTypesSettings CraftingTypes
		{
			get
			{
				if(this.craftingTypes == null)
				{
					this.craftingTypes = ORKCore.Data.Get<CraftingTypesSettings>();
				}
				return this.craftingTypes;
			}
		}

		private CraftingRecipesSettings craftingRecipes;
		public CraftingRecipesSettings CraftingRecipes
		{
			get
			{
				if(this.craftingRecipes == null)
				{
					this.craftingRecipes = ORKCore.Data.Get<CraftingRecipesSettings>();
				}
				return this.craftingRecipes;
			}
		}

		private FactionsSettings factions;
		public FactionsSettings Factions
		{
			get
			{
				if(this.factions == null)
				{
					this.factions = ORKCore.Data.Get<FactionsSettings>();
				}
				return this.factions;
			}
		}

		private FactionBenefitsSettings factionBenefits;
		public FactionBenefitsSettings FactionBenefits
		{
			get
			{
				if(this.factionBenefits == null)
				{
					this.factionBenefits = ORKCore.Data.Get<FactionBenefitsSettings>();
				}
				return this.factionBenefits;
			}
		}

		private FactionSympathySettings factionSympathy;
		public FactionSympathySettings FactionSympathy
		{
			get
			{
				if(this.factionSympathy == null)
				{
					this.factionSympathy = ORKCore.Data.Get<FactionSympathySettings>();
				}
				return this.factionSympathy;
			}
		}

		private ClassesSettings classes;
		public ClassesSettings Classes
		{
			get
			{
				if(this.classes == null)
				{
					this.classes = ORKCore.Data.Get<ClassesSettings>();
				}
				return this.classes;
			}
		}

		private BattleAIsSettings battleAIs;
		public BattleAIsSettings BattleAIs
		{
			get
			{
				if(this.battleAIs == null)
				{
					this.battleAIs = ORKCore.Data.Get<BattleAIsSettings>();
				}
				return this.battleAIs;
			}
		}

		private ActionCombosSettings actionCombos;
		public ActionCombosSettings ActionCombos
		{
			get
			{
				if(this.actionCombos == null)
				{
					this.actionCombos = ORKCore.Data.Get<ActionCombosSettings>();
				}
				return this.actionCombos;
			}
		}

		private AITypesSettings aiTypes;
		public AITypesSettings AITypes
		{
			get
			{
				if(this.aiTypes == null)
				{
					this.aiTypes = ORKCore.Data.Get<AITypesSettings>();
				}
				return this.aiTypes;
			}
		}

		private AIBehavioursSettings aiBehaviours;
		public AIBehavioursSettings AIBehaviours
		{
			get
			{
				if(this.aiBehaviours == null)
				{
					this.aiBehaviours = ORKCore.Data.Get<AIBehavioursSettings>();
				}
				return this.aiBehaviours;
			}
		}

		private AIRulesetsSettings aiRulesets;
		public AIRulesetsSettings AIRulesets
		{
			get
			{
				if(this.aiRulesets == null)
				{
					this.aiRulesets = ORKCore.Data.Get<AIRulesetsSettings>();
				}
				return this.aiRulesets;
			}
		}

		private BattleGridCellTypesSettings battleGridCellTypes;
		public BattleGridCellTypesSettings BattleGridCellTypes
		{
			get
			{
				if(this.battleGridCellTypes == null)
				{
					this.battleGridCellTypes = ORKCore.Data.Get<BattleGridCellTypesSettings>();
				}
				return this.battleGridCellTypes;
			}
		}

		private BattleRangeTemplatesSettings battleRangeTemplates;
		public BattleRangeTemplatesSettings BattleRangeTemplates
		{
			get
			{
				if(this.battleRangeTemplates == null)
				{
					this.battleRangeTemplates = ORKCore.Data.Get<BattleRangeTemplatesSettings>();
				}
				return this.battleRangeTemplates;
			}
		}

		private FormationsSettings formations;
		public FormationsSettings Formations
		{
			get
			{
				if(this.formations == null)
				{
					this.formations = ORKCore.Data.Get<FormationsSettings>();
				}
				return this.formations;
			}
		}

		private BattleGridFormationsSettings battleGridFormations;
		public BattleGridFormationsSettings BattleGridFormations
		{
			get
			{
				if(this.battleGridFormations == null)
				{
					this.battleGridFormations = ORKCore.Data.Get<BattleGridFormationsSettings>();
				}
				return this.battleGridFormations;
			}
		}

		private CombatantTypesSettings combatantTypes;
		public CombatantTypesSettings CombatantTypes
		{
			get
			{
				if(this.combatantTypes == null)
				{
					this.combatantTypes = ORKCore.Data.Get<CombatantTypesSettings>();
				}
				return this.combatantTypes;
			}
		}

		private CombatantsSettings combatants;
		public CombatantsSettings Combatants
		{
			get
			{
				if(this.combatants == null)
				{
					this.combatants = ORKCore.Data.Get<CombatantsSettings>();
				}
				return this.combatants;
			}
		}

		private CombatantGroupsSettings combatantGroups;
		public CombatantGroupsSettings CombatantGroups
		{
			get
			{
				if(this.combatantGroups == null)
				{
					this.combatantGroups = ORKCore.Data.Get<CombatantGroupsSettings>();
				}
				return this.combatantGroups;
			}
		}

		private MoveAIsSettings moveAIs;
		public MoveAIsSettings MoveAIs
		{
			get
			{
				if(this.moveAIs == null)
				{
					this.moveAIs = ORKCore.Data.Get<MoveAIsSettings>();
				}
				return this.moveAIs;
			}
		}

		private LootSettings loot;
		public LootSettings Loot
		{
			get
			{
				if(this.loot == null)
				{
					this.loot = ORKCore.Data.Get<LootSettings>();
				}
				return this.loot;
			}
		}

		private ResearchTypesSettings researchTypes;
		public ResearchTypesSettings ResearchTypes
		{
			get
			{
				if(this.researchTypes == null)
				{
					this.researchTypes = ORKCore.Data.Get<ResearchTypesSettings>();
				}
				return this.researchTypes;
			}
		}

		private ResearchTreesSettings researchTrees;
		public ResearchTreesSettings ResearchTrees
		{
			get
			{
				if(this.researchTrees == null)
				{
					this.researchTrees = ORKCore.Data.Get<ResearchTreesSettings>();
				}
				return this.researchTrees;
			}
		}

		private BattleTargetSettings targetSettings;
		public BattleTargetSettings TargetSettings
		{
			get
			{
				if(this.targetSettings == null)
				{
					this.targetSettings = ORKCore.Data.Get<BattleTargetSettings>();
				}
				return this.targetSettings;
			}
		}

		private BattleCameraSettings battleCamera;
		public BattleCameraSettings BattleCamera
		{
			get
			{
				if(this.battleCamera == null)
				{
					this.battleCamera = ORKCore.Data.Get<BattleCameraSettings>();
				}
				return this.battleCamera;
			}
		}

		private BattleSettings battleSettings;
		public BattleSettings BattleSettings
		{
			get
			{
				if(this.battleSettings == null)
				{
					this.battleSettings = ORKCore.Data.Get<BattleSettings>();
				}
				return this.battleSettings;
			}
		}

		private BattleSystemSettings battleSystem;
		public BattleSystemSettings BattleSystem
		{
			get
			{
				if(this.battleSystem == null)
				{
					this.battleSystem = ORKCore.Data.Get<BattleSystemSettings>();
				}
				return this.battleSystem;
			}
		}

		private BattleSpotsSettings battleSpots;
		public BattleSpotsSettings BattleSpots
		{
			get
			{
				if(this.battleSpots == null)
				{
					this.battleSpots = ORKCore.Data.Get<BattleSpotsSettings>();
				}
				return this.battleSpots;
			}
		}

		private BattleMenusSettings battleMenus;
		public BattleMenusSettings BattleMenus
		{
			get
			{
				if(this.battleMenus == null)
				{
					this.battleMenus = ORKCore.Data.Get<BattleMenusSettings>();
				}
				return this.battleMenus;
			}
		}

		private BattleTextsSettings battleTexts;
		public BattleTextsSettings BattleTexts
		{
			get
			{
				if(this.battleTexts == null)
				{
					this.battleTexts = ORKCore.Data.Get<BattleTextsSettings>();
				}
				return this.battleTexts;
			}
		}

		private BattleEndSettings battleEnd;
		public BattleEndSettings BattleEnd
		{
			get
			{
				if(this.battleEnd == null)
				{
					this.battleEnd = ORKCore.Data.Get<BattleEndSettings>();
				}
				return this.battleEnd;
			}
		}

		private GUILayersSettings guiLayers;
		public GUILayersSettings GUILayers
		{
			get
			{
				if(this.guiLayers == null)
				{
					this.guiLayers = ORKCore.Data.Get<GUILayersSettings>();
				}
				return this.guiLayers;
			}
		}

		private GUILayoutsSettings guiLayouts;
		public GUILayoutsSettings GUILayouts
		{
			get
			{
				if(this.guiLayouts == null)
				{
					this.guiLayouts = ORKCore.Data.Get<GUILayoutsSettings>();
				}
				return this.guiLayouts;
			}
		}

		private GUIBoxesSettings guiBoxes;
		public GUIBoxesSettings GUIBoxes
		{
			get
			{
				if(this.guiBoxes == null)
				{
					this.guiBoxes = ORKCore.Data.Get<GUIBoxesSettings>();
				}
				return this.guiBoxes;
			}
		}

		private MainMenuSettings mainMenu;
		public MainMenuSettings MainMenu
		{
			get
			{
				if(this.mainMenu == null)
				{
					this.mainMenu = ORKCore.Data.Get<MainMenuSettings>();
				}
				return this.mainMenu;
			}
		}

		private SaveGameMenuSettings saveGameMenu;
		public SaveGameMenuSettings SaveGameMenu
		{
			get
			{
				if(this.saveGameMenu == null)
				{
					this.saveGameMenu = ORKCore.Data.Get<SaveGameMenuSettings>();
				}
				return this.saveGameMenu;
			}
		}

		private LogTypesSettings logTypes;
		public LogTypesSettings LogTypes
		{
			get
			{
				if(this.logTypes == null)
				{
					this.logTypes = ORKCore.Data.Get<LogTypesSettings>();
				}
				return this.logTypes;
			}
		}

		private LogsSettings logs;
		public LogsSettings Logs
		{
			get
			{
				if(this.logs == null)
				{
					this.logs = ORKCore.Data.Get<LogsSettings>();
				}
				return this.logs;
			}
		}

		private LogTextsSettings logTexts;
		public LogTextsSettings LogTexts
		{
			get
			{
				if(this.logTexts == null)
				{
					this.logTexts = ORKCore.Data.Get<LogTextsSettings>();
				}
				return this.logTexts;
			}
		}

		private SceneObjectTypesSettings sceneObjectTypes;
		public SceneObjectTypesSettings SceneObjectTypes
		{
			get
			{
				if(this.sceneObjectTypes == null)
				{
					this.sceneObjectTypes = ORKCore.Data.Get<SceneObjectTypesSettings>();
				}
				return this.sceneObjectTypes;
			}
		}

		private SceneObjectsSettings sceneObjects;
		public SceneObjectsSettings SceneObjects
		{
			get
			{
				if(this.sceneObjects == null)
				{
					this.sceneObjects = ORKCore.Data.Get<SceneObjectsSettings>();
				}
				return this.sceneObjects;
			}
		}

		private QuestSettings questSettings;
		public QuestSettings QuestSettings
		{
			get
			{
				if(this.questSettings == null)
				{
					this.questSettings = ORKCore.Data.Get<QuestSettings>();
				}
				return this.questSettings;
			}
		}

		private QuestTypesSettings questTypes;
		public QuestTypesSettings QuestTypes
		{
			get
			{
				if(this.questTypes == null)
				{
					this.questTypes = ORKCore.Data.Get<QuestTypesSettings>();
				}
				return this.questTypes;
			}
		}

		private QuestsSettings quests;
		public QuestsSettings Quests
		{
			get
			{
				if(this.quests == null)
				{
					this.quests = ORKCore.Data.Get<QuestsSettings>();
				}
				return this.quests;
			}
		}

		private QuestTasksSettings questTasks;
		public QuestTasksSettings QuestTasks
		{
			get
			{
				if(this.questTasks == null)
				{
					this.questTasks = ORKCore.Data.Get<QuestTasksSettings>();
				}
				return this.questTasks;
			}
		}

		private TextDisplaySettings textDisplaySettings;
		public TextDisplaySettings TextDisplaySettings
		{
			get
			{
				if(this.textDisplaySettings == null)
				{
					this.textDisplaySettings = ORKCore.Data.Get<TextDisplaySettings>();
				}
				return this.textDisplaySettings;
			}
		}

		private CursorSettings cursorSettings;
		public CursorSettings CursorSettings
		{
			get
			{
				if(this.cursorSettings == null)
				{
					this.cursorSettings = ORKCore.Data.Get<CursorSettings>();
				}
				return this.cursorSettings;
			}
		}

		private MenuSettings menuSettings;
		public MenuSettings MenuSettings
		{
			get
			{
				if(this.menuSettings == null)
				{
					this.menuSettings = ORKCore.Data.Get<MenuSettings>();
				}
				return this.menuSettings;
			}
		}

		private TextCodeSettings textCodes;
		public TextCodeSettings TextCodes
		{
			get
			{
				if(this.textCodes == null)
				{
					this.textCodes = ORKCore.Data.Get<TextCodeSettings>();
				}
				return this.textCodes;
			}
		}

		private CombatantSelectionsSettings combatantSelections;
		public CombatantSelectionsSettings CombatantSelections
		{
			get
			{
				if(this.combatantSelections == null)
				{
					this.combatantSelections = ORKCore.Data.Get<CombatantSelectionsSettings>();
				}
				return this.combatantSelections;
			}
		}

		private QuantitySelectionsSettings quantitySelections;
		public QuantitySelectionsSettings QuantitySelections
		{
			get
			{
				if(this.quantitySelections == null)
				{
					this.quantitySelections = ORKCore.Data.Get<QuantitySelectionsSettings>();
				}
				return this.quantitySelections;
			}
		}

		private ShortcutSettings shortcutSettings;
		public ShortcutSettings ShortcutSettings
		{
			get
			{
				if(this.shortcutSettings == null)
				{
					this.shortcutSettings = ORKCore.Data.Get<ShortcutSettings>();
				}
				return this.shortcutSettings;
			}
		}

		private MenuScreensSettings menuScreens;
		public MenuScreensSettings MenuScreens
		{
			get
			{
				if(this.menuScreens == null)
				{
					this.menuScreens = ORKCore.Data.Get<MenuScreensSettings>();
				}
				return this.menuScreens;
			}
		}

		private HUDsSettings huds;
		public HUDsSettings HUDs
		{
			get
			{
				if(this.huds == null)
				{
					this.huds = ORKCore.Data.Get<HUDsSettings>();
				}
				return this.huds;
			}
		}

		private ShopLayoutsSettings shopLayouts;
		public ShopLayoutsSettings ShopLayouts
		{
			get
			{
				if(this.shopLayouts == null)
				{
					this.shopLayouts = ORKCore.Data.Get<ShopLayoutsSettings>();
				}
				return this.shopLayouts;
			}
		}

		private ShopsSettings shops;
		public ShopsSettings Shops
		{
			get
			{
				if(this.shops == null)
				{
					this.shops = ORKCore.Data.Get<ShopsSettings>();
				}
				return this.shops;
			}
		}
	}
}
