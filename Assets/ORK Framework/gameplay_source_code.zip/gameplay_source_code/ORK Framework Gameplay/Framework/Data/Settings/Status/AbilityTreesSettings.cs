
using UnityEngine;

namespace ORKFramework
{
	public class AbilityTreesSettings : BaseLanguageSettings<AbilityTree>
	{
		public AbilityTreesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "abilityTrees"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.AbilityTree; }
		}
		
		
		/*
		============================================================================
		Add, remove callbacks
		============================================================================
		*/
		public void SetStatusValueType(int index, StatusValueType val)
		{
			for(int i=0; i<this.data.Length; i++)
			{
				for(int j=0; j<this.data[i].ability.Length; j++)
				{
					for(int k=0; k<this.data[i].ability[j].learnCost.Length; k++)
					{
						if(this.data[i].ability[j].learnCost[k].statusID == index)
						{
							ArrayHelper.RemoveAt(ref this.data[i].ability[j].learnCost, k--);
						}
					}
				}
			}
		}
	}
}
