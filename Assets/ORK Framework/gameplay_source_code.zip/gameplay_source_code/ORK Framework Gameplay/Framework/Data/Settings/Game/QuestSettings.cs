﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class QuestSettings : BaseSettings
	{
		// quest settings
		[ORKEditorHelp("Active Quests", "Define the number of quests that can be active at the same time.\n" +
			"If the number of active quests is succeeded (e.g. by activating an inactive quest or adding a new quest), " +
			"one of the currently active quests will be set inactive.", "")]
		[ORKEditorInfo("Quest Settings", "The basic quest settings are defined here.", "")]
		[ORKEditorLimit(1, false)]
		public int activeQuests = 5;

		[ORKEditorHelp("Display Initial Tasks", "Display the notifications of a quest's initial tasks when adding the quest.\n" +
			"Initial tasks are tasks that will be activated when the quest is added.", "")]
		public bool displayInitialTasks = false;

		[ORKEditorHelp("Queue Quest Notifications", "Select how multiple notifications are displayed:\n" +
			"- Add: Notifications are displayed immediately while previous notifications are still displayed.\n" +
			"- Replace: Notifications are displayed immediately, closing the previous notification.\n" +
			"- Queue: Notifications are queued, displaying them after previous notifications where closed.", "")]
		public NotificationQueueType queueQuestNotifications = NotificationQueueType.Queue;

		[ORKEditorHelp("Queue Task Notifications", "Select how multiple notifications are displayed:\n" +
			"- Add: Notifications are displayed immediately while previous notifications are still displayed.\n" +
			"- Replace: Notifications are displayed immediately, closing the previous notification.\n" +
			"- Queue: Notifications are queued, displaying them after previous notifications where closed.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public NotificationQueueType queueTaskNotifications = NotificationQueueType.Queue;


		// default quest layout
		[ORKEditorInfo("Default Quest Layout", "The quest layout is used to display " +
			"quest information (e.g. tasks, rewards) in menus and dialogues." +
			"The default quest layout can be overridden by each quest individually.", "",
			endFoldout=true)]
		public QuestLayout questLayout = new QuestLayout();


		// quest notifications
		public QuestNotificationSettings questNotifications = new QuestNotificationSettings();

		public QuestSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("queueQuestNotifications"))
			{
				bool tmp = false;
				data.Get("queueQuestNotifications", ref tmp);
				this.queueQuestNotifications = tmp ? NotificationQueueType.Queue : NotificationQueueType.Replace;
			}
			if(data.Contains<bool>("queueTaskNotifications"))
			{
				bool tmp = false;
				data.Get("queueTaskNotifications", ref tmp);
				this.queueTaskNotifications = tmp ? NotificationQueueType.Queue : NotificationQueueType.Replace;
			}
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "questSettings"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}
	}
}
