﻿
using UnityEngine;

namespace ORKFramework
{
	public class ResearchTypesSettings : BaseLanguageSettings<ResearchType>
	{
		public ResearchTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "researchTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.ResearchType; }
		}
	}
}
