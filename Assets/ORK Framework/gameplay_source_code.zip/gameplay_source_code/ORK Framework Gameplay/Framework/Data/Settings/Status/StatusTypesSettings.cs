﻿
using UnityEngine;

namespace ORKFramework
{
	public class StatusTypesSettings : BaseLanguageSettings<StatusType>
	{
		public StatusTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "statusTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.StatusType; }
		}
	}
}

