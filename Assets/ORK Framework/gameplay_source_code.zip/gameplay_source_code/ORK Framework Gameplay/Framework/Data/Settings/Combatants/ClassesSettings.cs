
using UnityEngine;

namespace ORKFramework
{
	public class ClassesSettings : BaseLanguageSettings<Class>
	{
		public ClassesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "classes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Class; }
		}
	}
}
