
using UnityEngine;

namespace ORKFramework
{
	public class WeaponsSettings : BaseLanguageSettings<Weapon>
	{
		public WeaponsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "weapons"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.Weapon; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i = 0; i < names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.ItemTypes.GetName(this.data[i].itemType) + "/" + i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}
	}
}
