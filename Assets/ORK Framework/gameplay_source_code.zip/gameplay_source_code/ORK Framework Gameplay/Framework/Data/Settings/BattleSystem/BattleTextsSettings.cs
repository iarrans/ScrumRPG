
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleTextsSettings : BaseSettings
	{
		// general settings
		[ORKEditorHelp("Default GUISkin", "The GUISkin used to display the damage/refresh and other texts " +
			"(e.g. level up, etc.).", "")]
		[ORKEditorInfo("Text Settings", "Base text and display settings.", "")]
		[ORKEditorLayout("gui:legacy", endCheckGroup=true)]
		public AssetSource<GUISkin> textSkin = new AssetSource<GUISkin>();

		// choice/action content info
		// combatant group choices
		[ORKEditorInfo("All Allies Choice", "Name, description and icon for the choice to target all allies.", "",
			endFoldout=true)]
		public ContentButton allAlliesButton = new ContentButton("All Allies");

		[ORKEditorInfo("All Enemies Choice", "Name, description and icon for the choice to target all enemies.", "",
			endFoldout=true)]
		public ContentButton allEnemiesButton = new ContentButton("All Enemies");

		[ORKEditorInfo("All Combatants Choice", "Name, description and icon for the choice to target all combatants.", "",
			endFoldout=true)]
		public ContentButton allCombatantsButton = new ContentButton("All Combatants");

		// special actions
		[ORKEditorInfo("Escape Command", "Name, description and icon for the escape command.", "",
			endFoldout=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageContent[] escapeCommandText = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count,
			new System.Type[] {typeof(string)}, new System.Object[] {"Escape"});

		[ORKEditorInfo("Defend Command", "Name, description and icon for the defend command.", "",
			endFoldout=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageContent[] defendCommandText = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count,
			new System.Type[] {typeof(string)}, new System.Object[] {"Defend"});

		[ORKEditorInfo("None Command", "Name, description and icon for the none command (end turn).", "",
			endFoldout=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageContent[] noneCommandText = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count,
			new System.Type[] {typeof(string)}, new System.Object[] {"End Turn"});

		[ORKEditorInfo("Grid Move Command", "Name, description and icon for the grid move command.", "",
			endFoldout=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageContent[] gridMoveCommandText = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count,
			new System.Type[] {typeof(string)}, new System.Object[] {"Move"});

		[ORKEditorInfo("Grid Orientation Command", "Name, description and icon for the grid orientation command.", "",
			endFoldout=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageContent[] gridOrientationCommandText = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count,
			new System.Type[] {typeof(string)}, new System.Object[] {"Rotate"});

		[ORKEditorInfo("Grid Examine Command", "Name, description and icon for the grid examine command.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageContent[] gridExamineCommandText = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count,
			new System.Type[] {typeof(string)}, new System.Object[] {"Examine"});


		// info text settings
		[ORKEditorHelp("Show Info", "Info texts will be displayed.", "")]
		[ORKEditorInfo("Info Text Settings", "Info texts display information about " +
			"the battle action currently used by a combatant.", "")]
		public bool showInfo = true;

		[ORKEditorHelp("Queue Infos", "Select how info texts are displayed:\n" +
			"- Add: Info texts are displayed immediately while previous notifications are still displayed.\n" +
			"- Replace: Info texts are displayed immediately, closing the previous notification.\n" +
			"- Queue: Info texts are queued, displaying them after previous notifications where closed.", "")]
		[ORKEditorLayout("showInfo", true)]
		public NotificationQueueType queueInfos = NotificationQueueType.Queue;

		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the info texts.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int infoBoxID = 0;

		[ORKEditorHelp("Visibility Time (s)", "The time in seconds the info text will be displayed.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float infoTime = 3;

		[ORKEditorHelp("Display At Combatant", "The info text will be displayed at the position of the combatant.\n" +
			"If disabled, the GUI box position is used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool infoAtCom = false;

		[ORKEditorHelp("Update Info", "If a combatant already shows an info text, the text will be updated.\n" +
			"If disabled, the old text will be faded out and the new text faded in (i.e. the GUI box).", "")]
		[ORKEditorLayout("infoAtCom", true)]
		public bool infoComUpdate = true;

		[ORKEditorHelp("Path to Child", "The info text is positioned at a child object of the combatant.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string infoChildName = "";

		[ORKEditorHelp("Offset", "Offset added to the object's position.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public Vector2 infoPosOff = Vector2.zero;


		// show in
		[ORKEditorHelp("Field", "The info texts will be displayed in the field (i.e. outside of battles).", "")]
		[ORKEditorInfo(separator=true, labelText="Show In")]
		public bool infoInField = false;

		[ORKEditorHelp("Turn Based", "The info texts will be displayed in 'Turn Based' battles.", "")]
		public bool infoInTurnBased = true;

		[ORKEditorHelp("Active Time", "The info texts will be displayed in 'Active Time' battles.", "")]
		public bool infoInActiveTime = true;

		[ORKEditorHelp("Real Time", "The info texts will be displayed in 'Real Time' battles.", "")]
		public bool infoInRealTime = true;

		[ORKEditorHelp("Phase", "The info texts will be displayed in 'Phase' battles.", "")]
		public bool infoPhase = true;


		// infos
		[ORKEditorInfo("Attack Info", "Define the text used for base attacks.", "",
			endFoldout=true, label=new string[] {
				"%u = user name, % = ability name",
				"Ability Content:",
				"%n = name, %sn = short name, %d = description, %i = icon",
				"%tn = type name, %tsn = type short name, %td = type description, %ti = type icon"
		})]
		public BattleInfo attackInfo = new BattleInfo("%u attacks");

		[ORKEditorInfo("Ability Info", "Define the text used for abilities.", "",
			endFoldout=true, label=new string[] {
				"%u = user name, % = ability name",
				"Ability Content:",
				"%n = name, %sn = short name, %d = description, %i = icon",
				"%tn = type name, %tsn = type short name, %td = type description, %ti = type icon"
		})]
		public BattleInfo abilityInfo = new BattleInfo("%u uses %");

		[ORKEditorInfo("Item Info", "Define the text used for items.", "",
			endFoldout=true, label=new string[] {
				"%u = user name, % = item name",
				"Item Action Content:",
				"%n = name, %sn = short name, %d = description, %i = icon",
				"%tn = type name, %tsn = type short name, %td = type description, %ti = type icon"
		})]
		public BattleInfo itemInfo = new BattleInfo("%u uses %");

		[ORKEditorInfo("Defend Info", "Define the text used for defending.", "",
			endFoldout=true, label=new string[] {
				"%u = user name",
				"Defend Action Content:",
				"%n = name, %sn = short name, %d = description, %i = icon"
		})]
		public BattleInfo defendInfo = new BattleInfo("%u defends");

		[ORKEditorInfo("Escape Info", "Define the text used for escaping.", "",
			endFoldout=true, label=new string[] {
				"%u = user name",
				"Escape Action Content:",
				"%n = name, %sn = short name, %d = description, %i = icon"
		})]
		public BattleInfo escapeInfo = new BattleInfo("%u tries to escape");

		[ORKEditorInfo("Counter Info", "Define the text used for counter attacks.", "",
			endFoldout=true, label=new string[] {
				"%u = user name, % = ability name",
				"Ability Content:",
				"%n = name, %sn = short name, %d = description, %i = icon",
				"%tn = type name, %tsn = type short name, %td = type description, %ti = type icon"
		})]
		public BattleInfo counterInfo = new BattleInfo("%u counters");

		[ORKEditorInfo("Death Info", "Define the text used for dying.", "",
			endFoldout=true, label=new string[] {
				"%u = user name"
		})]
		public BattleInfo deathInfo = new BattleInfo("%u dies");

		[ORKEditorInfo("Do Nothing Info", "Define the text used for doing nothing (none action).", "",
			endFoldout=true, label=new string[] {
				"%u = user name",
				"None Action Content:",
				"%n = name, %sn = short name, %d = description, %i = icon"
		})]
		public BattleInfo noneInfo = new BattleInfo("%u does nothing");

		[ORKEditorInfo("Change Member Info", "Define the text used for changing group members.", "",
			endFoldout=true, label=new string[] {
				"%u = user name, % = new combatant name"
		})]
		public BattleInfo changeMemberInfo = new BattleInfo("%u is exchanged for %");

		[ORKEditorInfo("Join Battle Info", "Define the text used for joining a battle.", "",
			endFoldout=true, label=new string[] {
				"%u = user name"
		})]
		public BattleInfo joinBattleInfo = new BattleInfo("%u joins the battle");

		[ORKEditorInfo("Grid Move Info", "Define the text used for grid movement.", "",
			endFoldout=true, label=new string[] {
				"%u = user name",
				"Grid Move Action Content:",
				"%n = name, %sn = short name, %d = description, %i = icon"
		})]
		public BattleInfo gridMoveInfo = new BattleInfo("%u moves");

		// steal item infos
		[ORKEditorInfo("Steal Item Info", "Define the text used for stealing an item.", "",
			endFoldout=true, label=new string[] {
				"%u = user name, % = item name",
				"Item Content:",
				"%n = name, %sn = short name, %d = description, %i = icon",
				"%tn = type name, %tsn = type short name, %td = type description, %ti = type icon"
		})]
		public BattleInfo stealItemInfo = new BattleInfo("%u steals %");

		[ORKEditorInfo("Steal Item Fail Info", "Define the text used for failing to steal an item.", "",
			endFoldout=true, label=new string[] {
				"%u = user name"
		})]
		public BattleInfo stealItemFailInfo = new BattleInfo("%u fails to steal");

		[ORKEditorInfo("Steal Item Nothing Info", "Define the text used when there is no item to steal " +
			"(i.e. target doesn't allow stealing an item).", "",
			endFoldout=true, label=new string[] {
				"%u = user name"
		})]
		public BattleInfo stealItemNothingInfo = new BattleInfo("%u fails to steal");

		// steal money infos
		[ORKEditorInfo("Steal Money Info", "Define the text used for stealing money.", "",
			endFoldout=true, label=new string[] {
				"%u = user name, % = currency quantity",
				"Currency Content:",
				"%n = name, %sn = short name, %d = description, %i = icon",
				"%tn = type name, %tsn = type short name, %td = type description, %ti = type icon"
		})]
		public BattleInfo stealMoneyInfo = new BattleInfo("%u steals % money");

		[ORKEditorInfo("Steal Money Fail Info", "Define the text used for failing to steal money.", "",
			endFoldout=true, label=new string[] {
				"%u = user name",
				"Currency Content:",
				"%n = name, %sn = short name, %d = description, %i = icon",
				"%tn = type name, %tsn = type short name, %td = type description, %ti = type icon"
		})]
		public BattleInfo stealMoneyFailInfo = new BattleInfo("%u fails to steal money");

		[ORKEditorInfo("Steal Money Nothing Info", "Define the text used when there is no money to steal " +
			"(i.e. target doesn't allow stealing money).", "",
			endFoldout=true, endFolds=2, label=new string[] {
				"%u = user name",
				"Currency Content:",
				"%n = name, %sn = short name, %d = description, %i = icon",
				"%tn = type name, %tsn = type short name, %td = type description, %ti = type icon"
		})]
		[ORKEditorLayout(endCheckGroup=true)]
		public BattleInfo stealMoneyNothingInfo = new BattleInfo("%u fails to steal money");


		// flying texts
		// default position settings
		[ORKEditorInfo("Flying Text Settings", "Optionally display flying texts for different status changes, " +
			"e.g. adding/removing status effects or level ups.", "",
			"Default Position Settings", "Define where the flying texts will be displayed and how it will behave.\n" +
			"Each flying text can optionally override the default position settings.", "",
			endFoldout=true)]
		public FlyingTextPositionSettings flyingTextPositionSettings = new FlyingTextPositionSettings();


		// status effects
		[ORKEditorHelp("Show End With Battle", "Show the remove flying text for effects that end with the battle.", "")]
		[ORKEditorInfo("Status Effects", "Adding, missing or removing a status effect can display flying texts.", "")]
		public bool effectRemoveTextEndBattle = true;

		[ORKEditorHelp("Show End On Death", "Show the remove flying text for effects that end with the death of the combatant.", "")]
		public bool effectRemoveTextEndDeath = true;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Flying Text", "Add flying text settings.", "",
			"Remove", "Remove this flying text settings.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Flying Text", "Define the flying texts that will be displayed and for which group they're used.", ""
		})]
		public FlyingTextGroup<StatusEffectFlyingTextSettings>[] statusEffectFlyingText = new FlyingTextGroup<StatusEffectFlyingTextSettings>[0];


		// miss
		[ORKEditorInfo("Miss", "The miss text is displayed when an attack or ability misses it's target.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Flying Text", "Add flying text settings.", "",
			"Remove", "Remove this flying text settings.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Flying Text", "Define the flying texts that will be displayed and for which group they're used.", ""
		})]
		public FlyingTextGroup<FlyingTextSettings>[] missFlyingText = new FlyingTextGroup<FlyingTextSettings>[0];


		// block
		[ORKEditorInfo("Block", "The block text is displayed when status changes " +
			"(e.g. from an ability or item) are blocked by the target.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Flying Text", "Add flying text settings.", "",
			"Remove", "Remove this flying text settings.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Flying Text", "Define the flying texts that will be displayed and for which group they're used.", ""
		})]
		public FlyingTextGroup<FlyingTextSettings>[] blockFlyingText = new FlyingTextGroup<FlyingTextSettings>[0];


		// cast cancel
		[ORKEditorInfo("Cast Cancel", "The cast cancel text is displayed when an action cast is canceled (e.g. due to an attack).", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Flying Text", "Add flying text settings.", "",
			"Remove", "Remove this flying text settings.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Flying Text", "Define the flying texts that will be displayed and for which group they're used.", ""
		})]
		public FlyingTextGroup<FlyingTextSettings>[] castCancelFlyingText = new FlyingTextGroup<FlyingTextSettings>[0];


		// level up
		[ORKEditorInfo("Level Up", "The level up text is displayed when the level of a combatant increases.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Flying Text", "Add flying text settings.", "",
			"Remove", "Remove this flying text settings.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Flying Text", "Define the flying texts that will be displayed and for which group they're used.", ""
		})]
		public FlyingTextGroup<FlyingTextSettings>[] levelUpFlyingText = new FlyingTextGroup<FlyingTextSettings>[0];


		// class level up
		[ORKEditorInfo("Class Level Up", "The class level up text is displayed when the class level of a combatant increases.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorArray(false, "Add Flying Text", "Add flying text settings.", "",
			"Remove", "Remove this flying text settings.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Flying Text", "Define the flying texts that will be displayed and for which group they're used.", ""
		})]
		public FlyingTextGroup<FlyingTextSettings>[] classLevelUpFlyingText = new FlyingTextGroup<FlyingTextSettings>[0];


		// in-game
		private DefendShortcut dummyDefendAction;

		private EscapeShortcut dummyEscapeAction;

		private NoneShortcut dummyNoneAction;

		private GridMoveShortcut dummyGridMoveAction;

		private GridExamineShortcut dummyGridExamineAction;

		private GridOrientationShortcut dummyGridOrientationAction;


		public BattleTextsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.ContainsArray<DataObject>("allAlliesText"))
			{
				this.allAlliesButton.DataUpgrade(data.GetFileArray("allAlliesText"));
				this.allEnemiesButton.DataUpgrade(data.GetFileArray("allEnemiesText"));
				this.allCombatantsButton.DataUpgrade(data.GetFileArray("allCombatantsText"));
			}
			if(data.Contains<bool>("useEffectFlyingText") ||
				data.Contains<bool>("useEffectNotification"))
			{
				// status effect
				this.statusEffectFlyingText = new FlyingTextGroup<StatusEffectFlyingTextSettings>[1];
				this.statusEffectFlyingText[0] = new FlyingTextGroup<StatusEffectFlyingTextSettings>();
				this.statusEffectFlyingText[0].settings.SetData(data);
				if(data.Contains<bool>("useEffectFlyingText"))
				{
					data.Get("useEffectFlyingText", ref this.statusEffectFlyingText[0].settings.useAddFlyingText);
					data.Get("useEffectMissFlyingText", ref this.statusEffectFlyingText[0].settings.useMissFlyingText);
					data.Get("useEffectRemoveFlyingText", ref this.statusEffectFlyingText[0].settings.useRemoveFlyingText);
				}
				else
				{
					data.Get("useEffectNotification", ref this.statusEffectFlyingText[0].settings.useAddFlyingText);
					data.Get("useEffectMissNotification", ref this.statusEffectFlyingText[0].settings.useMissFlyingText);
					data.Get("useEffectRemoveNotification", ref this.statusEffectFlyingText[0].settings.useRemoveFlyingText);
				}
				if(this.statusEffectFlyingText[0].settings.useAddFlyingText)
				{
					this.statusEffectFlyingText[0].settings.addTextSettings = new FlyingTextSettings();
					this.statusEffectFlyingText[0].settings.addTextSettings.SetData(data.GetFile("effectTextSettings"));
				}
				if(this.statusEffectFlyingText[0].settings.useMissFlyingText)
				{
					this.statusEffectFlyingText[0].settings.missTextSettings = new FlyingTextSettings();
					this.statusEffectFlyingText[0].settings.missTextSettings.SetData(data.GetFile("effectMissTextSettings"));
				}
				if(this.statusEffectFlyingText[0].settings.useRemoveFlyingText)
				{
					this.statusEffectFlyingText[0].settings.removeTextSettings = new FlyingTextSettings();
					this.statusEffectFlyingText[0].settings.removeTextSettings.SetData(data.GetFile("effectRemoveTextSettings"));
				}
				// miss
				DataObject tmpData = data.GetFile("missTextSettings");
				if(tmpData != null)
				{
					this.missFlyingText = new FlyingTextGroup<FlyingTextSettings>[1];
					this.missFlyingText[0] = new FlyingTextGroup<FlyingTextSettings>();
					this.missFlyingText[0].settings.SetData(data.GetFile("missTextSettings"));
				}
				// block
				tmpData = data.GetFile("blockTextSettings");
				if(tmpData != null)
				{
					this.blockFlyingText = new FlyingTextGroup<FlyingTextSettings>[1];
					this.blockFlyingText[0] = new FlyingTextGroup<FlyingTextSettings>();
					this.blockFlyingText[0].settings.SetData(tmpData);
				}
				// cast cancel
				tmpData = data.GetFile("castCancelTextSettings");
				if(tmpData != null)
				{
					this.castCancelFlyingText = new FlyingTextGroup<FlyingTextSettings>[1];
					this.castCancelFlyingText[0] = new FlyingTextGroup<FlyingTextSettings>();
					this.castCancelFlyingText[0].settings.SetData(tmpData);
				}
				// level up
				tmpData = data.GetFile("levelUpTextSettings");
				if(tmpData != null)
				{
					this.levelUpFlyingText = new FlyingTextGroup<FlyingTextSettings>[1];
					this.levelUpFlyingText[0] = new FlyingTextGroup<FlyingTextSettings>();
					this.levelUpFlyingText[0].settings.SetData(tmpData);
				}
				// class level up
				tmpData = data.GetFile("classLevelUpTextSettings");
				if(tmpData != null)
				{
					this.classLevelUpFlyingText = new FlyingTextGroup<FlyingTextSettings>[1];
					this.classLevelUpFlyingText[0] = new FlyingTextGroup<FlyingTextSettings>();
					this.classLevelUpFlyingText[0].settings.SetData(tmpData);
				}
			}
			this.textSkin.Upgrade(data, "textSkin");

			if(data.Contains<bool>("queueInfos"))
			{
				bool tmp = false;
				data.Get("queueInfos", ref tmp);
				this.queueInfos = tmp ? NotificationQueueType.Queue : NotificationQueueType.Replace;
			}
		}

		public override void SetRealIDs()
		{

		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "battleTexts"; }
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public ChoiceContent GetAllCombatantsContent(TargetType type, ContentLayout layout)
		{
			if(TargetType.Ally == type)
			{
				return layout.GetChoiceContent(this.allAlliesButton);
			}
			else if(TargetType.Enemy == type)
			{
				return layout.GetChoiceContent(this.allEnemiesButton);
			}
			else if(TargetType.All == type)
			{
				return layout.GetChoiceContent(this.allCombatantsButton);
			}
			return null;
		}

		public GUISkin GUISkin
		{
			get { return this.textSkin; }
		}

		public DefendShortcut DummyDefendAction
		{
			get
			{
				if(this.dummyDefendAction == null)
				{
					this.dummyDefendAction = new DefendShortcut();
				}
				return this.dummyDefendAction;
			}
		}

		public EscapeShortcut DummyEscapeAction
		{
			get
			{
				if(this.dummyEscapeAction == null)
				{
					this.dummyEscapeAction = new EscapeShortcut();
				}
				return this.dummyEscapeAction;
			}
		}

		public NoneShortcut DummyNoneAction
		{
			get
			{
				if(this.dummyNoneAction == null)
				{
					this.dummyNoneAction = new NoneShortcut();
				}
				return this.dummyNoneAction;
			}
		}

		public GridMoveShortcut DummyGridMoveAction
		{
			get
			{
				if(this.dummyGridMoveAction == null)
				{
					this.dummyGridMoveAction = new GridMoveShortcut(new GridMoveSettings());
				}
				return this.dummyGridMoveAction;
			}
		}

		public GridExamineShortcut DummyGridExamineAction
		{
			get
			{
				if(this.dummyGridExamineAction == null)
				{
					this.dummyGridExamineAction = new GridExamineShortcut();
				}
				return this.dummyGridExamineAction;
			}
		}

		public GridOrientationShortcut DummyGridOrientationAction
		{
			get
			{
				if(this.dummyGridOrientationAction == null)
				{
					this.dummyGridOrientationAction = new GridOrientationShortcut(false);
				}
				return this.dummyGridOrientationAction;
			}
		}


		/*
		============================================================================
		Flying text functions
		============================================================================
		*/
		public void ShowMissFlyingText(string info, Combatant combatant, GameObject targetObject, IContentSimple content)
		{
			if(combatant != null &&
				this.missFlyingText.Length > 0)
			{
				int group = FlyingTextGroup<FlyingTextSettings>.GetGroup(combatant);
				for(int i = 0; i < this.missFlyingText.Length; i++)
				{
					if(this.missFlyingText[i].CheckCombatant(group))
					{
						this.missFlyingText[i].settings.ShowText(info, combatant, targetObject, content);
						break;
					}
				}
			}
		}

		public void ShowBlockFlyingText(string info, Combatant combatant, GameObject targetObject, IContentSimple content)
		{
			if(combatant != null &&
				this.blockFlyingText.Length > 0)
			{
				int group = FlyingTextGroup<FlyingTextSettings>.GetGroup(combatant);
				for(int i = 0; i < this.blockFlyingText.Length; i++)
				{
					if(this.blockFlyingText[i].CheckCombatant(group))
					{
						this.blockFlyingText[i].settings.ShowText(info, combatant, targetObject, content);
						break;
					}
				}
			}
		}

		public void ShowCastCancelFlyingText(string info, Combatant combatant, GameObject targetObject, IContentSimple content)
		{
			if(combatant != null &&
				this.castCancelFlyingText.Length > 0)
			{
				int group = FlyingTextGroup<FlyingTextSettings>.GetGroup(combatant);
				for(int i = 0; i < this.castCancelFlyingText.Length; i++)
				{
					if(this.castCancelFlyingText[i].CheckCombatant(group))
					{
						this.castCancelFlyingText[i].settings.ShowText(info, combatant, targetObject, content);
						break;
					}
				}
			}
		}

		public void ShowLevelUpFlyingText(string info, Combatant combatant, GameObject targetObject)
		{
			if(combatant != null &&
				this.levelUpFlyingText.Length > 0)
			{
				int group = FlyingTextGroup<FlyingTextSettings>.GetGroup(combatant);
				for(int i = 0; i < this.levelUpFlyingText.Length; i++)
				{
					if(this.levelUpFlyingText[i].CheckCombatant(group))
					{
						this.levelUpFlyingText[i].settings.ShowText(info, combatant, targetObject, combatant);
						break;
					}
				}
			}
		}

		public void ShowClassLevelUpFlyingText(string info, Combatant combatant, GameObject targetObject)
		{
			if(combatant != null &&
				this.classLevelUpFlyingText.Length > 0)
			{
				int group = FlyingTextGroup<FlyingTextSettings>.GetGroup(combatant);
				for(int i = 0; i < this.classLevelUpFlyingText.Length; i++)
				{
					if(this.classLevelUpFlyingText[i].CheckCombatant(group))
					{
						this.classLevelUpFlyingText[i].settings.ShowText(info, combatant, targetObject, combatant.Class.Current);
						break;
					}
				}
			}
		}
	}
}
