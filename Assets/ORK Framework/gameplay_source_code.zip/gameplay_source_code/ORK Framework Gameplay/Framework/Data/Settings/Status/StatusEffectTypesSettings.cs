
using UnityEngine;

namespace ORKFramework
{
	public class StatusEffectTypesSettings : BaseLanguageSettings<StatusEffectType>
	{
		public StatusEffectTypesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "statusEffectTypes"; }
		}

		public override ORKDataType DataType
		{
			get { return ORKDataType.StatusEffectType; }
		}
	}
}

