
using System.Collections.Generic;

namespace ORKFramework
{
	public class NameContentSorter : IComparer<IContent>
	{
		private bool invert = false;

		public NameContentSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(IContent x, IContent y)
		{
			if(this.invert)
			{
				return y.GetName().CompareTo(x.GetName());
			}
			else
			{
				return x.GetName().CompareTo(y.GetName());
			}
		}
	}

	public class NameCombatantSorter : IComparer<Combatant>
	{
		private bool invert = false;

		public NameCombatantSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(this.invert)
			{
				return y.GetName().CompareTo(x.GetName());
			}
			else
			{
				return x.GetName().CompareTo(y.GetName());
			}
		}
	}
}
