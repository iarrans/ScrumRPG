﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CursorTypeSorter : IComparer<CursorType>
	{
		public CursorTypeSorter()
		{

		}

		public int Compare(CursorType x, CursorType y)
		{
			return y.CompareTo(x);
		}
	}
}
