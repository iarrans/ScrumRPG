﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class SortingOptionSettings : BaseData
	{
		[ORKEditorHelp("Change Sorting Key", "Select the input key used to change the sorting.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int changeSortingKey = 0;

		[ORKEditorHelp("Remember Sorting", "Remember the current sorting option.", "")]
		public bool rememberSorting = false;

		[ORKEditorArray(false, "Add Sort Option", "Adds a sort option.", "",
			"Remove", "Removes this sort option.", "",
			isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Sort Option", "Define the sorting that will be used by this sort option.", ""
		})]
		public SortOption[] sortOption = new SortOption[]
		{
			new SortOption()
		};

		public SortingOptionSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("changeSortingKeyID"))
			{
				data.Get("changeSortingKeyID", ref this.changeSortingKey);
			}
		}

		public bool ChangeSorting(ref int currentSorting)
		{
			if(this.sortOption.Length > 0 &&
				ORK.InputKeys.Get(this.changeSortingKey).GetButton())
			{
				currentSorting++;
				if(currentSorting >= this.sortOption.Length)
				{
					currentSorting = 0;
				}
				return true;
			}
			return false;
		}
	}
}
