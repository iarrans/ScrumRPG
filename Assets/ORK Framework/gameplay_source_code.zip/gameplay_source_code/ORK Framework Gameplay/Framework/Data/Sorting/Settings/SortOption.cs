﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class SortOption : BaseData
	{
		[ORKEditorHelp("Name", "The name of this sorting option.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] name = ArrayHelper.CreateArray(ORK.Languages.Count, "Default");

		[ORKEditorHelp("Description", "The description of this sorting option.", "")]
		[ORKEditorInfo(expandWidth=true, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] description = ArrayHelper.CreateArray(ORK.Languages.Count, "");

		[ORKEditorHelp("Default Sorting", "Uses the default sorting settings.", "")]
		[ORKEditorInfo(separator=true)]
		public bool isDefault = true;

		[ORKEditorLayout("isDefault", false, endCheckGroup=true, autoInit=true)]
		public AdvancedContentSorter sorter;

		public SortOption()
		{

		}
	}
}
