﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class EquipStatusValueSorter : IComparer<IInventoryShortcut>, IComparer<EquipShortcut>
	{
		private Combatant user;

		private int statusValueID = 0;

		private bool invert = false;

		public EquipStatusValueSorter(Combatant user, int statusValueID, bool invert)
		{
			this.user = user;
			this.statusValueID = statusValueID;
			this.invert = invert;
		}

		public int Compare(IInventoryShortcut x, IInventoryShortcut y)
		{
			EquipShortcut equipX = x as EquipShortcut;
			EquipShortcut equipY = y as EquipShortcut;
			if(this.invert)
			{
				if(equipX == null &&
					equipY == null)
				{
					return y.GetName().CompareTo(x.GetName());
				}
				else if(equipX != null &&
					equipY == null)
				{
					return -1;
				}
				else if(equipX == null &&
					equipY != null)
				{
					return 1;
				}
				else
				{
					int result = equipY.GetStatusValueBonus(this.user, this.statusValueID).CompareTo(
						equipX.GetStatusValueBonus(this.user, this.statusValueID));
					if(result == 0)
					{
						return y.GetName().CompareTo(x.GetName());
					}
					return result;
				}
			}
			else
			{
				if(equipX == null &&
					equipY == null)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				else if(equipX != null &&
					equipY == null)
				{
					return -1;
				}
				else if(equipX == null &&
					equipY != null)
				{
					return 1;
				}
				else
				{
					int result = equipX.GetStatusValueBonus(this.user, this.statusValueID).CompareTo(
						equipY.GetStatusValueBonus(this.user, this.statusValueID));
					if(result == 0)
					{
						return x.GetName().CompareTo(y.GetName());
					}
					return result;
				}
			}
		}

		public int Compare(EquipShortcut x, EquipShortcut y)
		{
			if(this.invert)
			{
				int result = y.GetStatusValueBonus(this.user, this.statusValueID).CompareTo(
					x.GetStatusValueBonus(this.user, this.statusValueID));
				if(result == 0)
				{
					return y.GetName().CompareTo(x.GetName());
				}
				return result;
			}
			else
			{
				int result = x.GetStatusValueBonus(this.user, this.statusValueID).CompareTo(
					y.GetStatusValueBonus(this.user, this.statusValueID));
				if(result == 0)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				return result;
			}
		}
	}
}
