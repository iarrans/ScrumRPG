﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class OverrideLanguageContent : BaseData
	{
		// own name
		[ORKEditorHelp("Own Name", "Override the name.", "")]
		[ORKEditorInfo(labelText="Override Name")]
		public bool ownName = false;

		[ORKEditorHelp("Name", "Define the name that will be used.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%name = original name"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("ownName", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] name;


		// own short name
		[ORKEditorHelp("Own Short Name", "Override the short name.", "")]
		[ORKEditorInfo(separator=true, labelText="Override Short Name")]
		public bool ownShortName = false;

		[ORKEditorHelp("Short Name", "Define the short name that will be used.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%name = original short name"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("ownShortName", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] shortName;


		// own description
		[ORKEditorHelp("Own Description", "Override the description.", "")]
		[ORKEditorInfo(separator=true, labelText="Override Description")]
		public bool ownDescription = false;

		[ORKEditorHelp("Description", "Define the description that will be used.", "")]
		[ORKEditorInfo(isTextArea=true, label=new string[] {
			"%description = original description"
		})]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout("ownDescription", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] description;


		// own icon
		[ORKEditorHelp("Own Icon", "Override the icon.", "")]
		[ORKEditorInfo(separator=true, labelText="Override Icon")]
		public bool ownIcon = false;

		[ORKEditorHelp("Icon", "Select the icon that will be used.", "")]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("ownIcon", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public Texture[] icon;

		public OverrideLanguageContent()
		{

		}

		public string GetName(string originalName)
		{
			return this.name != null ?
				this.name[ORK.Game.Language].Replace("%name", originalName) :
				"";
		}

		public string GetShortName(string originalShortName)
		{
			return this.shortName != null ?
				this.shortName[ORK.Game.Language].Replace("%name", originalShortName) :
				"";
		}

		public string GetDescription(string originalDescription)
		{
			return this.description != null ?
				this.description[ORK.Game.Language].Replace("%description", originalDescription) :
				"";
		}
	}
}
