﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class IconInfo : BaseData
	{
		[ORKEditorHelp("Icon", "Select the icon that will be used.", "")]
		public AssetSource<Texture> icon = new AssetSource<Texture>();

		public IconInfo()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.icon.Upgrade(data, "icon");
		}
	}
}
