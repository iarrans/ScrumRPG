
using UnityEngine;
using ORKFramework.Events;
using System.Text;
using System.Reflection;

namespace ORKFramework.Reflection
{
	public class EventGetFieldValue : BaseData
	{
		[ORKEditorHelp("Field Name", "The name of the field/property that will be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string fieldName = "";

		[ORKEditorHelp("Is Property", "Uses the value of a property.\n" +
			"If disabled, the value of a field will be used.", "")]
		public bool isProperty = false;

		[ORKEditorHelp("Is Array", "The field/property is an array.\n" +
			"A defined index of the array is used.", "")]
		public bool isArray = false;

		[ORKEditorHelp("Use Array Length", "Use the length of the array instead of the value of a defined index in the array.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("isArray", true)]
		public bool useArrayLength = false;

		[ORKEditorInfo(labelText="Array Index")]
		[ORKEditorLayout("useArrayLength", false, endCheckGroup=true, endGroups=2, autoInit=true)]
		public EventInteger arrayIndex;

		public EventGetFieldValue()
		{

		}

		private object GetArrayValue(BaseEvent baseEvent, object value)
		{
			System.Array array = value as System.Array;
			if(array != null)
			{
				return this.useArrayLength ?
					array.Length :
					array.GetValue(this.arrayIndex.GetValue(baseEvent));
			}
			else
			{
				System.Collections.IList list = value as System.Collections.IList;
				if(list != null)
				{
					return this.useArrayLength ?
						list.Count :
						list[this.arrayIndex.GetValue(baseEvent)];
				}
			}
			return null;
		}

		public object GetValue(object instance, string className, bool isStatic, BaseEvent baseEvent)
		{
			if(className != "")
			{
				System.Type instanceType = isStatic ?
					ORK.Core.TypeHandler.GetType(className) :
					ORK.Core.TypeHandler.GetType(className, typeof(Component));

				if(instanceType != null)
				{
					if(isStatic || instance != null)
					{
						if(this.fieldName != "")
						{
							if(this.isProperty)
							{
								PropertyInfo propertyInfo = instanceType.GetProperty(this.fieldName,
									BindingFlags.Public | BindingFlags.NonPublic |
										(isStatic ? BindingFlags.Static : BindingFlags.Instance));
								if(propertyInfo != null)
								{
									try
									{
										if(this.isArray)
										{
											return this.GetArrayValue(baseEvent, propertyInfo.GetValue(instance, null));
										}
										else
										{
											return propertyInfo.GetValue(instance, null);
										}
									}
									catch(System.Exception ex)
									{
										Debug.LogWarning("Getting property value failed (" + instanceType + "): " +
											this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
									}
								}
								else
								{
									Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
								}
							}
							else
							{
								FieldInfo fieldInfo = instanceType.GetField(this.fieldName,
									BindingFlags.Public | BindingFlags.NonPublic |
										(isStatic ? BindingFlags.Static : BindingFlags.Instance));
								if(fieldInfo != null)
								{
									try
									{
										if(this.isArray)
										{
											return this.GetArrayValue(baseEvent, fieldInfo.GetValue(instance));
										}
										else
										{
											return fieldInfo.GetValue(instance);
										}
									}
									catch(System.Exception ex)
									{
										Debug.LogWarning("Getting field value failed (" + instanceType + "): " +
											this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
									}
								}
								else
								{
									Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
								}
							}
						}
					}
				}
				else
				{
					Debug.LogWarning("Component type not found: " + className);
				}
			}
			return null;
		}
	}
}
