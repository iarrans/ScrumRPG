
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Reflection
{
	public class CallParameter : BaseData
	{
		[ORKEditorHelp("Parameter Type", "Select the type of the parameter value.", "")]
		public ParameterType type = ParameterType.String;

		[ORKEditorInfo(separator=true, labelText="String Value", expandWidth=true)]
		[ORKEditorLayout("type", ParameterType.String, endCheckGroup=true)]
		public StringValue stringValue = new StringValue();

		[ORKEditorHelp("Bool Value", "Define the bool the field will be set to.", "")]
		[ORKEditorLayout("type", ParameterType.Bool, endCheckGroup=true)]
		public bool boolValue = false;

		[ORKEditorInfo(separator=true, labelText="Int/Float Value")]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { ParameterType.Int, ParameterType.Float },
			needed=Needed.One, endCheckGroup=true)]
		public FloatValue floatValue = new FloatValue();

		[ORKEditorInfo(separator=true, labelText="Vector Value")]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { ParameterType.Vector2, ParameterType.Vector3 },
			needed=Needed.One, endCheckGroup=true)]
		public Vector3Value vectorValue = new Vector3Value();

		public CallParameter()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<string>("stringValue"))
			{
				if(ParameterType.String == this.type)
				{
					data.Get("stringValue", ref this.stringValue.value);
				}
				else if(ParameterType.Int == this.type)
				{
					int tmp = 0;
					data.Get("intValue", ref tmp);
					this.floatValue.value = tmp;
				}
				else if(ParameterType.Float == this.type)
				{
					data.Get("floatValue", ref this.floatValue.value);
				}
				else if(ParameterType.Vector2 == this.type)
				{
					float[] tmp;
					data.Get("vector2Value", out tmp);
					if(tmp != null)
					{
						this.vectorValue.value = ArrayHelper.GetVector2(tmp);
					}
				}
				else if(ParameterType.Vector3 == this.type)
				{
					float[] tmp;
					data.Get("vector3Value", out tmp);
					if(tmp != null)
					{
						this.vectorValue.value = ArrayHelper.GetVector3(tmp);
					}
				}
			}
		}

		public object GetValue()
		{
			if(ParameterType.String == this.type)
			{
				return this.stringValue.GetValue();
			}
			else if(ParameterType.Bool == this.type)
			{
				return this.boolValue;
			}
			else if(ParameterType.Int == this.type)
			{
				return (int)this.floatValue.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader);
			}
			else if(ParameterType.Float == this.type)
			{
				return this.floatValue.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader);
			}
			else if(ParameterType.Vector2 == this.type)
			{
				return (Vector2)this.vectorValue.GetValue();
			}
			else if(ParameterType.Vector3 == this.type)
			{
				return this.vectorValue.GetValue();
			}
			return null;
		}

		public System.Type GetType()
		{
			if(ParameterType.String == this.type)
			{
				return typeof(string);
			}
			else if(ParameterType.Bool == this.type)
			{
				return typeof(bool);
			}
			else if(ParameterType.Int == this.type)
			{
				return typeof(int);
			}
			else if(ParameterType.Float == this.type)
			{
				return typeof(float);
			}
			else if(ParameterType.Vector2 == this.type)
			{
				return typeof(Vector2);
			}
			else if(ParameterType.Vector3 == this.type)
			{
				return typeof(Vector3);
			}
			return null;
		}
	}
}
