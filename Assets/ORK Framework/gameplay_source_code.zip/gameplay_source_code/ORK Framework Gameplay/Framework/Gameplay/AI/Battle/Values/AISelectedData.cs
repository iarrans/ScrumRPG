﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AISelectedData : AISelectedDataOrigin
	{
		[ORKEditorInfo(labelText="Selected Key")]
		public AIString selectedKey = new AIString();

		public AISelectedData()
		{

		}

		public string GetInfoText()
		{
			return this.selectedKey.GetInfoText() + "(" + this.origin.ToString() + ")";
		}

		public int GetCount(BattleAICall call)
		{
			return this.GetCount(call, this.selectedKey.GetValue(call));
		}

		public List<object> GetSelectedData(BattleAICall call)
		{
			return this.GetSelectedData(call, this.selectedKey.GetValue(call));
		}

		public void Change(BattleAICall call, object data, ListChangeType changeType)
		{
			this.Change(call, this.selectedKey.GetValue(call), data, changeType);
		}
	}
}
