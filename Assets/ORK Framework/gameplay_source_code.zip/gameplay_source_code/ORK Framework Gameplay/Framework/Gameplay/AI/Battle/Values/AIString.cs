﻿
using UnityEngine;
using UnityEngine.SceneManagement;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIString : BaseData
	{
		[ORKEditorHelp("Value Type", "Select where the string value comes from:\n" +
			"- Value: A defined value.\n" +
			"- Game Variable: The value of a game variable (string).\n" +
			"- Player Prefs: The value of a PlayerPrefs string variable.\n" +
			"- Scene Name: The name of the current scene.", "")]
		public StringValueType type = StringValueType.Value;

		[ORKEditorHelp("Value", "Depending on the 'Value Type':\n" +
		 	"- Value: The text will be used as value.\n" +
		 	"- Game Variable: The text is the key (name) of a game variable (string) that holds the value that will be used.\n" +
		 	"- Player Prefs: The text is the key of a PlayerPrefs string variable that holds the value that will be used.", "")]
		[ORKEditorInfo(expandWidth=true, isVariableField=true)]
		[ORKEditorLayout("type", StringValueType.SceneName, elseCheckGroup=true, endCheckGroup=true)]
		public string value = "";


		// variable
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in the current run of a combatant's battle AI " +
			"and don't interfere with global variables. The variable will be gone once combatant's battle AI finished.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.\n" +
			"- Selected: Variables assigned to selected data.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("type", StringValueType.GameVariable)]
		public VariableOrigin origin = VariableOrigin.Global;

		// selected data variable
		[ORKEditorHelp("Selected Key", "The selected key that will be used", "")]
		[ORKEditorInfo(indent=true, expandWidth=true)]
		[ORKEditorLayout("origin", VariableOrigin.Selected)]
		public string selectedKey = "";

		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public AISelectedDataOrigin selectedDataOrigin;


		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID of the used object variables.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;

		[ORKEditorHelp("Use Found Targets", "Change the object variables on the targets found by previous steps.\n" +
			"If disabled, you need to define the target that will be changed.", "")]
		[ORKEditorInfo(indent=true, separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true)]
		public bool onFound = false;

		[ORKEditorHelp("Target", "Select which combatant's or combatant group's object variables will be changed:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(indent=true, isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("onFound", false, endCheckGroup=true)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout(new string[] { "targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		// object ID
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(indent=true, expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=3)]
		public string objectID = "";

		public AIString()
		{

		}

		public AIString(string value)
		{
			this.type = StringValueType.Value;
			this.value = value;
		}

		public string GetValue(BattleAICall call)
		{
			if(StringValueType.Value == this.type)
			{
				return this.value;
			}
			else if(StringValueType.GameVariable == this.type)
			{
				if(VariableOrigin.Local == this.origin)
				{
					return call.Variables.GetString(this.value);
				}
				else if(VariableOrigin.Global == this.origin)
				{
					return ORK.Game.Variables.GetString(this.value);
				}
				else if(VariableOrigin.Object == this.origin)
				{
					if(this.useObject)
					{
						List<Combatant> list = this.onFound ?
							call.foundTargets :
							BattleAI.GetTargetList(this.targetType,
								this.targetExcludeSelf, this.targetExcludeFoundTargets,
								call);
						for(int i = 0; i < list.Count; i++)
						{
							if(list[i] != null)
							{
								return list[i].Variables.GetString(this.value);
							}
						}
					}
					else
					{
						return ORK.Game.Scene.GetObjectVariables(this.objectID).GetString(this.value);
					}
				}
				else if(VariableOrigin.Selected == this.origin)
				{
					List<SelectedDataHandler> dataList = this.selectedDataOrigin.Get(call);
					for(int i = 0; i < dataList.Count; i++)
					{
						if(dataList[i] != null)
						{
							VariableHandler handler = SelectedDataHelper.GetFirstVariableHandler(dataList[i].Get(this.selectedKey));
							if(handler != null)
							{
								return handler.GetString(this.value);
							}
						}
					}
				}
			}
			else if(StringValueType.PlayerPrefs == this.type)
			{
				return PlayerPrefs.GetString(this.value);
			}
			else if(StringValueType.SceneName == this.type)
			{
				return SceneManager.GetActiveScene().name;
			}
			return "";
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(StringValueType.SceneName == this.type)
			{
				return "Scene Name";
			}
			else if(StringValueType.Value == this.type)
			{
				return this.value;
			}
			else if(StringValueType.GameVariable == this.type)
			{
				return this.value + " (" + this.origin + ")";
			}
			return this.value + " (" + this.type + ")";
		}
	}
}

