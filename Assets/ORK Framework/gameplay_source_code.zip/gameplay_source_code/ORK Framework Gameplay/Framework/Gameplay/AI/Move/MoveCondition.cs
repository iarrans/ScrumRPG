
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveCondition : BaseData
	{
		[ORKEditorHelp("Type", "Select the type of the condition's check:\n" +
			"- Level: Checks the target's level.\n" +
			"- Class Level: Checks the target's class level.\n" +
			"- Group Size: Checks the target's group size.\n" +
			"- Status: Advanced status requirement.", "")]
		public MoveConditionType type = MoveConditionType.Level;


		// level/class level
		[ORKEditorHelp("Use Offset", "The defined level value is added to the combatant's level for the check.\n" +
			"If disabled, only the defined level value is used.", "")]
		[ORKEditorLayout(new string[] {"type", "type"}, new System.Object[] {MoveConditionType.Level, MoveConditionType.ClassLevel},
			needed=Needed.One)]
		public bool levelOffset = true;

		[ORKEditorHelp("Average Level", "Use the target's average group level for the check.\n" +
			"If disabled, the target's level is used.", "")]
		public bool levelAverage = false;

		[ORKEditorHelp("Only Battle Group", "Only the target's battle group is used for the average level.\n" +
			"If disabled, the whole group is used.", "")]
		[ORKEditorLayout("levelAverage", true, endCheckGroup=true, endGroups=2)]
		public bool levelOnlyBattle = true;


		// group size
		[ORKEditorHelp("Only Battle Group", "Only the target's battle group is used for the size check.\n" +
			"If disabled, the whole size of the whole group is used (i.e. all available group members).", "")]
		[ORKEditorLayout("type", MoveConditionType.GroupSize, endCheckGroup=true)]
		public bool groupSizeOnlyBattle = true;


		// check (level/group)
		[ORKEditorLayout(new string[] { "type", "type", "type" },
			new object[] { MoveConditionType.Level, MoveConditionType.ClassLevel , MoveConditionType.GroupSize },
			needed=Needed.One, endCheckGroup=true)]
		public ValueCheck valueCheck = new ValueCheck(1);


		// status condition
		[ORKEditorHelp("Check Self", "Check the user of the move AI instead of the detected target.", "")]
		[ORKEditorLayout("type", MoveConditionType.Status)]
		public bool statusCheckSelf = false;

		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public StatusRequirement statusRequirement;

		public MoveCondition()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(MoveConditionType.Level == this.type ||
				MoveConditionType.ClassLevel == this.type)
			{
				this.valueCheck.UpgradeInt(data, "levelCheck", "level");
			}
			else if(MoveConditionType.GroupSize == this.type)
			{
				this.valueCheck.UpgradeInt(data, "groupSizeCheck", "groupSize");
			}
		}

		public bool IsValid(Combatant combatant, Combatant target)
		{
			if(MoveConditionType.Level == this.type)
			{
				if(this.levelAverage)
				{
					if(this.levelOnlyBattle)
					{
						return this.levelOffset ?
							this.valueCheck.CheckOffset(target.Group.AverageBattleLevel, combatant.Status.Level, combatant, target) :
							this.valueCheck.Check(target.Group.AverageBattleLevel, combatant, target);
					}
					else
					{
						return this.levelOffset ?
							this.valueCheck.CheckOffset(target.Group.AverageLevel, combatant.Status.Level, combatant, target) :
							this.valueCheck.Check(target.Group.AverageLevel, combatant, target);
					}
				}
				else
				{
					return this.levelOffset ?
						this.valueCheck.CheckOffset(target.Status.Level, combatant.Status.Level, combatant, target) :
						this.valueCheck.Check(target.Status.Level, combatant, target);
				}
			}
			else if(MoveConditionType.ClassLevel == this.type)
			{
				if(this.levelAverage)
				{
					if(this.levelOnlyBattle)
					{
						return this.levelOffset ?
							this.valueCheck.CheckOffset(target.Group.AverageBattleClassLevel, combatant.Class.Level, combatant, target) :
							this.valueCheck.Check(target.Group.AverageBattleClassLevel, combatant, target);
					}
					else
					{
						return this.levelOffset ?
							this.valueCheck.CheckOffset(target.Group.AverageClassLevel, combatant.Class.Level, combatant, target) :
							this.valueCheck.Check(target.Group.AverageClassLevel, combatant, target);
					}
				}
				else
				{
					return this.levelOffset ?
						this.valueCheck.CheckOffset(target.Class.Level, combatant.Class.Level, combatant, target) :
						this.valueCheck.Check(target.Class.Level, combatant, target);
				}
			}
			else if(MoveConditionType.GroupSize == this.type)
			{
				if(this.groupSizeOnlyBattle)
				{
					return this.valueCheck.Check(target.Group.BattleSize, combatant, target);
				}
				else
				{
					return this.valueCheck.Check(target.Group.Size, combatant, target);
				}
			}
			else if(MoveConditionType.Status == this.type)
			{
				return this.statusRequirement.CheckRequirement(this.statusCheckSelf ? combatant : target);
			}
			return false;
		}
	}
}
