﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIRulesetSlot : ISaveData
	{
		private bool blocked = false;

		private AIRulesetShortcut ruleset;

		public AIRulesetSlot()
		{

		}

		public bool Blocked
		{
			get { return this.blocked; }
			set { this.blocked = false; }
		}

		public bool Equipped
		{
			get { return this.ruleset != null; }
		}

		public AIRulesetShortcut AIRuleset
		{
			get { return this.ruleset; }
			set { this.ruleset = value; }
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			if(this.ruleset != null)
			{
				data.Set("ruleset", this.ruleset.SaveGame());
			}

			data.Set("blocked", this.blocked);

			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.ruleset = null;
			if(data != null)
			{
				DataObject tmpRuleset = data.GetFile("ruleset");
				if(tmpRuleset != null)
				{
					this.ruleset = new AIRulesetShortcut();
					this.ruleset.LoadGame(tmpRuleset);
					if(this.ruleset.ID < 0 ||
						this.ruleset.ID >= ORK.AIRulesets.Count)
					{
						this.ruleset = null;
					}
				}

				data.Get("blocked", ref this.blocked);
			}
		}
	}
}
