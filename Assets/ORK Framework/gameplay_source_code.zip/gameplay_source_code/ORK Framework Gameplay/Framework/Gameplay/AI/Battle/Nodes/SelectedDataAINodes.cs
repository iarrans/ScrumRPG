﻿
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Clear Selected Data", "Clears selected data, i.e. either all or " +
		"the selected data of the defined key will be removed.", "")]
	[ORKNodeInfo("Selected Data")]
	public class ClearSelectedDataStep : BaseAIStep
	{
		[ORKEditorHelp("Clear All", "Clears all selected data.\n" +
			"If disabled, only the selected data of a defined selected key will be cleared.", "")]
		public bool all = false;

		[ORKEditorInfo(separator=true, labelText="Selected Key")]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public AIString selectedKey = new AIString();

		public AISelectedDataOrigin selectedDataOrigin = new AISelectedDataOrigin();

		public ClearSelectedDataStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(this.all)
			{
				this.selectedDataOrigin.Clear(call);
			}
			else
			{
				this.selectedDataOrigin.Clear(call, this.selectedKey.GetValue(call));
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedDataOrigin.GetInfoText() + ": " +
				(this.all ? "All" : this.selectedKey.GetInfoText());
		}
	}

	[ORKEditorHelp("Selected Data Count", "Checks how many data is stored in a selected data list.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectedDataCountStep : BaseAICheckStep
	{
		public AISelectedData selectedData = new AISelectedData();

		[ORKEditorInfo(separator=true)]
		public AIValueCheck check = new AIValueCheck();

		public SelectedDataCountStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeAIFloat(data, "check", "checkValue", "checkValue2");

			if(data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(this.check.Check(this.selectedData.GetCount(call),
				call, call.user, call.user))
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}

			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedData.GetInfoText() + " " + this.check.GetInfoText();
		}
	}

	[ORKEditorHelp("Select Combatant", "Uses combatants as selected data.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectCombatantStep : BaseAIStep
	{
		public AISelectedData selectedData = new AISelectedData();

		[ORKEditorHelp("Change Type", "Select how the selected data will be changed:\n" +
			"- Add: The combatants will be added to the selected data.\n" +
			"- Remove: The combatants will be removed from the selected data.\n" +
			"- Clear: The selected data will be cleared.\n" +
			"- Set: The combatants will be set as selected data, removing previous data.", "")]
		[ORKEditorInfo(separator=true)]
		public ListChangeType changeType = ListChangeType.Set;


		// combatants
		[ORKEditorHelp("Use All Combatants", "The list of all combatants will be set as selected data.\n" +
			"If disabled, only the first available combatant will be set as selected data.", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, elseCheckGroup=true)]
		public bool allCombatants = false;

		[ORKEditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " + 
			"followed by battle reserve and finally the rest of the members.", "")]
		[ORKEditorLayout("allCombatants", true)]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[ORKEditorHelp("Use Random", "Use a random combatant from the group.", "")]
		[ORKEditorLayout("combatantScope", MenuCombatantScope.Current, elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public bool useRandom = false;

		[ORKEditorInfo(separator=true)]
		public SelectCombatantSettings selectCombatant = new SelectCombatantSettings();

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be used:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- None: No combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions " +
			"to check if a combatant will be used.\n" +
			"The requirements are only checked for the combatant itself, not e.g. the combatant's last targets.", "")]
		[ORKEditorInfo("Filter Settings", "Optionally filter the used combatants by using status requirements and variable conditions on them.", "")]
		public bool useRequirements = false;

		[ORKEditorHelp("Is Enemy", "Select if the combatants are enemies of the user:\n" +
			"- Yes: The combatants are enemies.\n" +
			"- No: The combatants are allies.\n" +
			"- Ignore: Ignores the faction standings.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		[ORKEditorLayout("useRequirements", true)]
		public Consider isEnemy = Consider.Ignore;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2, autoInit=true)]
		public SimpleCombatantRequirement requirement;

		public SelectCombatantStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				this.selectedData.Clear(call, this.selectedData.selectedKey.GetValue(call));
			}
			else
			{
				List<Combatant> found = new List<Combatant>();
				List<Combatant> list = BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call);

				if(this.allCombatants)
				{
					if(MenuCombatantScope.Current == this.combatantScope)
					{
						if(this.useRequirements)
						{
							this.requirement.FilterList(ref list);
						}
						for(int i = 0; i < list.Count; i++)
						{
							this.selectCombatant.Get(list[i], found);
						}
					}
					else
					{
						List<Combatant> combatants = new List<Combatant>();
						for(int i = 0; i < list.Count; i++)
						{
							list[i].Group.GetMembers(this.combatantScope, ref combatants);
						}
						if(this.useRequirements)
						{
							this.requirement.FilterList(ref combatants);
						}

						if(this.useRandom)
						{
							this.selectCombatant.Get(combatants[UnityWrapper.Range(0, combatants.Count)], found);
						}
						else
						{
							for(int i = 0; i < combatants.Count; i++)
							{
								this.selectCombatant.Get(combatants[i], found);
							}
						}
					}
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null &&
							(!this.useRequirements || this.requirement.Check(list[i])))
						{
							this.selectCombatant.Get(list[i], found);
							break;
						}
					}
				}

				if(found.Count > 0 &&
					this.useRequirements &&
					Consider.Ignore != this.isEnemy)
				{
					for(int i = 0; i < found.Count; i++)
					{
						if(found[i].IsEnemy(call.user) == (Consider.No == this.isEnemy))
						{
							found.RemoveAt(i--);
						}
					}
				}

				if(found.Count == 1)
				{
					this.selectedData.Change(call, found[0], this.changeType);
				}
				else if(found.Count > 1)
				{
					this.selectedData.Change(call, found, this.changeType);
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedData.GetInfoText() + " " + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" :
				(" " + this.targetType.ToString() + (this.allCombatants ? " (all)" : "")));
		}
	}

	[ORKEditorHelp("Select Ability", "Uses abilities of combatants or a newly created ability as selected data.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectAbilityStep : BaseAIStep
	{
		public AISelectedData selectedData = new AISelectedData();

		[ORKEditorHelp("Change Type", "Select how the selected data will be changed:\n" +
			"- Add: The abilities will be added to the selected data.\n" +
			"- Remove: The abilities will be removed from the selected data.\n" +
			"- Clear: The selected data will be cleared.\n" +
			"- Set: The abilities will be set as selected data, removing previous data.", "")]
		[ORKEditorInfo(separator=true)]
		public ListChangeType changeType = ListChangeType.Set;


		// ability settings
		[ORKEditorHelp("Create Ability", "Create a new instance of the defined ability.\n" +
			"If disabled, abilities known by a combatant will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Ability Settings")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, elseCheckGroup=true)]
		public bool createAbility = false;

		// all abilities
		[ORKEditorHelp("All Abilities", "Get all abilities of the combatant.", "")]
		[ORKEditorLayout("createAbility", false, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool allAbilities = false;

		[ORKEditorHelp("Useable In", "Select where the abilities can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Passive abilities.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("allAbilities", true)]
		public UseableIn useableIn = UseableIn.Both;

		[ORKEditorHelp("Add Temporary Abilities", "Select if temporary abilities will be included:\n" +
			"- Yes: Temporary abilities will be included.\n" +
			"- No: Temporary abilities will not be included.\n" +
			"- Only: Only temporary abilities will be used.", "")]
		public IncludeCheckType addTemporary = IncludeCheckType.Yes;

		[ORKEditorHelp("Limit Ability Type", "Limit the abilities to a defined ability type and it's sub-types.", "")]
		public bool limitAbilityType = false;

		[ORKEditorHelp("Ability Type", "Select the ability type that will be used to limit the abilities.", "")]
		[ORKEditorInfo(ORKDataType.AbilityType)]
		[ORKEditorLayout("limitAbilityType", true, endCheckGroup=true)]
		public int abilityTypeID = 0;

		// ability
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public AbilitySelection ability = new AbilitySelection();


		// combatant
		[ORKEditorHelp("Use All Combatants", "The abilities of all combatants will be set as selected data.\n" +
			"If disabled, only the first available ability will be set as selected data.", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		[ORKEditorLayout("createAbility", false)]
		public bool allCombatants = false;

		[ORKEditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[ORKEditorLayout("allCombatants", true, endCheckGroup=true)]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be used:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- None: No combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, endGroups=3,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		public SelectAbilityStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("abilityID"))
			{
				this.ability.SetData(data);
			}
			if(data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				this.selectedData.Clear(call, this.selectedData.selectedKey.GetValue(call));
			}
			else if(this.createAbility)
			{
				this.selectedData.Change(call,
					this.ability.CreateShortcut(AbilityState.None), this.changeType);
			}
			else
			{
				List<Combatant> list = BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call);

				if(this.allCombatants)
				{
					List<AbilityShortcut> abilities = new List<AbilityShortcut>();

					if(MenuCombatantScope.Current != this.combatantScope)
					{
						List<Combatant> combatants = new List<Combatant>();
						for(int i = 0; i < list.Count; i++)
						{
							list[i].Group.GetMembers(this.combatantScope, ref combatants);
						}
						list = combatants;
					}

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(this.allAbilities)
							{
								List<AbilityShortcut> tmpAbilities = this.limitAbilityType ?
								list[i].Abilities.GetByType(this.abilityTypeID, this.useableIn, this.addTemporary, true) :
								list[i].Abilities.GetAbilities(this.useableIn, this.addTemporary);

								for(int j = 0; j < tmpAbilities.Count; j++)
								{
									if(!abilities.Contains(tmpAbilities[j]))
									{
										abilities.Add(tmpAbilities[j]);
									}
								}
							}
							else
							{
								AbilityShortcut ability = this.ability.GetAbility(list[i]);

								if(ability != null &&
									!abilities.Contains(ability))
								{
									abilities.Add(ability);
								}
							}
						}
					}

					this.selectedData.Change(call, abilities, this.changeType);
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(this.allAbilities)
							{
								this.selectedData.Change(call,
									this.limitAbilityType ?
										list[i].Abilities.GetByType(this.abilityTypeID, this.useableIn, this.addTemporary, true) :
										list[i].Abilities.GetAbilities(this.useableIn, this.addTemporary),
									this.changeType);
								break;
							}
							else
							{
								AbilityShortcut ability = this.ability.GetAbility(list[i]);

								if(ability != null)
								{
									this.selectedData.Change(call, ability, this.changeType);
									break;
								}
							}
						}
					}
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedData.GetInfoText() + " " + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" :
				(" " + (this.createAbility ?
					"Create " :
					(this.targetType.ToString() + (this.allCombatants ? " (all) " : " "))) +
				(this.allAbilities ? "all abilities" : this.ability.GetInfoText())));
		}
	}

	[ORKEditorHelp("Select Base Attack", "Uses base attacks of combatants as selected data.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectBaseAttackStep : BaseAIStep
	{
		public AISelectedData selectedData = new AISelectedData();

		[ORKEditorHelp("Change Type", "Select how the selected data will be changed:\n" +
			"- Add: The base attacks will be added to the selected data.\n" +
			"- Remove: The base attacks will be removed from the selected data.\n" +
			"- Clear: The selected data will be cleared.\n" +
			"- Set: The base attacks will be set as selected data, removing previous data.", "")]
		[ORKEditorInfo(separator=true)]
		public ListChangeType changeType = ListChangeType.Set;


		// attack settings
		[ORKEditorHelp("Base Attack Scope", "Select the scope of the base attack that will be used:\n" +
			"- Current: Use the current base attack of the combatant.\n" +
			"- Index: Use a base attack at a defined index.\n" +
			"- All: Use all base attacks of the combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Base Attack Settings")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, elseCheckGroup=true)]
		public BaseAttackScope attackScope = BaseAttackScope.Current;

		[ORKEditorLayout("attackScope", BaseAttackScope.Index, endCheckGroup=true, autoInit=true)]
		public AIFloat attackIndex;


		// combatant
		[ORKEditorHelp("Use All Combatants", "The base attacks of all combatants will be set as selected data.\n" +
			"If disabled, only the first available base attack will be set as selected data.", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		public bool allCombatants = false;

		[ORKEditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[ORKEditorLayout("allCombatants", true, endCheckGroup=true)]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be used:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- None: No combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, endGroups=2,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		public SelectBaseAttackStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				this.selectedData.Clear(call, this.selectedData.selectedKey.GetValue(call));
			}
			else
			{
				List<Combatant> list = BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call);
				if(this.allCombatants)
				{
					List<AbilityShortcut> abilities = new List<AbilityShortcut>();

					if(MenuCombatantScope.Current != this.combatantScope)
					{
						List<Combatant> combatants = new List<Combatant>();
						for(int i = 0; i < list.Count; i++)
						{
							list[i].Group.GetMembers(this.combatantScope, ref combatants);
						}
						list = combatants;
					}

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(BaseAttackScope.All == this.attackScope)
							{
								list[i].Abilities.GetBaseAttacks(ref abilities);
							}
							else
							{
								AbilityShortcut ability = null;

								if(BaseAttackScope.Current == this.attackScope)
								{
									ability = list[i].Abilities.GetCurrentBaseAttack();
								}
								else if(BaseAttackScope.Index == this.attackScope)
								{
									ability = list[i].Abilities.GetBaseAttack((int)this.attackIndex.GetValue(call, call.user, call.user));
								}

								if(ability != null &&
									!abilities.Contains(ability))
								{
									abilities.Add(ability);
								}
							}
						}
					}

					this.selectedData.Change(call, abilities, this.changeType);
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(BaseAttackScope.All == this.attackScope)
							{
								List<AbilityShortcut> abilities = new List<AbilityShortcut>();
								list[i].Abilities.GetBaseAttacks(ref abilities);
								this.selectedData.Change(call, abilities, this.changeType);
								break;
							}
							else
							{
								AbilityShortcut ability = null;

								if(BaseAttackScope.Current == this.attackScope)
								{
									ability = list[i].Abilities.GetCurrentBaseAttack();
								}
								else if(BaseAttackScope.Index == this.attackScope)
								{
									ability = list[i].Abilities.GetBaseAttack((int)this.attackIndex.GetValue(call, call.user, call.user));
								}

								if(ability != null)
								{
									this.selectedData.Change(call, ability, this.changeType);
									break;
								}
							}
						}
					}
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedData.GetInfoText() + " " + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" :
				(" " + this.targetType.ToString() + (this.allCombatants ? " (all) " : " ") +
				this.attackScope.ToString()));
		}
	}

	[ORKEditorHelp("Select Counter Attack", "Uses counter attacks of combatants as selected data.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectCounterAttackStep : BaseAIStep
	{
		public AISelectedData selectedData = new AISelectedData();

		[ORKEditorHelp("Change Type", "Select how the selected data will be changed:\n" +
			"- Add: The counter attacks will be added to the selected data.\n" +
			"- Remove: The counter attacks will be removed from the selected data.\n" +
			"- Clear: The selected data will be cleared.\n" +
			"- Set: The counter attacks will be set as selected data, removing previous data.", "")]
		[ORKEditorInfo(separator=true)]
		public ListChangeType changeType = ListChangeType.Set;


		// combatant
		[ORKEditorHelp("Use All Combatants", "The counter attacks of all combatants will be set as selected data.\n" +
			"If disabled, only the first available counter attack will be set as selected data.", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, elseCheckGroup=true)]
		public bool allCombatants = false;

		[ORKEditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[ORKEditorLayout("allCombatants", true, endCheckGroup=true)]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be used:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- None: No combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, endGroups=2,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;

		public SelectCounterAttackStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				this.selectedData.Clear(call, this.selectedData.selectedKey.GetValue(call));
			}
			else
			{
				List<Combatant> list = BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call);
				if(this.allCombatants)
				{
					List<AbilityShortcut> abilities = new List<AbilityShortcut>();

					if(MenuCombatantScope.Current != this.combatantScope)
					{
						List<Combatant> combatants = new List<Combatant>();
						for(int i = 0; i < list.Count; i++)
						{
							list[i].Group.GetMembers(this.combatantScope, ref combatants);
						}
						list = combatants;
					}

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							AbilityShortcut ability = list[i].Abilities.GetCounterAttack();

							if(ability != null &&
								!abilities.Contains(ability))
							{
								abilities.Add(ability);
							}
						}
					}

					this.selectedData.Change(call, abilities, this.changeType);
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							this.selectedData.Change(call,
								list[i].Abilities.GetCounterAttack(), this.changeType);
							break;
						}
					}
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedData.GetInfoText() + " " + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" :
				(" " + this.targetType.ToString() + (this.allCombatants ? " (all)" : "")));
		}
	}

	[ORKEditorHelp("Select Equipment", "Uses the equipment currently equipped on combatants as selected data.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectEquipmentStep : BaseAIStep
	{
		public AISelectedData selectedData = new AISelectedData();

		[ORKEditorHelp("Change Type", "Select how the selected data will be changed:\n" +
			"- Add: The equipment will be added to the selected data.\n" +
			"- Remove: The equipment will be removed from the selected data.\n" +
			"- Clear: The selected data will be cleared.\n" +
			"- Set: The equipment will be set as selected data, removing previous data.", "")]
		[ORKEditorInfo(separator=true)]
		public ListChangeType changeType = ListChangeType.Set;


		// equipment
		[ORKEditorHelp("All Equipment", "Use all currently equipped weapons and armors of the combatant.\n" +
			"If disabled, only the equipment of a defined equipment part will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Equipment Settings")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, elseCheckGroup=true)]
		public bool allEquipment = false;

		[ORKEditorHelp("Equipment Part", "Select the equipment part which's current equipment will be used.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("allEquipment", false, endCheckGroup=true)]
		public int equipmentPartID = 0;

		[ORKEditorHelp("Limit Item Type", "Limit the equipment to a defined item type and its sub-types.", "")]
		public bool limitItemType = false;

		[ORKEditorHelp("Item Type", "Select the item type that will be used to limit the equipment.", "")]
		[ORKEditorInfo(ORKDataType.ItemType)]
		[ORKEditorLayout("limitItemType", true, endCheckGroup=true)]
		public int itemTypeID = 0;


		// combatant
		[ORKEditorHelp("Use All Combatants", "The equipment of all combatants will be set as selected data.\n" +
			"If disabled, only the first available equipment will be set as selected data.", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		public bool allCombatants = false;

		[ORKEditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[ORKEditorLayout("allCombatants", true, endCheckGroup=true)]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be used:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- None: No combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// filter
		[ORKEditorHelp("Use Filter", "Use equipment variable conditions on the equipment.\n" +
			"Equipment that doesn't match the conditions will not be used.", "")]
		[ORKEditorInfo("Filter Settings", "Optionally filter the used equipment by using equipment variable conditions on them.", "")]
		public bool useFilter = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useFilter", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public VariableCondition condition;

		public SelectEquipmentStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				this.selectedData.Clear(call, this.selectedData.selectedKey.GetValue(call));
			}
			else
			{
				List<Combatant> list = BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call);
				if(this.allCombatants)
				{
					List<EquipShortcut> equipment = new List<EquipShortcut>();

					if(MenuCombatantScope.Current != this.combatantScope)
					{
						List<Combatant> combatants = new List<Combatant>();
						for(int i = 0; i < list.Count; i++)
						{
							list[i].Group.GetMembers(this.combatantScope, ref combatants);
						}
						list = combatants;
					}

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(this.allEquipment)
							{
								for(int j = 0; j < ORK.EquipmentParts.Count; j++)
								{
									if(list[i].Equipment[j].Available &&
										list[i].Equipment[j].Equipped)
									{
										EquipShortcut equip = list[i].Equipment[j].Equipment;

										if(equip != null &&
											!equipment.Contains(equip) &&
											(!this.limitItemType ||
												equip.TypeID == this.itemTypeID ||
												ORK.ItemTypes.Get(equip.TypeID).IsSubTypeOf(this.itemTypeID)) &&
											(!this.useFilter ||
												(equip.HasVariables &&
													this.condition.CheckVariables(equip.Variables))))
										{
											equipment.Add(equip);
										}
									}
								}
							}
							else if(list[i].Equipment[this.equipmentPartID].Available &&
								list[i].Equipment[this.equipmentPartID].Equipped)
							{
								EquipShortcut equip = list[i].Equipment[this.equipmentPartID].Equipment;

								if(equip != null &&
									!equipment.Contains(equip) &&
									(!this.limitItemType ||
										equip.TypeID == this.itemTypeID ||
										ORK.ItemTypes.Get(equip.TypeID).IsSubTypeOf(this.itemTypeID)) &&
									(!this.useFilter ||
										(equip.HasVariables &&
											this.condition.CheckVariables(equip.Variables))))
								{
									equipment.Add(equip);
								}
							}
						}
					}

					this.selectedData.Change(call, equipment, this.changeType);
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							if(this.allEquipment)
							{
								List<EquipShortcut> equipment = new List<EquipShortcut>();

								for(int j = 0; j < ORK.EquipmentParts.Count; j++)
								{
									if(list[i].Equipment[j].Available &&
										list[i].Equipment[j].Equipped)
									{
										EquipShortcut equip = list[i].Equipment[j].Equipment;

										if(equip != null &&
											!equipment.Contains(equip) &&
											(!this.limitItemType ||
												equip.TypeID == this.itemTypeID ||
												ORK.ItemTypes.Get(equip.TypeID).IsSubTypeOf(this.itemTypeID)) &&
											(!this.useFilter ||
												(equip.HasVariables &&
													this.condition.CheckVariables(equip.Variables))))
										{
											equipment.Add(equip);
										}
									}
								}

								this.selectedData.Change(call, equipment, this.changeType);
								break;
							}
							else if(list[i].Equipment[this.equipmentPartID].Available &&
								list[i].Equipment[this.equipmentPartID].Equipped)
							{
								EquipShortcut equip = list[i].Equipment[this.equipmentPartID].Equipment;

								if(equip != null &&
									(!this.limitItemType ||
										equip.TypeID == this.itemTypeID ||
										ORK.ItemTypes.Get(equip.TypeID).IsSubTypeOf(this.itemTypeID)) &&
									(!this.useFilter ||
										(equip.HasVariables &&
											this.condition.CheckVariables(equip.Variables))))
								{
									this.selectedData.Change(call, equip, this.changeType);
									break;
								}
							}
						}
					}
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedData.GetInfoText() + " " + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" :
				(" " + this.targetType.ToString() + (this.allCombatants ? " (all) " : " ") +
				(this.allEquipment ?
					"all equipment" :
					ORK.EquipmentParts.GetName(this.equipmentPartID))));
		}
	}

	[ORKEditorHelp("Select Item", "Uses items from the inventory of combatants or newly created items as selected data.", "")]
	[ORKNodeInfo("Selected Data")]
	public class SelectItemStep : BaseAIStep
	{
		public AISelectedData selectedData = new AISelectedData();

		[ORKEditorHelp("Change Type", "Select how the selected data will be changed:\n" +
			"- Add: The items will be added to the selected data.\n" +
			"- Remove: The items will be removed from the selected data.\n" +
			"- Clear: The items data will be cleared.\n" +
			"- Set: The items will be set as selected data, removing previous data.", "")]
		[ORKEditorInfo(separator=true)]
		public ListChangeType changeType = ListChangeType.Set;


		// item settings
		[ORKEditorHelp("Create Item", "Create new instances of the defined items.\n" +
			"If disabled, items from the inventories of combatants will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Item Settings")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, elseCheckGroup=true)]
		public bool createItem = false;

		// all items
		[ORKEditorHelp("All Items", "Use all items currently in the combatant's inventory.\n" +
			"If disabled, only the defined items will be used.", "")]
		[ORKEditorLayout("createItem", false, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool allItems = false;

		[ORKEditorLayout("allItems", true)]
		public InventoryAccessSettings inventoryAccess = new InventoryAccessSettings();

		// item type
		[ORKEditorHelp("Limit Item Type", "Limit the items to a defined item type and its sub-types.", "")]
		[ORKEditorInfo(separator=true)]
		public bool limitItemType = false;

		[ORKEditorHelp("Item Type", "Select the item type that will be used to limit the items.", "")]
		[ORKEditorInfo(ORKDataType.ItemType)]
		[ORKEditorLayout("limitItemType", true, endCheckGroup=true)]
		public int itemTypeID = 0;

		// define items
		[ORKEditorArray(false, "Add Item", "Adds an item to the list.", "",
			"Remove", "Removes this item from the list.", "",
			noRemoveCount=1, isCopy=true, isMove=true, foldout=true, foldoutText=new string[] {
				"Item", "Define the item.", ""
		})]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public ItemGain[] item = new ItemGain[] {new ItemGain()};


		// combatant
		[ORKEditorHelp("Use All Combatants", "The items of all combatants will be set as selected data.\n" +
			"If disabled, only the first available items will be set as selected data.", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		[ORKEditorLayout("createItem", false)]
		public bool allCombatants = false;

		[ORKEditorHelp("Combatant Scope", "Select the scope that will be used:\n" +
			"- Current: The combatant itself.\n" +
			"- Battle: The members of the combatant's battle group.\n" +
			"- Group: All members of the combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the combatant's battle group.\n" +
			"- Battle Reserve: The members in the combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.", "")]
		[ORKEditorLayout("allCombatants", true, endCheckGroup=true)]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be used:\n" +
			"- Self: The combatant itself.\n" +
			"- Ally: The combatant's allies.\n" +
			"- Enemy: The combatant's enemies.\n" +
			"- All: All combatants.\n" +
			"- None: No combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;

		[ORKEditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[ORKEditorLayout(new string[] { "targetType", "targetType", "targetType" },
			new System.Object[] { BattleAITargetType.Ally, BattleAITargetType.Enemy, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool targetExcludeFoundTargets = false;


		// filter
		[ORKEditorHelp("Use Filter", "Use item or equipment variable conditions on the items and equipment.\n" +
			"Items and equipment that doesn't match the conditions will not be used.\n" +
			"Other things without variables will not be checked.", "")]
		[ORKEditorInfo("Filter Settings", "Optionally filter the used items and equipment " +
			"by using item/equipment variable conditions on them.", "")]
		public bool useFilter = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useFilter", true, endCheckGroup=true, endGroups=3, autoInit=true)]
		public VariableCondition condition;

		public SelectItemStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("addMoney"))
			{
				this.inventoryAccess.SetData(data);
			}
			if(data.Contains<DataObject>("selectedKey"))
			{
				this.selectedData.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentStep, BattleAICall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				this.selectedData.Clear(call, this.selectedData.selectedKey.GetValue(call));
			}
			else if(this.createItem)
			{
				List<IShortcut> items = new List<IShortcut>();
				for(int i = 0; i < this.item.Length; i++)
				{
					items.Add(this.item[i].CreateShortcut(call.user, call.user));
				}
				this.selectedData.Change(call, items, this.changeType);
			}
			else
			{
				List<Combatant> list = BattleAI.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call);
				if(this.allCombatants)
				{
					List<Inventory> inventory = new List<Inventory>();
					List<IShortcut> items = new List<IShortcut>();

					if(MenuCombatantScope.Current == this.combatantScope ||
						ORK.InventorySettings.IsGroup())
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(list[i] != null &&
								!inventory.Contains(list[i].Inventory))
							{
								inventory.Add(list[i].Inventory);
							}
						}
					}
					else
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(list[i] != null)
							{
								List<Combatant> group = new List<Combatant>();
								list[i].Group.GetMembers(this.combatantScope, ref group);
								for(int j = 0; j < group.Count; j++)
								{
									if(group[j] != null &&
										!inventory.Contains(group[j].Inventory))
									{
										inventory.Add(group[j].Inventory);
									}
								}
							}
						}
					}

					for(int i = 0; i < inventory.Count; i++)
					{
						if(inventory[i] != null)
						{
							if(this.allItems)
							{
								this.inventoryAccess.GetAll(inventory[i],
									this.limitItemType ? this.itemTypeID : -1, true, ref items);
							}
							else
							{
								for(int j = 0; j < this.item.Length; j++)
								{
									this.item[j].GetFromInventory(inventory[i], true, ref items);
								}
							}
						}
					}

					this.Filter(items);
					this.selectedData.Change(call, items, this.changeType);
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							List<IShortcut> items = new List<IShortcut>();
							if(this.allItems)
							{
								this.inventoryAccess.GetAll(list[i].Inventory,
									this.limitItemType ? this.itemTypeID : -1, true, ref items);
							}
							else
							{
								for(int j = 0; j < this.item.Length; j++)
								{
									this.item[j].GetFromInventory(list[i].Inventory, true, ref items);
								}
							}

							this.Filter(items);
							if(items.Count > 0)
							{
								this.selectedData.Change(call, items, this.changeType);
								break;
							}
						}
					}
				}
			}

			currentStep = this.next;
			return null;
		}

		private void Filter(List<IShortcut> list)
		{
			if(this.useFilter)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] == null)
					{
						list.RemoveAt(i--);
					}
					else if(list[i] is ItemShortcut)
					{
						ItemShortcut item = (ItemShortcut)list[i];
						if(!item.HasVariables ||
							!this.condition.CheckVariables(item.Variables))
						{
							list.RemoveAt(i--);
						}
					}
					else if(list[i] is EquipShortcut)
					{
						EquipShortcut equip = (EquipShortcut)list[i];
						if(!equip.HasVariables ||
							!this.condition.CheckVariables(equip.Variables))
						{
							list.RemoveAt(i--);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selectedData.GetInfoText() + " " + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" :
				(" " + (this.createItem ?
					"Create" :
					(this.targetType.ToString() + (this.allCombatants ? " (all)" : "") +
						(this.allItems ? " all items" : "")))));
		}
	}
}
