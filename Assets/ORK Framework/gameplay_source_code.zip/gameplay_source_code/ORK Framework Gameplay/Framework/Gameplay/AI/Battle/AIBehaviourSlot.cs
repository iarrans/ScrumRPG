﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIBehaviourSlot : ISaveData
	{
		private bool blocked = false;

		private AIBehaviourShortcut behaviour;

		public AIBehaviourSlot()
		{

		}

		public bool Blocked
		{
			get { return this.blocked; }
			set { this.blocked = false; }
		}

		public bool Equipped
		{
			get { return this.behaviour != null; }
		}

		public AIBehaviourShortcut AIBehaviour
		{
			get { return this.behaviour; }
			set { this.behaviour = value; }
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			if(this.behaviour != null)
			{
				data.Set("behaviour", this.behaviour.SaveGame());
			}

			data.Set("blocked", this.blocked);

			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.behaviour = null;
			if(data != null)
			{
				DataObject tmpBehaviour = data.GetFile("behaviour");
				if(tmpBehaviour != null)
				{
					this.behaviour = new AIBehaviourShortcut();
					this.behaviour.LoadGame(tmpBehaviour);
					if(this.behaviour.ID < 0 ||
						this.behaviour.ID >= ORK.AIBehaviours.Count)
					{
						this.behaviour = null;
					}
				}

				data.Get("blocked", ref this.blocked);
			}
		}
	}
}
