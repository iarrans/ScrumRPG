﻿
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class BoolValue : BaseData
	{
		[ORKEditorHelp("Value Type", "Select where the bool value comes from:\n" +
			"- Value: A defined value.\n" +
			"- Game Variable: The value of a game variable (bool).\n" +
			"- Player Prefs: The value of a PlayerPrefs int variable, if it's above 0, the value is 'true', otherwise 'false'.", "")]
		public BoolValueType type = BoolValueType.Value;


		// value
		[ORKEditorHelp("Value", "Define the bool value that will be used.", "")]
		[ORKEditorLayout("type", BoolValueType.Value)]
		public bool value = false;


		// variable/playerprefs key
		[ORKEditorHelp("Variable/PlayerPrefs Key", "Define the key of the game variable (bool) or PlayerPrefs (int) that will be used.", "")]
		[ORKEditorInfo(expandWidth=true, isVariableField=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public string key = "";

		public BoolValue()
		{

		}

		public BoolValue(bool value)
		{
			this.type = BoolValueType.Value;
			this.value = value;
		}

		public bool GetValue()
		{
			if(BoolValueType.Value == this.type)
			{
				return this.value;
			}
			else if(BoolValueType.GameVariable == this.type)
			{
				return ORK.Game.Variables.GetBool(this.key);
			}
			else if(BoolValueType.PlayerPrefs == this.type)
			{
				return PlayerPrefs.GetInt(this.key) > 0;
			}
			return false;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(BoolValueType.Value == this.type)
			{
				return this.value.ToString();
			}
			return this.key + " (" + this.type + ")";
		}
	}
}

