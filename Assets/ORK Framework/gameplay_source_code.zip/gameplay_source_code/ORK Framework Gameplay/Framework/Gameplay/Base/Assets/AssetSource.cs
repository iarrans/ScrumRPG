﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public abstract class AssetSource : BaseData
	{
		public abstract BaseAssetSource Source
		{
			get;
		}

		public abstract string GetSettingsType();

		public abstract void SetSettingsType(string type);

		public abstract System.Type GetAssetType();

		public abstract bool HasAsset
		{
			get;
		}
	}

	public class AssetSource<T> : AssetSource where T : UnityEngine.Object
	{
		[ORKEditorHelp("Asset Source", "Select the source of the used asset:", "")]
		[ORKEditorInfo(settingBaseType=typeof(BaseAssetSource), settingAutoSetup="settings",
			setWidth=true, fieldWidth=150, hideName=true)]
		public string type = "";

		public BaseAssetSource<T> settings = new ReferenceAssetSource<T>();

		public AssetSource()
		{
			this.type = this.settings.GetGenericTypeName();
		}

		public void Upgrade(DataObject data, string fieldName)
		{
			if(data != null &&
				data.Contains<T>(fieldName))
			{
				ReferenceAssetSource<T> tmpSettings = new ReferenceAssetSource<T>();
				data.Get(fieldName, ref tmpSettings.asset);
				this.settings = tmpSettings;
				this.type = this.settings.GetGenericTypeName();
			}
		}

		public static implicit operator T(AssetSource<T> source)
		{
			return source != null ? source.settings.Get() : null;
		}

		public override BaseAssetSource Source
		{
			get { return this.settings; }
		}

		public override string GetSettingsType()
		{
			return this.type;
		}

		public override void SetSettingsType(string type)
		{
			this.type = type;
			this.EditorAutoSetup("settings");
		}

		public override System.Type GetAssetType()
		{
			return typeof(T);
		}

		public override bool HasAsset
		{
			get { return this.settings.HasAsset; }
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(!this.settings.IsType(this.type))
			{
				UnityEngine.Object asset = this.settings.EditorAsset;
				DataObject data = this.settings.GetData();

				System.Type tmpType = ReflectionTypeHandler.Instance.GetType(this.type, typeof(BaseAssetSource));
				if(tmpType != null)
				{
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						tmpType.MakeGenericType(typeof(T)));
					if(tmpSettings is BaseAssetSource<T>)
					{
						this.settings = (BaseAssetSource<T>)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new ReferenceAssetSource<T>();
						this.settings.SetData(data);
						this.type = this.settings.GetGenericTypeName();
					}
				}
				else
				{
					this.settings = new ReferenceAssetSource<T>();
					this.settings.SetData(data);
					this.type = this.settings.GetGenericTypeName();
				}

				if(asset != null)
				{
					this.settings.EditorAsset = asset;
				}
			}
		}
	}
}
