﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Group Leader", "The combatant must or mustn't be the leader of it's group.", "")]
	public class GroupLeaderRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Is Leader", "The combatant must be the leader of his group.\n" +
			"If disabled, the combatant mustn't be the leader of his group.", "")]
		public bool isLeader = true;

		public GroupLeaderRequirementType()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.isLeader == combatant.IsLeader;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.GroupChanged += notify.CombatantGroupChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.GroupChanged -= notify.CombatantGroupChanged;
		}
	}
}
