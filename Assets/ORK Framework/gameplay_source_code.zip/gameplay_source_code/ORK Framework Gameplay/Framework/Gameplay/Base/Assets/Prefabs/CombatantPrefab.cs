﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantPrefab : BaseData
	{
		[ORKEditorHelp("Prefab", "Select the prefab of this combatant.\n" +
			"The prefab is used to spawn the combatant in the field and in battle.", "")]
		public AssetSource<GameObject> prefab = new AssetSource<GameObject>();

		[ORKEditorHelp("Child as Root", "The defined child object of the game object " +
			"(selected prefab) will be used as root object.\n" +
			"This can be used e.g. if the prefab root isn't the moving object.\n" +
			"Usage: Path/to/Child. Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string prefabRoot = "";

		[ORKEditorHelp("Box Radius", "The box radius is a radius around the combatant and represents " +
		 	"the combatants width.\n" +
		 	"It's used to calculate distances, e.g. for movement and range checks.\n" +
			"E.g.: Two combatants are 10 world units apart, one combatant has a box width of 4, " +
			"the other has a box width of 1.5 - the calculated distance would be 4.5.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float boxRadius = 0;

		[ORKEditorHelp("Spawn Offset", "Offset added to the combatants game object position when spawning.", "")]
		public Vector3 spawnOffset = Vector3.zero;

		public CombatantPrefab()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			// prefab
			this.prefab.Upgrade(data, "prefab");
		}
	}
}
