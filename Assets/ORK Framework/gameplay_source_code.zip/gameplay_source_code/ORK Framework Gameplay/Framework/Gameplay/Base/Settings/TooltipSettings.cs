﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TooltipSettings : BaseData
	{
		[ORKEditorHelp("Selection Tooltip", "Tooltips are displayed for the currently selected choice.\n" +
			"Cursor over always takes priority.\n" +
			"If disabled, only hovering the cursor over content with a tooltip will display a tooltip.", "")]
		public bool selectionTooltip = false;

		[ORKEditorHelp("Preview Tooltip", "Tooltips are displayed for the current preview source (e.g. an equipment or ability).\n" +
			"Actual tooltips (e.g. hovering the cursor over a choice or shortcut) will take precedence over preview tooltips.", "")]
		public bool previewTooltip = false;

		[ORKEditorHelp("Blocked Focus Lock", "Tooltips are locked when a focus blocking GUI box is displayed " +
			"and only shows tooltips from the focused GUI box.", "")]
		public bool blockedFocusLock = false;


		// action tooltips
		[ORKEditorHelp("Player Action Tooltip", "Tooltips are displayed for the current action of a player combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Action Tooltips")]
		public bool playerActionTooltip = false;

		[ORKEditorHelp("Ally Action Tooltip", "Tooltips are displayed for the current action of an allied combatant.", "")]
		public bool allyActionTooltip = false;

		[ORKEditorHelp("Enemy Action Tooltip", "Tooltips are displayed for the current action of an enemy combatant.", "")]
		public bool enemyActionTooltip = false;

		[ORKEditorHelp("No Counter Tooltips", "Counter attacks don't display action tooltips.", "")]
		[ORKEditorLayout(new string[] { "playerActionTooltip", "allyActionTooltip", "enemyActionTooltip" },
			new object[] { true, true, true },
			needed=Needed.One, endCheckGroup=true)]
		public bool noCounterTooltips = false;

		public TooltipSettings()
		{

		}
	}
}
