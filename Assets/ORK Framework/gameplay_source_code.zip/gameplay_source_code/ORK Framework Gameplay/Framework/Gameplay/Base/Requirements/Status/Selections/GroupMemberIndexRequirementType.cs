﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Group Member Index", "The combatant must or mustn't be the member at a defined index of it's group or battle group.", "")]
	public class GroupMemberIndexRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Member Index", "The member index that will be checked for.", "")]
		[ORKEditorLimit(0, false)]
		public int index = 0;

		[ORKEditorHelp("Is Index", "The combatant must be the member at the defined index.\n" +
			"If disabled, the combatant mustn't be the member at the defined index.", "")]
		public bool isIndex = true;

		[ORKEditorHelp("Check Battle Group", "Check the battle group member index.\n" +
			"If disabled, the whole group member index will be checked.", "")]
		public bool battleGroup = true;

		public GroupMemberIndexRequirementType()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.battleGroup ?
				(combatant.Group.GetBattleMemberIndex(combatant) == this.index) == this.isIndex :
				(combatant.Group.GetMemberIndex(combatant) == this.index) == this.isIndex;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.GroupChanged += notify.CombatantGroupChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.GroupChanged -= notify.CombatantGroupChanged;
		}
	}
}
