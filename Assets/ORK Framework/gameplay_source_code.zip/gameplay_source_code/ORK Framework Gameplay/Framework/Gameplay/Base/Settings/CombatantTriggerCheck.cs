﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantTriggerCheck : BaseData
	{
		[ORKEditorHelp("Check Time", "Check the time the combatant is within the combatant trigger.", "")]
		public bool checkTime = false;

		[ORKEditorLayout("checkTime", true, endCheckGroup=true)]
		public ValueCheck check = new ValueCheck();


		// tags
		[ORKEditorHelp("Needed", "Either all or only one tag must be added to the combatant trigger component.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Tags")]
		public Needed needed = Needed.All;

		[ORKEditorInfo(hideName=true, separator=true)]
		[ORKEditorArray(false, "Add Tag", "Adds a tag that will be checked.", "",
			"Remove", "Removes this tag.", "", isHorizontal=true)]
		public string[] tags = new string[0];

		public CombatantTriggerCheck()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeFloatValue(data, "check", "value", "value2");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Check(Combatant combatant, CombatantTriggerComponent trigger)
		{
			if(combatant != null &&
				trigger != null &&
				trigger.IsActive &&
				(this.tags.Length == 0 ||
					trigger.CheckTags(this.tags, this.needed)))
			{
				if(this.checkTime)
				{
					float time = trigger.GetTime(combatant);
					return time >= 0 &&
						this.check.Check(time, combatant);
				}
				else
				{
					return trigger.Contains(combatant);
				}
			}
			return false;
		}

		public bool Check(Combatant user, Combatant combatant)
		{
			if(user != null &&
				combatant != null)
			{
				List<CombatantTriggerComponent> triggers = user.Object.Triggers;
				if(triggers.Count > 0)
				{
					if(this.checkTime)
					{
						for(int i = 0; i < triggers.Count; i++)
						{
							if(triggers[i] != null &&
								triggers[i].IsActive &&
								(this.tags.Length == 0 ||
									triggers[i].CheckTags(this.tags, this.needed)))
							{
								float time = triggers[i].GetTime(combatant);
								return time >= 0 &&
									this.check.Check(time, user, combatant);
							}
						}
					}
					else
					{
						for(int i = 0; i < triggers.Count; i++)
						{
							if(triggers[i] != null &&
								triggers[i].IsActive &&
								(this.tags.Length == 0 ||
									triggers[i].CheckTags(this.tags, this.needed)))
							{
								return triggers[i].Contains(combatant);
							}
						}
					}
				}
			}
			return false;
		}

		public void GetCombatants(Combatant user, ref List<Combatant> list)
		{
			if(user != null)
			{
				List<CombatantTriggerComponent> triggers = user.Object.Triggers;
				if(triggers.Count > 0)
				{
					if(this.checkTime)
					{
						float tmpValue = this.check.value.GetValue(user, user);
						float tmpValue2 = this.check.value2 != null ? this.check.value2.GetValue(user, user) : 0;
						for(int i = 0; i < triggers.Count; i++)
						{
							if(triggers[i] != null &&
								triggers[i].IsActive &&
								(this.tags.Length == 0 ||
									triggers[i].CheckTags(this.tags, this.needed)))
							{
								triggers[i].GetInTrigger(ref list, tmpValue, tmpValue2, this.check.type);
							}
						}
					}
					else
					{
						for(int i = 0; i < triggers.Count; i++)
						{
							if(triggers[i] != null &&
								triggers[i].IsActive &&
								(this.tags.Length == 0 ||
									triggers[i].CheckTags(this.tags, this.needed)))
							{
								triggers[i].GetInTrigger(ref list);
							}
						}
					}
				}
			}
		}
	}
}
