﻿
using UnityEngine;
using UnityEngine.AI;
using ORKFramework.Behaviours;
using System.Collections.Generic;
using System.Reflection;

namespace ORKFramework
{
	public class MoveToInteractionSettings : BaseData
	{
		// move to interaction
		[ORKEditorHelp("Use Move To Interaction", "The player will automatically move to an interaction " +
			"(e.g. event interaction, item collector) before starting the interaction.", "")]
		public bool useMoveToInteraction = false;

		[ORKEditorHelp("Default Interaction Radius", "The default radius used for interaction game objects.\n" +
			"The destination of the movement will be calculated from the player's combatant radius, " +
			"the interaction's radius and the stop distance.", "")]
		[ORKEditorLayout("useMoveToInteraction", true)]
		public float defaultInteractionRadius = 1;

		[ORKEditorHelp("Stop Distance", "The distance in world units the player will stop before the interaction.", "")]
		public float defaultStopDistance = 1;

		[ORKEditorHelp("Interaction Distance", "The distance in world units the player must at least have to the destination position " +
			"to start the interaction after moving toward it.\n" +
			"The distance is checked less equal.", "")]
		public float interactionDistance = 0.1f;

		[ORKEditorHelp("Ignore Height Distance", "The distance on the height axis will be ignored for the distance check.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		public bool ignoreHeightDistance = true;

		[ORKEditorHelp("Don't Move When Closer", "Don't move to the interaction when the player " +
			"is already closer to it than the move destination.\n" +
			"If the interaction defined a destination object, this wont be used.", "")]
		public bool noMoveWhenCloser = true;


		// move position/speed component calls
		[ORKEditorHelp("Component Type", "Select the component used to move the player:\n" +
			"- Default: A simple movement component that will move directly to the destination.\n" +
			"- Nav Mesh Agent: Unity's built in NavMesh is used.\n" +
			"- Custom: A custom component is used.", "")]
		[ORKEditorInfo(separator=true, labelText="Move Component Settings", callbackAfter="button:movecomopnent")]
		public MoveComponentType compType = MoveComponentType.Default;

		[ORKEditorHelp("Add Component", "The component will be added to the combatant's game object, if it isn't added already.\n" +
			"If disabled, the component must already be attached to the combatant's game object (i.e. it's prefab).", "")]
		public bool compAdd = false;

		// NavMesh
		[ORKEditorHelp("Sample Distance", "Define the distance in which the nearest position on the NavMesh will be searched.", "")]
		[ORKEditorLayout("compType", MoveComponentType.NavMeshAgent)]
		public float navMeshSampleDistance = 5;

		[ORKEditorHelp("Area Mask", "A mask specifying which NavMesh areas are allowed when finding the nearest point.\n" +
			"Defaults to all areas (-1).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public int navMeshSampleAreaMask = NavMesh.AllAreas;

		// custom component
		[ORKEditorHelp("Component Name", "The name of the custom component used to move the player.\n" +
			"If the component is in a namespace, you must define the full path (e.g. MyNamespace.ComponentName).", "")]
		[ORKEditorLayout("compType", MoveComponentType.Custom)]
		[ORKEditorInfo(expandWidth=true)]
		public string compName = "";

		[ORKEditorHelp("Speed Method Name", "The name of the method used to set the move speed.\n" +
			"Requires a method that takes a float value as parameter.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string compSpeedMethod = "";

		[ORKEditorHelp("Position Method Name", "The name of the method used to set the move position.\n" +
			"Requires a method that takes a Vector3 value as parameter.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string compPositionMethod = "";

		[ORKEditorHelp("Stop Method Name", "The name of the method used to stop the movement.\n" +
			"Requires a method that takes no parameters.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string compStopMethod = "";


		// move speed
		[ORKEditorInfo(separator=true, labelText="Movement Speed")]
		public MoveSpeed speed = new MoveSpeed(MoveSpeedType.Run, 5);


		// block controls
		[ORKEditorHelp("Block Player Control", "The control of the player will be blocked while moving to an interaction.", "")]
		[ORKEditorInfo(separator=true, labelText="Control Blocks")]
		public bool blockPlayer = false;

		[ORKEditorHelp("Block Camera Control", "The control of the camera will be blocked while moving to an interaction.", "")]
		public bool blockCamera = false;


		// cancel keys
		[ORKEditorHelp("Cancel Input Key", "Select the input key that will cancel moving to an interaction.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, noAutoAdd=true, separator=true, labelText="Cancel Input Keys")]
		[ORKEditorArray(false, "Add Cancel Input Key", "Adds an input key that will cancel moving to an interaction.", "",
			"Remove", "Removes this input key.", "", isHorizontal=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int[] cancelKeyID = new int[0];

		public MoveToInteractionSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("ignoreYDistance"))
			{
				data.Get("ignoreYDistance", ref this.ignoreHeightDistance);
			}
		}

		public bool CancelMovement()
		{
			for(int i = 0; i < this.cancelKeyID.Length; i++)
			{
				if(ORK.InputKeys.Get(this.cancelKeyID[i]).GetButton())
				{
					return true;
				}
			}
			return false;
		}
	}
}
