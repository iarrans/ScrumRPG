﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Action Bar", "The combatant's action bar will be compared with a defined value.", "")]
	public class ActionBarRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Used Action Bar", "Check the combatant's used action bar.\n" +
			"If disabled, the action bar will be checked.", "")]
		public bool usedActionBar = false;

		public ValueCheck check = new ValueCheck();

		public ActionBarRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeFloat(data, "comparison", "value");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.check.Check(this.usedActionBar ?
					combatant.Battle.UsedActionBar :
					combatant.Battle.ActionBar,
				combatant);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Battle.ActionBarChanged += notify.CombatantActionBarChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Battle.ActionBarChanged -= notify.CombatantActionBarChanged;
		}
	}
}
