﻿
using UnityEngine;
using UnityEngine.SceneManagement;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Formulas
{
	public class FormulaString : BaseData
	{
		[ORKEditorHelp("Value Type", "Select where the string value comes from:\n" +
			"- Value: A defined value.\n" +
			"- Game Variable: The value of a game variable (string).\n" +
			"- Player Prefs: The value of a PlayerPrefs string variable.\n" +
			"- Scene Name: The name of the current scene.", "")]
		public StringValueType type = StringValueType.Value;

		[ORKEditorHelp("Value", "Depending on the 'Value Type':\n" +
		 	"- Value: The text will be used as value.\n" +
		 	"- Game Variable: The text is the key (name) of a game variable (string) that holds the value that will be used.\n" +
		 	"- Player Prefs: The text is the key of a PlayerPrefs string variable that holds the value that will be used.", "")]
		[ORKEditorInfo(expandWidth=true, isVariableField=true)]
		[ORKEditorLayout("type", StringValueType.SceneName, elseCheckGroup=true, endCheckGroup=true)]
		public string value = "";


		// variable
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used while calculating a formula and don't interfere with global variables. " +
			"The variable will be gone once the formula finished calculating.\n" +
			"When a formula is called from an event, the local variables are shared with the event and " +
			"will also be available in the running event (until the event ends)." +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.\n" +
			"- Selected: Variables assigned to selected data coming from an event.\n" +
			"When coming from a battle event, the variables are usually assigned to the ability or item of the action.\n" +
			"Only available when the formula was initially called by an event.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("type", StringValueType.GameVariable)]
		public VariableOrigin origin = VariableOrigin.Global;

		// selected data variable
		[ORKEditorHelp("Selected Key", "The selected key that will be used", "")]
		[ORKEditorInfo(indent=true, expandWidth=true)]
		[ORKEditorLayout("origin", VariableOrigin.Selected)]
		public string selectedKey = "";

		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public FormulaSelectedDataOrigin selectedDataOrigin;


		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID of the used object variables.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;

		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public FormulaStatusOrigin fromObject;

		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(indent=true, expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=3)]
		public string objectID = "";

		public FormulaString()
		{

		}

		public FormulaString(string value)
		{
			this.type = StringValueType.Value;
			this.value = value;
		}

		public string GetValue(FormulaCall call)
		{
			if(StringValueType.Value == this.type)
			{
				return this.value;
			}
			else if(StringValueType.GameVariable == this.type)
			{
				if(VariableOrigin.Local == this.origin)
				{
					return call.Variables.GetString(this.value);
				}
				else if(VariableOrigin.Global == this.origin)
				{
					return ORK.Game.Variables.GetString(this.value);
				}
				else if(VariableOrigin.Object == this.origin)
				{
					if(this.useObject)
					{
						Combatant combatant = this.fromObject.GetCombatant(call);
						if(combatant != null)
						{
							return combatant.Variables.GetString(this.value);
						}
					}
					else
					{
						return ORK.Game.Scene.GetObjectVariables(this.objectID).GetString(this.value);
					}
				}
				else if(VariableOrigin.Selected == this.origin)
				{
					SelectedDataHandler selectedData = this.selectedDataOrigin.Get(call);
					if(selectedData != null)
					{
						VariableHandler handler = SelectedDataHelper.GetFirstVariableHandler(selectedData.Get(this.selectedKey));
						if(handler != null)
						{
							return handler.GetString(this.value);
						}
					}
				}
			}
			else if(StringValueType.PlayerPrefs == this.type)
			{
				return PlayerPrefs.GetString(this.value);
			}
			else if(StringValueType.SceneName == this.type)
			{
				return SceneManager.GetActiveScene().name;
			}
			return "";
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(StringValueType.SceneName == this.type)
			{
				return "Scene Name";
			}
			else if(StringValueType.Value == this.type)
			{
				return this.value;
			}
			else if(StringValueType.GameVariable == this.type)
			{
				return this.value + " (" + this.origin + ")";
			}
			return this.value + " (" + this.type + ")";
		}
	}
}

