
using UnityEngine;

namespace ORKFramework
{
	public class GameStatistic : BaseData, ISaveData
	{
		// enemies
		[ORKEditorHelp("Total Killed", "The sum of all killed enemies will be logged.", "")]
		[ORKEditorInfo(labelText="Enemy Statistics")]
		public bool logKilledEnemies = false;

		[ORKEditorHelp("Single Killed", "The number of killed enemies will be logged separated by enemy.", "")]
		public bool logSingleEnemies = false;


		// items
		[ORKEditorHelp("Total Used", "The sum of all used items will be logged.", "")]
		[ORKEditorInfo(separator=true, labelText="Item Statistics")]
		public bool logUsedItems = false;

		[ORKEditorHelp("Single Used", "The number of used items will be logged, separated by item.", "")]
		public bool logSingleItems = false;

		[ORKEditorHelp("Total Created", "The sum of all created items (using crafting recipes) will be logged.", "")]
		public bool logCreatedItems = false;

		[ORKEditorHelp("Single Created", "The number of created items (using crafting recipes) will be logged, separated by item.", "")]
		public bool logSingleCreated = false;

		[ORKEditorHelp("Total Battle Gains", "The sum of all items collected as battle gains will be logged.", "")]
		public bool logTotalBattleGains = false;

		[ORKEditorHelp("Single Battle Gains", "The number of items collected as battle gains will be logged, separated by item.", "")]
		public bool logSingleBattleGains = false;


		// battles
		[ORKEditorHelp("Total Battles", "The sum of all battles will be logged.", "")]
		[ORKEditorInfo(separator=true, labelText="Battle Statistics")]
		public bool logBattles = false;

		[ORKEditorHelp("Won Battles", "The sum of battles won by the party will be logged.", "")]
		public bool logWonBattles = false;

		[ORKEditorHelp("Lost Battles", "The sum of battles lost by the party will be logged.", "")]
		public bool logLostBattles = false;

		[ORKEditorHelp("Escaped Battles", "The sum of battles where the party escaped will be logged.", "")]
		public bool logEscapedBattles = false;


		// custom
		[ORKEditorHelp("Custom", "Custom statistics will be logged.\n" +
			"Custom statistics can be added by using game events and battle animations.", "")]
		[ORKEditorInfo(separator=true, labelText="Custom Statistics")]
		public bool logCustom = false;


		// ingame
		// enemies
		private int killedEnemies = 0;
		private int[] singleEnemies = new int[0];

		// items
		private int usedItems = 0;
		private int[] singleItems = new int[0];
		private int createdItems = 0;
		private int[] singleCreatedItems = new int[0];
		private int[] singleCreatedWeapons = new int[0];
		private int[] singleCreatedArmors = new int[0];
		private int[] singleCreatedAIBehaviours = new int[0];
		private int[] singleCreatedAIRulesets = new int[0];
		private int[] singleCreatedCraftingRecipes = new int[0];
		private int gainedItems = 0;
		private int[] singleGainedItems = new int[0];
		private int[] singleGainedWeapons = new int[0];
		private int[] singleGainedArmors = new int[0];
		private int[] singleGainedAIBehaviours = new int[0];
		private int[] singleGainedAIRulesets = new int[0];
		private int[] singleGainedCraftingRecipes = new int[0];

		// battles
		private int battles = 0;
		private int wonBattles = 0;
		private int lostBattles = 0;
		private int escapedBattles = 0;

		// custom
		private int[] custom = new int[0];

		public GameStatistic()
		{

		}

		public void Clear()
		{
			if(this.logKilledEnemies)
			{
				this.killedEnemies = 0;
			}
			if(this.logSingleEnemies)
			{
				this.singleEnemies = new int[ORK.Combatants.Count];
			}
			if(this.logUsedItems)
			{
				this.usedItems = 0;
			}
			if(this.logSingleItems)
			{
				this.singleItems = new int[ORK.Items.Count];
			}
			if(this.logCreatedItems)
			{
				this.createdItems = 0;
			}
			if(this.logSingleCreated)
			{
				this.singleCreatedItems = new int[ORK.Items.Count];
				this.singleCreatedWeapons = new int[ORK.Weapons.Count];
				this.singleCreatedArmors = new int[ORK.Armors.Count];
				this.singleCreatedAIBehaviours = new int[ORK.AIBehaviours.Count];
				this.singleCreatedAIRulesets = new int[ORK.AIRulesets.Count];
				this.singleCreatedCraftingRecipes = new int[ORK.CraftingRecipes.Count];
			}
			if(this.logTotalBattleGains)
			{
				this.gainedItems = 0;
			}
			if(this.logSingleBattleGains)
			{
				this.singleGainedItems = new int[ORK.Items.Count];
				this.singleGainedWeapons = new int[ORK.Weapons.Count];
				this.singleGainedArmors = new int[ORK.Armors.Count];
				this.singleGainedAIBehaviours = new int[ORK.AIBehaviours.Count];
				this.singleGainedAIRulesets = new int[ORK.AIRulesets.Count];
				this.singleGainedCraftingRecipes = new int[ORK.CraftingRecipes.Count];
			}
			if(this.logBattles)
			{
				this.battles = 0;
			}
			if(this.logWonBattles)
			{
				this.wonBattles = 0;
			}
			if(this.logLostBattles)
			{
				this.lostBattles = 0;
			}
			if(this.logEscapedBattles)
			{
				this.escapedBattles = 0;
			}
			if(this.logCustom)
			{
				this.custom = new int[0];
			}
		}


		/*
		============================================================================
		Type functions
		============================================================================
		*/
		public void Clear(StatisticType type, int index)
		{
			if(StatisticType.TotalKilled == type)
			{
				this.killedEnemies = 0;
			}
			else if(StatisticType.SingleKilled == type)
			{
				if(index >= 0 && index < this.singleEnemies.Length)
				{
					this.singleEnemies[index] = 0;
				}
			}
			else if(StatisticType.TotalUsed == type)
			{
				this.usedItems = 0;
			}
			else if(StatisticType.SingleUsed == type)
			{
				if(index >= 0 && index < this.singleItems.Length)
				{
					this.singleItems[index] = 0;
				}
			}
			else if(StatisticType.TotalCreated == type)
			{
				this.createdItems = 0;
			}
			else if(StatisticType.SingleCreatedItem == type)
			{
				if(index >= 0 && index < this.singleCreatedItems.Length)
				{
					this.singleCreatedItems[index] = 0;
				}
			}
			else if(StatisticType.SingleCreatedWeapon == type)
			{
				if(index >= 0 && index < this.singleCreatedWeapons.Length)
				{
					this.singleCreatedWeapons[index] = 0;
				}
			}
			else if(StatisticType.SingleCreatedArmor == type)
			{
				if(index >= 0 && index < this.singleCreatedArmors.Length)
				{
					this.singleCreatedArmors[index] = 0;
				}
			}
			else if(StatisticType.SingleCreatedAIBehaviour == type)
			{
				if(index >= 0 && index < this.singleCreatedAIBehaviours.Length)
				{
					this.singleCreatedAIBehaviours[index] = 0;
				}
			}
			else if(StatisticType.SingleCreatedAIRuleset == type)
			{
				if(index >= 0 && index < this.singleCreatedAIRulesets.Length)
				{
					this.singleCreatedAIRulesets[index] = 0;
				}
			}
			else if(StatisticType.SingleCreatedCraftingRecipes == type)
			{
				if(index >= 0 && index < this.singleCreatedCraftingRecipes.Length)
				{
					this.singleCreatedCraftingRecipes[index] = 0;
				}
			}
			else if(StatisticType.TotalGained == type)
			{
				this.gainedItems = 0;
			}
			else if(StatisticType.SingleGainedItem == type)
			{
				if(index >= 0 && index < this.singleGainedItems.Length)
				{
					this.singleGainedItems[index] = 0;
				}
			}
			else if(StatisticType.SingleGainedWeapon == type)
			{
				if(index >= 0 && index < this.singleGainedWeapons.Length)
				{
					this.singleGainedWeapons[index] = 0;
				}
			}
			else if(StatisticType.SingleGainedArmor == type)
			{
				if(index >= 0 && index < this.singleGainedArmors.Length)
				{
					this.singleGainedArmors[index] = 0;
				}
			}
			else if(StatisticType.SingleGainedAIBehaviour == type)
			{
				if(index >= 0 && index < this.singleGainedAIBehaviours.Length)
				{
					this.singleGainedAIBehaviours[index] = 0;
				}
			}
			else if(StatisticType.SingleGainedAIRuleset == type)
			{
				if(index >= 0 && index < this.singleGainedAIRulesets.Length)
				{
					this.singleGainedAIRulesets[index] = 0;
				}
			}
			else if(StatisticType.SingleGainedCraftingRecipes == type)
			{
				if(index >= 0 && index < this.singleGainedCraftingRecipes.Length)
				{
					this.singleGainedCraftingRecipes[index] = 0;
				}
			}
			else if(StatisticType.TotalBattles == type)
			{
				this.battles = 0;
			}
			else if(StatisticType.WonBattles == type)
			{
				this.wonBattles = 0;
			}
			else if(StatisticType.LostBattles == type)
			{
				this.lostBattles = 0;
			}
			else if(StatisticType.EscapedBattles == type)
			{
				this.escapedBattles = 0;
			}
			else if(StatisticType.Custom == type)
			{
				if(index >= 0 && index < this.custom.Length)
				{
					this.custom[index] = 0;
				}
			}
		}

		public int Get(StatisticType type, int index)
		{
			if(StatisticType.TotalKilled == type)
			{
				return this.killedEnemies;
			}
			else if(StatisticType.SingleKilled == type)
			{
				if(index >= 0 && index < this.singleEnemies.Length)
				{
					return this.singleEnemies[index];
				}
			}
			else if(StatisticType.TotalUsed == type)
			{
				return this.usedItems;
			}
			else if(StatisticType.SingleUsed == type)
			{
				if(index >= 0 && index < this.singleItems.Length)
				{
					return this.singleItems[index];
				}
			}
			else if(StatisticType.TotalCreated == type)
			{
				return this.createdItems;
			}
			else if(StatisticType.SingleCreatedItem == type)
			{
				if(index >= 0 && index < this.singleCreatedItems.Length)
				{
					return this.singleCreatedItems[index];
				}
			}
			else if(StatisticType.SingleCreatedWeapon == type)
			{
				if(index >= 0 && index < this.singleCreatedWeapons.Length)
				{
					return this.singleCreatedWeapons[index];
				}
			}
			else if(StatisticType.SingleCreatedArmor == type)
			{
				if(index >= 0 && index < this.singleCreatedArmors.Length)
				{
					return this.singleCreatedArmors[index];
				}
			}
			else if(StatisticType.SingleCreatedAIBehaviour == type)
			{
				if(index >= 0 && index < this.singleCreatedAIBehaviours.Length)
				{
					return this.singleCreatedAIBehaviours[index];
				}
			}
			else if(StatisticType.SingleCreatedAIRuleset == type)
			{
				if(index >= 0 && index < this.singleCreatedAIRulesets.Length)
				{
					return this.singleCreatedAIRulesets[index];
				}
			}
			else if(StatisticType.SingleCreatedCraftingRecipes == type)
			{
				if(index >= 0 && index < this.singleCreatedCraftingRecipes.Length)
				{
					return this.singleCreatedCraftingRecipes[index];
				}
			}
			else if(StatisticType.TotalGained == type)
			{
				return this.gainedItems;
			}
			else if(StatisticType.SingleGainedItem == type)
			{
				if(index >= 0 && index < this.singleGainedItems.Length)
				{
					return this.singleGainedItems[index];
				}
			}
			else if(StatisticType.SingleGainedWeapon == type)
			{
				if(index >= 0 && index < this.singleGainedWeapons.Length)
				{
					return this.singleGainedWeapons[index];
				}
			}
			else if(StatisticType.SingleGainedArmor == type)
			{
				if(index >= 0 && index < this.singleGainedArmors.Length)
				{
					return this.singleGainedArmors[index];
				}
			}
			else if(StatisticType.SingleGainedAIBehaviour == type)
			{
				if(index >= 0 && index < this.singleGainedAIBehaviours.Length)
				{
					return this.singleGainedAIBehaviours[index];
				}
			}
			else if(StatisticType.SingleGainedAIRuleset == type)
			{
				if(index >= 0 && index < this.singleGainedAIRulesets.Length)
				{
					return this.singleGainedAIRulesets[index];
				}
			}
			else if(StatisticType.SingleGainedCraftingRecipes == type)
			{
				if(index >= 0 && index < this.singleGainedCraftingRecipes.Length)
				{
					return this.singleGainedCraftingRecipes[index];
				}
			}
			else if(StatisticType.TotalBattles == type)
			{
				return this.battles;
			}
			else if(StatisticType.WonBattles == type)
			{
				return this.wonBattles;
			}
			else if(StatisticType.LostBattles == type)
			{
				return this.lostBattles;
			}
			else if(StatisticType.EscapedBattles == type)
			{
				return this.escapedBattles;
			}
			else if(StatisticType.Custom == type)
			{
				if(index >= 0 && index < this.custom.Length)
				{
					return this.custom[index];
				}
			}
			return 0;
		}


		/*
		============================================================================
		Text functions
		============================================================================
		*/
		public void GetStatisticText(ref string text)
		{
			if(text.Contains("#*"))
			{
				// enemies
				text = text.Replace(TextCode.Statistic_KilledTotal,
					ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetKilledEnemies()));

				int replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_KilledEnemy, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_KilledEnemy + replace + "#",
						ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetKilledEnemy(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_KilledEnemy, 0);
				}

				// items
				text = text.Replace(TextCode.Statistic_UsedTotal,
					this.GetUsedItems().ToString(ORK.TextDisplaySettings.numberFormatting.itemQuantityFormat));

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_UsedItem, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_UsedItem + replace + "#",
						ORK.Items.Get(replace).FormatQuantity(this.GetUsedItem(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_UsedItem, 0);
				}

				// created items
				text = text.Replace(TextCode.Statistic_CreatedTotal,
					this.GetCreatedItems().ToString(ORK.TextDisplaySettings.numberFormatting.itemQuantityFormat));

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedItem, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_CreatedItem + replace + "#",
						ORK.Items.Get(replace).FormatQuantity(this.GetCreatedItem(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedItem, 0);
				}

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedWeapon, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_CreatedWeapon + replace + "#",
						ORK.Weapons.Get(replace).FormatQuantity(this.GetCreatedWeapon(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedWeapon, 0);
				}

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedArmor, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_CreatedArmor + replace + "#",
						ORK.Armors.Get(replace).FormatQuantity(this.GetCreatedArmor(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedArmor, 0);
				}

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedAIBehaviour, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_CreatedAIBehaviour + replace + "#",
						ORK.AIBehaviours.Get(replace).FormatQuantity(this.GetCreatedAIBehaviour(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedAIBehaviour, 0);
				}

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedAIRuleset, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_CreatedAIRuleset + replace + "#",
						ORK.AIRulesets.Get(replace).FormatQuantity(this.GetCreatedAIRuleset(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedAIRuleset, 0);
				}

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedCraftingRecipe, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_CreatedCraftingRecipe + replace + "#",
						ORK.CraftingRecipes.Get(replace).FormatQuantity(this.GetCreatedCraftingRecipes(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_CreatedCraftingRecipe, 0);
				}

				// gained items
				text = text.Replace(TextCode.Statistic_GainedTotal,
					this.GetGainedItems().ToString(ORK.TextDisplaySettings.numberFormatting.itemQuantityFormat));

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_GainedItem, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_GainedItem + replace + "#",
						ORK.Items.Get(replace).FormatQuantity(this.GetGainedItem(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_GainedItem, 0);
				}

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_GainedWeapon, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_GainedWeapon + replace + "#",
						ORK.Weapons.Get(replace).FormatQuantity(this.GetGainedWeapon(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_GainedWeapon, 0);
				}

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_GainedArmor, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_GainedArmor + replace + "#",
						ORK.Armors.Get(replace).FormatQuantity(this.GetGainedArmor(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_GainedArmor, 0);
				}

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_GainedAIBehaviour, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_GainedAIBehaviour + replace + "#",
						ORK.AIBehaviours.Get(replace).FormatQuantity(this.GetGainedAIBehaviour(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_GainedAIBehaviour, 0);
				}

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_GainedAIRuleset, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_GainedAIRuleset + replace + "#",
						ORK.AIRulesets.Get(replace).FormatQuantity(this.GetGainedAIRuleset(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_GainedAIRuleset, 0);
				}

				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_GainedCraftingRecipe, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_GainedCraftingRecipe + replace + "#",
						ORK.CraftingRecipes.Get(replace).FormatQuantity(this.GetGainedCraftingRecipes(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_GainedCraftingRecipe, 0);
				}

				// battles
				text = text.Replace(TextCode.Statistic_BattlesTotal,
					ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetBattles()));
				text = text.Replace(TextCode.Statistic_BattlesWon,
					ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetWonBattles()));
				text = text.Replace(TextCode.Statistic_BattlesLost,
					ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetLostBattles()));
				text = text.Replace(TextCode.Statistic_BattlesEscaped,
					ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetEscapedBattles()));

				// custom
				replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_Custom, 0);
				while(replace != -2)
				{
					text = text.Replace(TextCode.Statistic_Custom + replace + "#",
						ORK.TextDisplaySettings.numberFormatting.FormatInt(this.GetCustom(replace)));
					replace = TextHelper.NextSpecial(ref text, TextCode.Statistic_Custom, 0);
				}
			}
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public void EnemyKilled(int id)
		{
			if(this.logKilledEnemies)
			{
				this.killedEnemies++;
			}
			if(this.logSingleEnemies && id < this.singleEnemies.Length)
			{
				this.singleEnemies[id]++;
			}
		}

		public int GetKilledEnemies()
		{
			return this.killedEnemies;
		}

		public int GetKilledEnemy(int id)
		{
			if(id < this.singleEnemies.Length)
			{
				return this.singleEnemies[id];
			}
			else
			{
				return 0;
			}
		}


		/*
		============================================================================
		Item functions
		============================================================================
		*/
		public void ItemUsed(int id)
		{
			if(this.logUsedItems)
			{
				this.usedItems++;
			}
			if(this.logSingleItems && id < this.singleItems.Length)
			{
				this.singleItems[id]++;
			}
		}

		public int GetUsedItems()
		{
			return this.usedItems;
		}

		public int GetUsedItem(int id)
		{
			if(id < this.singleItems.Length)
			{
				return this.singleItems[id];
			}
			else
			{
				return 0;
			}
		}


		/*
		============================================================================
		Created item functions
		============================================================================
		*/
		public void ItemCreated(int id, int quantity, ItemDropType type)
		{
			if(this.logCreatedItems)
			{
				this.createdItems += quantity;
			}
			if(this.logSingleCreated)
			{
				if(ItemDropType.Item == type &&
					id < this.singleCreatedItems.Length)
				{
					this.singleCreatedItems[id] += quantity;
				}
				else if(ItemDropType.Weapon == type &&
					id < this.singleCreatedWeapons.Length)
				{
					this.singleCreatedWeapons[id] += quantity;
				}
				else if(ItemDropType.Armor == type &&
					id < this.singleCreatedArmors.Length)
				{
					this.singleCreatedArmors[id] += quantity;
				}
				else if(ItemDropType.AIBehaviour == type &&
					id < this.singleCreatedAIBehaviours.Length)
				{
					this.singleCreatedAIBehaviours[id] += quantity;
				}
				else if(ItemDropType.AIRuleset == type &&
					id < this.singleCreatedAIRulesets.Length)
				{
					this.singleCreatedAIRulesets[id] += quantity;
				}
				else if(ItemDropType.CraftingRecipe == type &&
					id < this.singleCreatedCraftingRecipes.Length)
				{
					this.singleCreatedCraftingRecipes[id] += quantity;
				}
			}
		}

		public int GetCreatedItems()
		{
			return this.createdItems;
		}

		public int GetCreatedItem(int id)
		{
			if(id < this.singleCreatedItems.Length)
			{
				return this.singleCreatedItems[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetCreatedWeapon(int id)
		{
			if(id < this.singleCreatedWeapons.Length)
			{
				return this.singleCreatedWeapons[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetCreatedArmor(int id)
		{
			if(id < this.singleCreatedArmors.Length)
			{
				return this.singleCreatedArmors[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetCreatedAIBehaviour(int id)
		{
			if(id < this.singleCreatedAIBehaviours.Length)
			{
				return this.singleCreatedAIBehaviours[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetCreatedAIRuleset(int id)
		{
			if(id < this.singleCreatedAIRulesets.Length)
			{
				return this.singleCreatedAIRulesets[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetCreatedCraftingRecipes(int id)
		{
			if(id < this.singleCreatedCraftingRecipes.Length)
			{
				return this.singleCreatedCraftingRecipes[id];
			}
			else
			{
				return 0;
			}
		}


		/*
		============================================================================
		Gained item functions
		============================================================================
		*/
		public void ItemGained(int id, int quantity, ItemDropType type)
		{
			if(this.logTotalBattleGains)
			{
				this.gainedItems += quantity;
			}
			if(this.logSingleBattleGains)
			{
				if(ItemDropType.Item == type &&
					id < this.singleGainedItems.Length)
				{
					this.singleGainedItems[id] += quantity;
				}
				else if(ItemDropType.Weapon == type &&
					id < this.singleGainedWeapons.Length)
				{
					this.singleGainedWeapons[id] += quantity;
				}
				else if(ItemDropType.Armor == type &&
					id < this.singleGainedArmors.Length)
				{
					this.singleGainedArmors[id] += quantity;
				}
				else if(ItemDropType.AIBehaviour == type &&
					id < this.singleGainedAIBehaviours.Length)
				{
					this.singleGainedAIBehaviours[id] += quantity;
				}
				else if(ItemDropType.AIRuleset == type &&
					id < this.singleGainedAIRulesets.Length)
				{
					this.singleGainedAIRulesets[id] += quantity;
				}
				else if(ItemDropType.CraftingRecipe == type &&
					id < this.singleGainedCraftingRecipes.Length)
				{
					this.singleGainedCraftingRecipes[id] += quantity;
				}
			}
		}

		public int GetGainedItems()
		{
			return this.gainedItems;
		}

		public int GetGainedItem(int id)
		{
			if(id < this.singleGainedItems.Length)
			{
				return this.singleGainedItems[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetGainedWeapon(int id)
		{
			if(id < this.singleGainedWeapons.Length)
			{
				return this.singleGainedWeapons[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetGainedArmor(int id)
		{
			if(id < this.singleGainedArmors.Length)
			{
				return this.singleGainedArmors[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetGainedAIBehaviour(int id)
		{
			if(id < this.singleGainedAIBehaviours.Length)
			{
				return this.singleGainedAIBehaviours[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetGainedAIRuleset(int id)
		{
			if(id < this.singleGainedAIRulesets.Length)
			{
				return this.singleGainedAIRulesets[id];
			}
			else
			{
				return 0;
			}
		}

		public int GetGainedCraftingRecipes(int id)
		{
			if(id < this.singleGainedCraftingRecipes.Length)
			{
				return this.singleGainedCraftingRecipes[id];
			}
			else
			{
				return 0;
			}
		}


		/*
		============================================================================
		Battle functions
		============================================================================
		*/
		public void BattleStarted()
		{
			if(this.logBattles)
			{
				this.battles++;
			}
		}

		public void BattleWon()
		{
			if(this.logWonBattles)
			{
				this.wonBattles++;
			}
		}

		public void BattleLost()
		{
			if(this.logLostBattles)
			{
				this.lostBattles++;
			}
		}

		public void BattleEscaped()
		{
			if(this.logEscapedBattles)
			{
				this.escapedBattles++;
			}
		}

		public int GetBattles()
		{
			return this.battles;
		}

		public int GetWonBattles()
		{
			return this.wonBattles;
		}

		public int GetLostBattles()
		{
			return this.lostBattles;
		}

		public int GetEscapedBattles()
		{
			return this.escapedBattles;
		}


		/*
		============================================================================
		Custom functions
		============================================================================
		*/
		public void CustomChanged(int index, int add)
		{
			if(this.logCustom && index >= 0)
			{
				if(index >= this.custom.Length)
				{
					int[] tmp = this.custom;
					this.custom = new int[index + 1];
					System.Array.Copy(tmp, this.custom, tmp.Length);
				}
				this.custom[index] += add;
			}
		}

		public int GetCustom(int index)
		{
			if(index >= 0 && index < this.custom.Length)
			{
				return this.custom[index];
			}
			return 0;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			// enemies
			data.Set("killedEnemies", this.killedEnemies);
			data.Set("singleEnemies", this.singleEnemies);

			// items
			data.Set("usedItems", this.usedItems);
			data.Set("singleItems", this.singleItems);
			// crafted
			data.Set("createdItems", this.createdItems);
			data.Set("singleCreatedItems", this.singleCreatedItems);
			data.Set("singleCreatedWeapons", this.singleCreatedWeapons);
			data.Set("singleCreatedArmors", this.singleCreatedArmors);
			data.Set("singleCreatedAIBehaviours", this.singleCreatedAIBehaviours);
			data.Set("singleCreatedAIRulesets", this.singleCreatedAIRulesets);
			data.Set("singleCreatedCraftingRecipes", this.singleCreatedCraftingRecipes);
			// gained
			data.Set("gainedItems", this.gainedItems);
			data.Set("singleGainedItems", this.singleGainedItems);
			data.Set("singleGainedWeapons", this.singleGainedWeapons);
			data.Set("singleGainedArmors", this.singleGainedArmors);
			data.Set("singleGainedAIBehaviours", this.singleGainedAIBehaviours);
			data.Set("singleGainedAIRulesets", this.singleGainedAIRulesets);
			data.Set("singleGainedCraftingRecipes", this.singleGainedCraftingRecipes);

			// battles
			data.Set("battles", this.battles);
			data.Set("wonBattles", this.wonBattles);
			data.Set("lostBattles", this.lostBattles);
			data.Set("escapedBattles", this.escapedBattles);

			// custom
			data.Set("custom", this.custom);

			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.Clear();
			if(data != null)
			{
				// enemies
				data.Get("killedEnemies", ref this.killedEnemies);
				data.Get("singleEnemies", out this.singleEnemies);

				// items
				int[] tmp = null;
				data.Get("usedItems", ref this.usedItems);
				this.LoadArray(data, "singleItems", tmp, this.singleItems);
				// crafted
				data.Get("createdItems", ref this.createdItems);
				this.LoadArray(data, "singleCreatedItems", tmp, this.singleCreatedItems);
				this.LoadArray(data, "singleCreatedWeapons", tmp, this.singleCreatedWeapons);
				this.LoadArray(data, "singleCreatedArmors", tmp, this.singleCreatedArmors);
				this.LoadArray(data, "singleCreatedAIBehaviours", tmp, this.singleCreatedAIBehaviours);
				this.LoadArray(data, "singleCreatedAIRulesets", tmp, this.singleCreatedAIRulesets);
				this.LoadArray(data, "singleCreatedCraftingRecipes", tmp, this.singleCreatedCraftingRecipes);
				// gained
				data.Get("gainedItems", ref this.gainedItems);
				this.LoadArray(data, "singleGainedItems", tmp, this.singleGainedItems);
				this.LoadArray(data, "singleGainedWeapons", tmp, this.singleGainedWeapons);
				this.LoadArray(data, "singleGainedArmors", tmp, this.singleGainedArmors);
				this.LoadArray(data, "singleGainedAIBehaviours", tmp, this.singleGainedAIBehaviours);
				this.LoadArray(data, "singleGainedAIRulesets", tmp, this.singleGainedAIRulesets);
				this.LoadArray(data, "singleGainedCraftingRecipes", tmp, this.singleGainedCraftingRecipes);

				// battles
				data.Get("battles", ref this.battles);
				data.Get("wonBattles", ref this.wonBattles);
				data.Get("lostBattles", ref this.lostBattles);
				data.Get("escapedBattles", ref this.escapedBattles);

				// custom
				data.Get("custom", out this.custom);
			}
		}

		private void LoadArray(DataObject data, string name, int[] source, int[] destination)
		{
			if(destination != null)
			{
				source = null;
				data.Get(name, out source);
				if(source != null)
				{
					System.Array.Copy(source, destination, Mathf.Min(source.Length, destination.Length));
				}
			}
		}
	}
}
