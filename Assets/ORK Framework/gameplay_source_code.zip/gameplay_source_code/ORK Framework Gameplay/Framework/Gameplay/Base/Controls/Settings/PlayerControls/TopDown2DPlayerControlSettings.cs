﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TopDown2DPlayerControlSettings : BaseData
	{
		[ORKEditorHelp("Vertical Axis", "The key used for vertical control.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int verticalAxis = 2;

		[ORKEditorHelp("Horizontal Axis", "The key used for horizontal control.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int horizontalAxis = 1;


		// flipping
		[ORKEditorHelp("Vertical Flip", "Vertically flip the player (i.e. negating the Y-axis scale).", "")]
		[ORKEditorInfo(separator=true)]
		public bool verticalFlip = false;

		[ORKEditorHelp("Negate Flip", "Negate the flip direction, i.e. down will flip positive, up will flip negative.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("verticalFlip", true, endCheckGroup=true)]
		public bool verticalFlipNegate = false;

		[ORKEditorHelp("Horizontal Flip", "Horizontally flip the player (i.e. negating the X-axis scale).", "")]
		public bool horizontalFlip = false;

		[ORKEditorHelp("Negate Flip", "Negate the flip direction, i.e. left will flip positive, right will flip negative.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("horizontalFlip", true, endCheckGroup=true)]
		public bool horizontalFlipNegate = false;

		[ORKEditorHelp("Flip Input Ignore", "Don't flip if the input axis is below this value.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float flipInputIgnore = 0.1f;


		// sprint
		[ORKEditorHelp("Use Sprint", "The player can sprint.", "")]
		[ORKEditorInfo("Sprint Settings", "Optionally allow the player to sprint.", "")]
		public bool useSprint = false;

		[ORKEditorHelp("Sprint Key", "The key used to sprint.\n" +
			"The key must be held down to sprint - select handling type Hold in the settings of the key.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useSprint", true)]
		public int sprintKey = 0;

		[ORKEditorHelp("Sprint Factor", "The players move speed will be multiplied with this number when sprinting.\n" +
			"E.g. 2 will double the move speed.", "")]
		public float sprintFactor = 2.0f;

		[ORKEditorHelp("Use Energy", "Sprinting will consume energy.", "")]
		public bool useEnergy = false;

		[ORKEditorInfo("Maximum Energy", "The maximum sprint energy.", "", endFoldout=true)]
		[ORKEditorLayout("useEnergy", true)]
		public FloatValue maxEnergy = new FloatValue();

		[ORKEditorInfo("Energy Consume", "The energy consumed per second when sprinting.", "", endFoldout=true)]
		public FloatValue energyConsume = new FloatValue();

		[ORKEditorInfo("Energy Regeneration", "The energy regenerated per second.", "", endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public FloatValue energyRegeneration = new FloatValue();

		public TopDown2DPlayerControlSettings()
		{

		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public void AddPlayerControl(GameObject player)
		{
			TopDown2DPlayerController comp = player.GetComponent<TopDown2DPlayerController>();
			if(comp == null)
			{
				comp = player.AddComponent<TopDown2DPlayerController>();
			}
			comp.moveDead = ORK.GameControls.playerControl.moveDead;
			comp.useCharacterSpeed = ORK.GameControls.playerControl.useSpeed;
			comp.runSpeed = ORK.GameControls.playerControl.runSpeed;
			comp.gravity = ORK.GameControls.playerControl.gravity;
			comp.speedSmoothing = ORK.GameControls.playerControl.speedSmoothing;
			comp.verticalAxis = this.verticalAxis;
			comp.horizontalAxis = this.horizontalAxis;
			comp.horizontalFlip = this.horizontalFlip;
			comp.horizontalFlipNegate = this.horizontalFlipNegate;
			comp.verticalFlip = this.verticalFlip;
			comp.verticalFlipNegate = this.verticalFlipNegate;
			comp.flipInputIgnore = this.flipInputIgnore;
			comp.useSprint = this.useSprint;
			comp.sprintKey = this.sprintKey;
			comp.sprintFactor = this.sprintFactor;
			comp.useEnergy = this.useEnergy;
			comp.maxEnergy = this.maxEnergy;
			comp.energyConsume = this.energyConsume;
			comp.energyRegeneration = this.energyRegeneration;

			ORK.Control.AddPlayerControl(comp);
		}

		public void RemovePlayerControl(GameObject player)
		{
			TopDown2DPlayerController comp = player.GetComponent<TopDown2DPlayerController>();
			if(comp != null)
			{
				ORK.Control.RemovePlayerControl(comp);
				GameObject.Destroy(comp);
			}
		}
	}
}
