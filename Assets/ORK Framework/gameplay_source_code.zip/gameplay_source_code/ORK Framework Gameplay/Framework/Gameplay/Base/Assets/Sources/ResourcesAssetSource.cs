﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[ORKEditorSettingInfo("Resources", "Select the asset stored in a 'Resources' folder that will be used.\n" +
		"This only saves the path within the 'Resources' folder.", "")]
	public class ResourcesAssetSource<T> : BaseAssetSource<T> where T : UnityEngine.Object
	{
		[ORKEditorHelp("Asset", "Select the asset that will be used.\n" +
			"The asset has to be placed in a 'Resources' folder.\n" +
			"Only the asset's path within the 'Resources' folder will be saved, not a reference to the actual asset.", "")]
		[ORKEditorInfo(hide=true, hideName=true, setWidth=true, fieldWidth=150)]
		public T asset;

		[ORKEditorInfo(hide=true)]
		public string resourcePath = "";

		public ResourcesAssetSource()
		{

		}

		public override DataObject GetData()
		{
			DataObject data = new DataObject();
			data.Set("resourcePath", this.resourcePath);
			data.Set(DataSerializer.TYPE, this.GetTypeNamespace() + this.GetType().Name);
			return data;
		}

		public override T Get()
		{
			return AssetSourceCache.Instance.GetFromResources<T>(this.resourcePath);
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public override bool EditorHasAssetField
		{
			get { return true; }
		}

		public override Object EditorAsset
		{
			get { return this.asset; }
			set { this.asset = value as T; }
		}

		public override bool HasAsset
		{
			get { return !string.IsNullOrEmpty(this.resourcePath); }
		}

		public override void EditorBefore()
		{
			if(this.asset == null &&
				!string.IsNullOrEmpty(this.resourcePath))
			{
				this.asset = Resources.Load<T>(this.resourcePath);
				if(this.asset == null)
				{
					this.resourcePath = "";
				}
			}
		}

		public override void EditorAfter(bool assetChanged, string assetPath)
		{
			if(assetChanged)
			{
				if(!string.IsNullOrEmpty(assetPath))
				{
					int index = assetPath.IndexOf("/Resources/", System.StringComparison.Ordinal);
					if(index > 0)
					{
						index += 11;
						this.resourcePath = assetPath.Substring(index,
							assetPath.LastIndexOf('.') - index);
					}
					else
					{
						this.asset = null;
						this.resourcePath = "";
					}
				}
				else
				{
					this.asset = null;
					this.resourcePath = "";
				}
			}
		}

		public override string GetInfoText()
		{
			return this.resourcePath;
		}
	}
}
