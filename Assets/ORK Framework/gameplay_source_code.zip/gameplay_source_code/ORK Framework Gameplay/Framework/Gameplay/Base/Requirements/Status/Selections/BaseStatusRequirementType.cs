﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	public abstract class BaseStatusRequirementType : BaseTypeData
	{
		protected virtual string GetTypeNamespace()
		{
			return "Requirements.";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public abstract bool Check(Combatant combatant);

		public virtual bool CheckPreview(Combatant combatant)
		{
			return Check(combatant);
		}

		public virtual bool CheckBestiary(Combatant combatant)
		{
			return Check(combatant);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public abstract void Register(Combatant combatant, IStatusChanged notify);

		public abstract void Unregister(Combatant combatant, IStatusChanged notify);
	}
}
