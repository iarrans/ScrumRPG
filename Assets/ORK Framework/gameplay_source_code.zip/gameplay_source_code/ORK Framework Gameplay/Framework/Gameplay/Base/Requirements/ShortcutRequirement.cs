﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public enum ShortcutRequirementType { None, Ability, Item, Weapon, Armor, Currency };

	public class ShortcutRequirement : BaseData
	{
		[ORKEditorHelp("Shortcut Type", "Select if a type of shortcut is required:\n" +
			"- None: All shortcuts are allowed.\n" +
			"- Ability: Requires an ability.\n" +
			"- Item: Requires an item.\n" +
			"- Weapon: Requires a weapon.\n" +
			"- Armor: Requires an armor.\n" +
			"- Currency: Reqruies a currency.", "")]
		public ShortcutRequirementType type = ShortcutRequirementType.None;


		// ability
		[ORKEditorHelp("Is Passive Ability", "Select if the shortcut has to be a passive ability:\n" +
			"- Yes: The shortcut is a passive ability.\n" +
			"- No: The shortcut isn't a passive ability.\n" +
			"- Ignore: The type of shortcut is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		[ORKEditorLayout("type", ShortcutRequirementType.Ability)]
		public Consider isPassiveAbility = Consider.Ignore;

		[ORKEditorHelp("Has Use Count", "Select if the ability uses use count:\n" +
			"- Yes: The ability is using use count.\n" +
			"- No: The ability isn't using use count.\n" +
			"- Ignore: Use count is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		[ORKEditorLayout(endCheckGroup=true)]
		public Consider hasAbilityUseCount = Consider.Ignore;


		// ability/item > reuse
		[ORKEditorHelp("Has Reuse Time/Turns", "Select if the shortcut has to be an ability or item using reuse time/turns:\n" +
			"- Yes: The shortcut is an ability or item using reuse time/turns.\n" +
			"- No: The shortcut isn't an ability or item using reuse time/turns.\n" +
			"- Ignore: The type of shortcut is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { ShortcutRequirementType.Ability, ShortcutRequirementType.Item },
			needed=Needed.One, endCheckGroup=true)]
		public Consider hasReuse = Consider.Ignore;


		// equipment
		[ORKEditorHelp("Has Durability", "Select if the weapon/armor uses durability:\n" +
			"- Yes: The equipment is using durability.\n" +
			"- No: The equipment isn't using durability.\n" +
			"- Ignore: Durability is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		[ORKEditorLayout(new string[] { "type", "type" },
			new object[] { ShortcutRequirementType.Weapon, ShortcutRequirementType.Armor },
			needed=Needed.One, endCheckGroup=true)]
		public Consider hasEquipDurability = Consider.Ignore;


		// variable conditions
		[ORKEditorHelp("Use Shortcut Variables", "Use variables from items/abilities/equipment.\n" +
			"The check will fail if the shortcut doesn't have variables.\n" +
			"If disabled, uses global variables.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Conditions")]
		public bool useShortcutVariables = false;

		public VariableCondition variableCondition = new VariableCondition();

		public ShortcutRequirement()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Check(IShortcut shortcut)
		{
			if(this.CheckVariables(shortcut))
			{
				if(ShortcutRequirementType.Ability == this.type)
				{
					AbilityShortcut ability = shortcut as AbilityShortcut;
					if(ability != null)
					{
						// passive ability
						if(Consider.Yes == this.isPassiveAbility)
						{
							if(!ability.IsPassive)
							{
								return false;
							}
						}
						else if(Consider.No == this.isPassiveAbility)
						{
							if(ability.IsPassive)
							{
								return false;
							}
						}
						// use count
						if(Consider.Yes == this.hasAbilityUseCount)
						{
							if(!ability.HasUseCount)
							{
								return false;
							}
						}
						else if(Consider.No == this.hasAbilityUseCount)
						{
							if(ability.HasUseCount)
							{
								return false;
							}
						}
						// reuse time/turns
						if(Consider.Yes == this.hasReuse)
						{
							if(ability.IsReuseTime(EndAfter.None))
							{
								return false;
							}
						}
						else if(Consider.No == this.hasReuse)
						{
							if(!ability.IsReuseTime(EndAfter.None))
							{
								return false;
							}
						}
						return true;
					}
				}
				else if(ShortcutRequirementType.Item == this.type)
				{
					ItemShortcut item = shortcut as ItemShortcut;
					if(item != null)
					{
						// reuse time/turns
						if(Consider.Yes == this.hasReuse)
						{
							if(item.IsReuseTime(EndAfter.None))
							{
								return false;
							}
						}
						else if(Consider.No == this.hasReuse)
						{
							if(!item.IsReuseTime(EndAfter.None))
							{
								return false;
							}
						}
						return true;
					}
				}
				else if(ShortcutRequirementType.Weapon == this.type)
				{
					EquipShortcut equip = shortcut as EquipShortcut;
					if(equip != null &&
						equip.IsType(EquipSet.Weapon))
					{
						return this.CheckEquip(equip);
					}
				}
				else if(ShortcutRequirementType.Armor == this.type)
				{
					EquipShortcut equip = shortcut as EquipShortcut;
					if(equip != null &&
						equip.IsType(EquipSet.Armor))
					{
						return this.CheckEquip(equip);
					}
				}
				else if(ShortcutRequirementType.Currency == this.type)
				{
					MoneyShortcut currency = shortcut as MoneyShortcut;
					if(currency != null)
					{
						return true;
					}
				}
			}
			return false;
		}

		private bool CheckEquip(EquipShortcut equip)
		{
			if(Consider.Yes == this.hasEquipDurability)
			{
				if(equip.Durability == -1)
				{
					return false;
				}
			}
			else if(Consider.No == this.hasEquipDurability)
			{
				if(equip.Durability != -1)
				{
					return false;
				}
			}
			return true;
		}

		public bool CheckVariables(IShortcut shortcut)
		{
			if(this.variableCondition.Has)
			{
				if(this.useShortcutVariables)
				{
					IVariableSource variableSource = shortcut as IVariableSource;
					if(variableSource != null &&
						variableSource.HasVariables)
					{
						return this.variableCondition.CheckVariables(variableSource.Variables);
					}
				}
				else
				{
					return this.variableCondition.CheckVariables(ORK.Game.Variables);
				}
				return false;
			}
			return true;
		}
	}
}
