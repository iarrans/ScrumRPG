﻿
using UnityEngine;

namespace ORKFramework
{
	public class RandomFloat : BaseData
	{
		[ORKEditorHelp("Minimum Random", "The minimum random value (inclusive).", "")]
		public float min = 0;

		[ORKEditorHelp("Maximum Random", "The maximum random value (inclusive).", "")]
		[ORKEditorLimit("min", false)]
		public float max = 0;

		// rounding
		[ORKEditorHelp("Rounding", "Rounds the random value.\n" +
			"- None: No rounding.\n" +
			"- Ceil: The value will be rounded up (e.g. 14.2 will become 15).\n" +
			"- Floor: The value will be rounded down (e.g. 14.8 will become 14).\n" +
			"- Round: The value will be rounded to the nearest integer (e.g. 14.2 will become 14, 14.8 will become 15).", "")]
		[ORKEditorLayout("type", NumberValueType.Value, elseCheckGroup=true, endCheckGroup=true)]
		public Rounding rounding = Rounding.None;

		public RandomFloat()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("min"))
			{
				int tmp = 0;
				data.Get("min", ref tmp);
				this.min = tmp;
				tmp = 0;
				data.Get("max", ref tmp);
				this.max = tmp;
			}
		}

		public float GetValue()
		{
			return ValueHelper.GetRounded(UnityWrapper.Range(this.min, this.max), this.rounding);
		}
	}
}
