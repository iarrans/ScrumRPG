﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ObjectRequirement : BaseData
	{
		// difficulty condition
		[ORKEditorHelp("Use Difficulty Check", "Check the game's difficulty.", "")]
		[ORKEditorInfo("Difficulty Condition", "Optionally check the game's difficulty.", "")]
		public bool useDifficultyCheck = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useDifficultyCheck", true, endCheckGroup=true, autoInit=true)]
		public DifficultyCheck difficultyCheck;


		// variable conditions
		[ORKEditorHelp("Use Variable Conditions", "A variable condition is used.", "")]
		[ORKEditorInfo("Variable Conditions", "Variable conditions can be used.", "")]
		public bool useVariableCondition = false;

		[ORKEditorHelp("Use Object Variable", "Use object variables of the game object.\n" +
			"The game object must have an 'Object Variables' component attached, otherwise the check fails.", "")]
		[ORKEditorLayout("useVariableCondition", true)]
		public bool useObjectVariables = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public VariableCondition variableCondition = new VariableCondition();


		// quest conditions
		[ORKEditorHelp("Use Quest Conditions", "Quest type, quest or task status conditions are used.", "")]
		[ORKEditorInfo("Quest Conditions", "Quest type, quest and task status conditions can be used.", "")]
		public bool useQuestCondition = false;

		[ORKEditorInfo(endFoldout=true, separator=true)]
		[ORKEditorLayout("useQuestCondition", true, endCheckGroup=true, autoInit=true)]
		public QuestCondition questCondition;

		public ObjectRequirement()
		{

		}

		public VariableHandler GetVariableHandler(GameObject gameObject)
		{
			if(this.useObjectVariables)
			{
				return ObjectVariablesComponent.GetInChildren(gameObject);
			}
			else
			{
				return ORK.Game.Variables;
			}
			return null;
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		public void Register(GameObject gameObject, Notify notify)
		{
			if(this.useDifficultyCheck)
			{
				ORK.Game.DifficultyChanged += notify;
			}
			if(this.variableCondition.Has)
			{
				VariableHandler handler = this.GetVariableHandler(gameObject);
				if(handler != null)
				{
					handler.Changed += notify;
				}
			}
			if(this.useQuestCondition &&
				this.questCondition.Has)
			{
				ORK.Game.Quests.Changed += notify;
			}
		}

		public void Unregister(GameObject gameObject, Notify notify)
		{
			if(this.useDifficultyCheck)
			{
				ORK.Game.DifficultyChanged -= notify;
			}
			if(this.variableCondition.Has)
			{
				VariableHandler handler = this.GetVariableHandler(gameObject);
				if(handler != null)
				{
					handler.Changed -= notify;
				}
			}
			if(this.useQuestCondition &&
				this.questCondition.Has)
			{
				ORK.Game.Quests.Changed -= notify;
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Check(GameObject gameObject)
		{
			return this.CheckDifficulty() && this.CheckQuests() && this.CheckVariables(gameObject);
		}

		public bool CheckDifficulty()
		{
			return !this.useDifficultyCheck || this.difficultyCheck.Check();
		}

		public bool CheckVariables(GameObject gameObject)
		{
			if(this.useVariableCondition &&
				this.variableCondition.Has)
			{
				return this.variableCondition.CheckVariables(this.GetVariableHandler(gameObject));
			}
			return true;
		}

		public bool CheckQuests()
		{
			return !this.useQuestCondition || this.questCondition.Check();
		}
	}
}
