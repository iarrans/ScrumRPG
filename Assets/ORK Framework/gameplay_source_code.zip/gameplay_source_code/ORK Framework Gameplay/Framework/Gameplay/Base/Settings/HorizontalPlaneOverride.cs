﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public enum HorizontalPlaneType { XZ, XY };
	public enum HorizontalPlaneOverrideType { Default, XZ, XY };

	[System.Serializable]
	public class HorizontalPlaneOverride : BaseData
	{
		[ORKEditorHelp("Horizontal Plane", "Select the horizontal plane that will be used (i.e. which axes are used as the ground/horizontal level):\n" +
			"- Default: The default horizontal plane defined in 'Game > Game Settings'." +
			"- XZ: The X and Z axes define the ground, i.e. default 3D behaviour.\n" +
			"- XY: The X and Y axes define the ground, i.e. default 2D behaviour.", "")]
		public HorizontalPlaneOverrideType type = HorizontalPlaneOverrideType.Default;

		public HorizontalPlaneOverride()
		{

		}

		public static implicit operator HorizontalPlaneType(HorizontalPlaneOverride plane)
		{
			if(plane == null ||
				HorizontalPlaneOverrideType.Default == plane.type)
			{
				return ORK.GameSettings.horizontalPlane;
			}
			else if(HorizontalPlaneOverrideType.XZ == plane.type)
			{
				return HorizontalPlaneType.XZ;
			}
			else if(HorizontalPlaneOverrideType.XY == plane.type)
			{
				return HorizontalPlaneType.XY;
			}
			return ORK.GameSettings.horizontalPlane;
		}

		public bool IsXZ
		{
			get
			{
				return HorizontalPlaneOverrideType.XZ == this.type ||
					(HorizontalPlaneOverrideType.Default == this.type &&
						HorizontalPlaneType.XZ == ORK.GameSettings.horizontalPlane);
			}
		}

		public bool IsXY
		{
			get
			{
				return HorizontalPlaneOverrideType.XY == this.type ||
					(HorizontalPlaneOverrideType.Default == this.type &&
						HorizontalPlaneType.XY == ORK.GameSettings.horizontalPlane);
			}
		}
	}
}
