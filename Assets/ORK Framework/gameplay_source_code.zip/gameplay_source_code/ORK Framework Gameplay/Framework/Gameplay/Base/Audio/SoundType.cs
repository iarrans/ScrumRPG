
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Animations
{
	public class SoundType : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of this sound type.", "")]
		[ORKEditorInfo("Base Settings", "Set the name of this sound type.", "", 
			expandWidth=true, endFoldout=true)]
		public string name = "";

		public SoundType()
		{
			
		}
		
		public SoundType(string name)
		{
			this.name = name;
		}
	}
}
