﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Ability", "The combatant must or mustn't have a selected ability.", "")]
	public class AbilityRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Ability", "Select the ability that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		public int abilityID = 0;

		[ORKEditorHelp("Level", "The level of the ability that will be checked for.\n" +
			"The combatant must have at least the defined ability level.", "")]
		[ORKEditorLimit(1, false)]
		public int level = 1;

		[ORKEditorHelp("Ability Is", "Select if the ability is:\n" +
			"- Known: The combatant must know the ability (i.e. the ability is available).\n" +
			"- Learned: The combatant must have learned the ability.\n" +
			"- Group Ability: The ability must be a group ability of the combatant's group.\n" +
			"- Temporary: The ability is added as temporary ability.", "")]
		public AbilityCheckType abilityCheck = AbilityCheckType.Known;

		[ORKEditorHelp("Is Valid", "The 'Ability Is' check must be valid.\n" +
			"If disabled, the check must not be valid (i.e. " +
			"'Knows' = mustn't know at all, " +
			"'Learned' = mustn't be learned, " +
			"'Group Ability' = mustn't be a group ability).", "")]
		public bool isValid = true;

		public AbilityRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.abilityID);
				data.Get("abilityValid", ref this.isValid);

				if(data.Contains<bool>("knowsAbility"))
				{
					bool knows = false;
					data.Get("knowsAbility", ref knows);
					bool learned = false;
					data.Get("learned", ref learned);

					if(knows)
					{
						this.abilityCheck = learned ?
							AbilityCheckType.Learned : AbilityCheckType.Known;
						this.isValid = true;
					}
					else
					{
						this.abilityCheck = AbilityCheckType.Known;
						this.isValid = false;
					}
				}
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(AbilityCheckType.Known == this.abilityCheck)
			{
				return combatant.Abilities.Has(this.abilityID, this.level) == this.isValid;
			}
			else if(AbilityCheckType.Learned == this.abilityCheck)
			{
				return combatant.Abilities.HasLearned(this.abilityID, this.level) == this.isValid;
			}
			else if(AbilityCheckType.GroupAbility == this.abilityCheck)
			{
				return combatant.Group.Abilities.HasLearned(this.abilityID, this.level) == this.isValid;
			}
			else if(AbilityCheckType.Temporary == this.abilityCheck)
			{
				return combatant.Abilities.HasTemporary(this.abilityID, this.level) == this.isValid;
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Abilities.AbilitiesChanged += notify.AbilitiesChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Abilities.AbilitiesChanged -= notify.AbilitiesChanged;
		}
	}
}
