﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Attack Attribute", "The selected attack attribute will be compared to a defined value.", "")]
	public class AttackAttributeRequirementType : BaseStatusRequirementType
	{
		public AttackAttributeSelection selection = new AttackAttributeSelection();

		[ORKEditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the attribute.\n" +
			"- Base Value: The base value of the attribute (without bonuses).\n" +
			"- Min Value: The minimum value of the attribute.\n" +
			"- Max Value: The maximum value of the attribute.\n" +
			"- Start Value: The start value of the attribute (i.e. the attribute's initial value).\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.", "")]
		public AttributeGetValue getValue = AttributeGetValue.CurrentValue;

		public ValueCheck check = new ValueCheck();

		public AttackAttributeRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.selection.index);
				data.Get("selectionID2", ref this.selection.subIndex);
				data.GetEnum("attrGetValue", ref this.getValue);
			}
			this.check.UpgradeFloat(data, "comparison", "value");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.check.Check(
				combatant.Status.GetAttackAttribute(this.selection.index).
					GetTypeValue(this.selection.subIndex, this.getValue),
				combatant);
		}

		public override bool CheckPreview(Combatant combatant)
		{
			return this.check.Check(
				combatant.Status.GetAttackAttribute(this.selection.index).
					GetPreviewValue(this.selection.subIndex),
				combatant);
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null &&
				(combatant.Bestiary.IsComplete ||
				combatant.Bestiary.status.attackAttribute[this.selection.index].attribute[this.selection.subIndex]))
			{
				return this.check.Check(
					combatant.Status.GetAttackAttribute(this.selection.index).
						GetTypeValue(this.selection.subIndex, this.getValue),
					combatant);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Status.GetAttackAttribute(this.selection.index).Changed += notify.AttackAttributeChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Status.GetAttackAttribute(this.selection.index).Changed -= notify.AttackAttributeChanged;
		}
	}
}
