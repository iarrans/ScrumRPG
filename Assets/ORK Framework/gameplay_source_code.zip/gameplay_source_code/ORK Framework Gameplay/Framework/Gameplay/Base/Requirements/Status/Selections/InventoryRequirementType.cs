﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Inventory", "The combatant's (or group's) inventory will be checked for a defined item, weapon, armor or currency.", "")]
	public class InventoryRequirementType : BaseStatusRequirementType
	{
		public ItemGain itemCheck = new ItemGain();

		[ORKEditorHelp("In Inventory", "If enabled, the defined item, weapon, armor or currency " +
			"must be in the combatant's inventory.\n" +
			"If disabled, it mustn't be in the inventory.", "")]
		public bool inInventory = true;

		public InventoryRequirementType()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.inInventory == this.itemCheck.Has(combatant.Inventory);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.InventoryChanged += notify.CombatantInventoryChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.InventoryChanged -= notify.CombatantInventoryChanged;
		}
	}
}
