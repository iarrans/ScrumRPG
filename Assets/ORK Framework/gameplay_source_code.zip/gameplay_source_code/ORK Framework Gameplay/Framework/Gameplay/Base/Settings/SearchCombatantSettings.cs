﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class SearchCombatantSettings : BaseData
	{
		// search settings
		[ORKEditorHelp("Add Player Group", "Include members of the player group.", "")]
		[ORKEditorInfo(labelText="Search Settings")]
		public bool addPlayerGroup = true;

		[ORKEditorHelp("Is Enemy", "Select if the combatants are enemies of the user:\n" +
			"- Yes: The combatants are enemies.\n" +
			"- No: The combatants are allies.\n" +
			"- Ignore: Ignores the faction standings.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider isEnemy = Consider.Ignore;

		[ORKEditorHelp("Is Dead", "Select if the combatants are dead:\n" +
			"- Yes: The combatants are dead.\n" +
			"- No: The combatants are alive.\n" +
			"- Ignore: Ignores the death state.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider isDead = Consider.Ignore;

		[ORKEditorHelp("In Battle", "Select if the combatants are in battle:\n" +
			"- Yes: The combatants are in battle.\n" +
			"- No: The combatants are not in battle.\n" +
			"- Ignore: Ignores the battle state.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider inBattle = Consider.Ignore;


		// requirements
		[ORKEditorHelp("Needed", "Either ALL or only ONE requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed statusNeeded = Needed.All;

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirement[] statusRequirement = new StatusRequirement[0];

		public SearchCombatantSettings()
		{

		}


		/*
		============================================================================
		Search functions
		============================================================================
		*/
		public List<Combatant> Search(Combatant user, Range range)
		{
			return ORK.Game.Combatants.Get(user, this.addPlayerGroup, range,
				this.isEnemy, this.isDead, this.inBattle, this.CheckRequirement);
		}

		public List<Combatant> Search(Vector3 position, Combatant user, Range range)
		{
			return ORK.Game.Combatants.Get(position, user, this.addPlayerGroup, range,
				this.isEnemy, this.isDead, this.inBattle, this.CheckRequirement);
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CheckRequirement(Combatant user, Combatant target)
		{
			return StatusRequirement.Check(target, this.statusRequirement, this.statusNeeded);
		}
	}
}
