﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Status Effect Type", "A status effect of the selected status effect type must or mustn't be applied.", "")]
	public class StatusEffectTypeRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Status Effect Type", "Select the status effect type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.StatusEffectType)]
		public int effectTypeID = 0;

		[ORKEditorHelp("Is Applied", "A status effect of the selected status effect type must be applied.\n" +
			"If disabled, an effect mustn't be applied.", "")]
		public bool isApplied = false;

		[ORKEditorHelp("Check Count", "Check the number of applied status effects of the selected type.", "")]
		[ORKEditorLayout("isApplied", true)]
		public bool checkCount = false;

		[ORKEditorLayout("checkCount", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public ValueCheck check;

		public StatusEffectTypeRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.effectTypeID);
				data.Get("appliedEffectType", ref this.isApplied);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.isApplied &&
				this.checkCount)
			{
				return this.check.Check(combatant.Status.Effects.GetTypeAppliedCount(this.effectTypeID), combatant);
			}
			else
			{
				return this.isApplied == combatant.Status.Effects.IsTypeApplied(this.effectTypeID);
			}
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Status.Effects.Added += notify.StatusEffectChanged;
			combatant.Status.Effects.Removed += notify.StatusEffectChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Status.Effects.Added -= notify.StatusEffectChanged;
			combatant.Status.Effects.Removed -= notify.StatusEffectChanged;
		}
	}
}
