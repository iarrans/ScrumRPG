﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class EquipmentConditionalPrefab : BaseData
	{
		public EquipmentPrefab prefab = new EquipmentPrefab();


		// variable conditions
		[ORKEditorHelp("Use Equipment Variable", "Use variables of the equipment instead of global variables.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Conditions")]
		public bool useItemVariable = false;

		public VariableCondition condition = new VariableCondition();

		public EquipmentConditionalPrefab()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Check(IVariableSource variableSource)
		{
			return this.CheckVariables(variableSource);
		}

		public bool CheckVariables(IVariableSource variableSource)
		{
			if(this.condition.Has)
			{
				if(this.useItemVariable)
				{
					if(variableSource != null &&
						variableSource.HasVariables)
					{
						return this.condition.CheckVariables(variableSource.Variables);
					}
				}
				else
				{
					return this.condition.CheckVariables(ORK.Game.Variables);
				}
				return false;
			}
			return true;
		}
	}
}
