﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class LocalSpace : BaseData
	{
		[ORKEditorHelp("Local Space", "Use the local space of the game object.", "")]
		public bool localSpace = true;

		[ORKEditorHelp("Ignore Scale", "Ignore the scale when using local space.", "")]
		[ORKEditorInfo(indent=true)]
		[ORKEditorLayout("localSpace", true, endCheckGroup=true)]
		public bool ignoreScale = false;

		public LocalSpace()
		{

		}

		public LocalSpace(bool localSpace)
		{
			this.localSpace = localSpace;
		}

		public void Upgrade(DataObject data)
		{
			if(data.Contains<bool>("localSpace"))
			{
				data.Get("localSpace", ref this.localSpace);
			}
		}

		public void Upgrade(DataObject data, string name)
		{
			if(data.Contains<bool>(name))
			{
				data.Get(name, ref this.localSpace);
			}
		}

		public Vector3 GetOffsetPosition(Transform transform, Vector3 offset)
		{
			if(this.localSpace)
			{
				if(this.ignoreScale)
				{
					return transform.TransformPointUnscaled(offset);
				}
				else
				{
					return transform.TransformPoint(offset);
				}
			}
			else
			{
				return transform.position + offset;
			}
		}

		public Vector3 GetPosition(Transform transform, Vector3 position)
		{
			if(this.localSpace)
			{
				if(this.ignoreScale)
				{
					return transform.TransformPointUnscaled(position);
				}
				else
				{
					return transform.TransformPoint(position);
				}
			}
			else
			{
				return position;
			}
		}
	}
}
