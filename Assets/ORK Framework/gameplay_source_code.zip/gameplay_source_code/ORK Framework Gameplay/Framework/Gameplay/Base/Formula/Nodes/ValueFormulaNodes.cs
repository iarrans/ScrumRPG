
using UnityEngine;
using ORKFramework.Reflection;
using System.Collections.Generic;
using System.Reflection;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Value", "A single value is used.", "")]
	[ORKNodeInfo("Value")]
	public class ValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true, labelText="Value")]
		public FormulaFloat value = new FormulaFloat();

		public ValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			ValueHelper.UseOperator(ref call.result, this.value.GetValue(call), this.formulaOperator);
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " " + this.value.GetInfoText();
		}
	}

	[ORKEditorHelp("Random Value", "A random value between two values is used.", "")]
	[ORKNodeInfo("Value")]
	public class RandomValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorHelp("As Int", "The random value will be used as an integer (i.e. whole number).\n" +
			"When generating a random integer, 'Value 2' will be used exclusive." +
			"If disabled, the random value will be a float.", "")]
		public bool asInt = false;

		[ORKEditorInfo(separator=true, labelText="Value 1")]
		public FormulaFloat min = new FormulaFloat();

		[ORKEditorInfo(separator=true, labelText="Value 2")]
		public FormulaFloat max = new FormulaFloat();

		public RandomValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			float v1 = this.min.GetValue(call);
			float v2 = this.max.GetValue(call);
			if(v1 < v2)
			{
				ValueHelper.UseOperator(ref call.result,
					this.asInt ? UnityWrapper.Range((int)v1, (int)v2) : UnityWrapper.Range(v1, v2),
					this.formulaOperator);
			}
			else if(v1 > v2)
			{
				ValueHelper.UseOperator(ref call.result,
					this.asInt ? UnityWrapper.Range((int)v1, (int)v2) : UnityWrapper.Range(v2, v1),
					this.formulaOperator);
			}
			else
			{
				ValueHelper.UseOperator(ref call.result, this.asInt ? (int)v1 : v1, this.formulaOperator);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " " + this.min.GetInfoText() + " ~ " + this.max.GetInfoText();
		}
	}

	[ORKEditorHelp("Minimum Value", "The smaller value of two values is used.", "")]
	[ORKNodeInfo("Value")]
	public class MinimumValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true, labelText="Value 1")]
		public FormulaFloat min = new FormulaFloat();

		[ORKEditorInfo(separator=true, labelText="Value 2")]
		public FormulaFloat max = new FormulaFloat();

		public MinimumValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			ValueHelper.UseOperator(ref call.result,
				Mathf.Min(this.min.GetValue(call), this.max.GetValue(call)),
				this.formulaOperator);
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " min(" + this.min.GetInfoText() + ", " + this.max.GetInfoText() + ")";
		}
	}

	[ORKEditorHelp("Maximum Value", "The bigger value of two values is used.", "")]
	[ORKNodeInfo("Value")]
	public class MaximumValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		[ORKEditorInfo(separator=true, labelText="Value 1")]
		public FormulaFloat min = new FormulaFloat();

		[ORKEditorInfo(separator=true, labelText="Value 2")]
		public FormulaFloat max = new FormulaFloat();

		public MaximumValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			ValueHelper.UseOperator(ref call.result,
				Mathf.Max(this.min.GetValue(call), this.max.GetValue(call)),
				this.formulaOperator);
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " max(" + this.min.GetInfoText() + ", " + this.max.GetInfoText() + ")";
		}
	}

	[ORKEditorHelp("Check Formula Value", "The current value of the formula will be checked with a defined value.\n" +
		"If the check is true, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Value", "Check")]
	public class CheckFormulaValueStep : BaseFormulaCheckStep
	{
		public FormulaValueCheck check = new FormulaValueCheck();

		public CheckFormulaValueStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeFormulaFloat(data, "check", "value", "value2");
		}

		public override int Calculate(FormulaCall call)
		{
			if(this.check.Check(call.result, call))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.GetInfoText();
		}
	}

	[ORKEditorHelp("Function Value", "The return value of a called function is used.\n" +
		"Requires a function that takes a 'FormulaCall' as parameter, which gives you access to " + 
		"the user/target of the formula, current value and local variables/selected data, e.g.:\n" +
		"public float YourFunction(FormulaCall call)", "")]
	[ORKNodeInfo("Value")]
	public class FunctionValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;

		// field settings
		[ORKEditorHelp("Class Origin", "Select where the defined function comes from:\n" +
			"- Component: A component on a defined combatant's game object.\n" +
			"- Static: A static function of the class.\n" +
			"- Selected Data: A class instance stored in selected data.", "")]
		[ORKEditorInfo(separator=true, labelText="Field Settings")]
		public ReflectionClassOrigin classOrigin = ReflectionClassOrigin.Static;

		// component
		[ORKEditorLayout("classOrigin", ReflectionClassOrigin.Component, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin origin;

		// selected data
		[ORKEditorLayout("classOrigin", ReflectionClassOrigin.SelectedData, endCheckGroup=true, autoInit=true)]
		public FormulaSelectedData selectedData;

		// class
		[ORKEditorHelp("Class Name", "The name of the class that contains the static function.", "")]
		[ORKEditorInfo(separator=true, expandWidth=true)]
		public string className = "";

		[ORKEditorHelp("Function Name", "The name of the static function that will be called.\n" +
			"Requires a function that takes a 'FormulaCall' as parameter, which gives you access to " +
			"the user/target of the formula, current value and local variables/selected data, e.g.:\n" +
			"public float YourFunction(FormulaCall call)\n" +
			"Or for static functions:\n" +
			"public static float YourFunction(FormulaCall call)", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string functionName = "";

		public FunctionValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.className != "" && this.functionName != "")
			{
				if(ReflectionClassOrigin.Component == this.classOrigin)
				{
					Combatant combatant = this.origin.GetCombatant(call);
					if(combatant != null && combatant.GameObject != null)
					{
						Component comp = ComponentHelper.Get(combatant.GameObject, this.className);
						if(comp != null)
						{
							object tmp = this.GetValue(comp, call);
							if(tmp is float)
							{
								ValueHelper.UseOperator(ref call.result, (float)tmp, this.formulaOperator);
							}
							else if(tmp is int)
							{
								ValueHelper.UseOperator(ref call.result, (int)tmp, this.formulaOperator);
							}
						}
					}
				}
				else if(ReflectionClassOrigin.Static == this.classOrigin)
				{
					object tmp = this.GetValue(null, call);
					if(tmp is float)
					{
						ValueHelper.UseOperator(ref call.result, (float)tmp, this.formulaOperator);
					}
					else if(tmp is int)
					{
						ValueHelper.UseOperator(ref call.result, (int)tmp, this.formulaOperator);
					}
				}
				else if(ReflectionClassOrigin.SelectedData == this.classOrigin)
				{
					List<object> list = SelectedDataHelper.GetClass(this.selectedData.GetSelectedData(call), this.className);

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							object tmp = this.GetValue(list[i], call);
							if(tmp is float)
							{
								ValueHelper.UseOperator(ref call.result, (float)tmp, this.formulaOperator);
							}
							else if(tmp is int)
							{
								ValueHelper.UseOperator(ref call.result, (int)tmp, this.formulaOperator);
							}
						}
					}
				}
			}

			return this.next;
		}

		protected virtual object GetValue(object instance, FormulaCall call)
		{
			if(instance != null || ReflectionClassOrigin.Static == this.classOrigin)
			{
				System.Type classType = ORK.Core.TypeHandler.GetType(this.className);
				if(classType != null)
				{
					System.Type[] types = new System.Type[] { typeof(FormulaCall) };
					object[] values = new object[] { call };

					MethodInfo methodInfo = classType.GetMethod(this.functionName, types);
					if(methodInfo != null)
					{
						try
						{
							return methodInfo.Invoke(ReflectionClassOrigin.Static == this.classOrigin ? null : instance, values);
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Method call failed (" + classType + "): " +
								this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Method not found (" + classType + "): " + this.functionName);
					}
				}
				else
				{
					Debug.LogWarning("Class not found: " + this.className);
				}
			}
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " " + this.className + "." + this.functionName;
		}
	}

	[ORKEditorHelp("Field Value", "The value of an int or float field/property is used.", "")]
	[ORKNodeInfo("Value")]
	public class FieldValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;


		// field settings
		[ORKEditorHelp("Class Origin", "Select where the defined class/field/property comes from:\n" +
			"- Component: A component on a defined combatant's game object.\n" +
			"- Static: A static field/property of the class.\n" +
			"- Selected Data: A class instance stored in selected data.", "")]
		[ORKEditorInfo(separator=true, labelText="Field Settings")]
		public ReflectionClassOrigin classOrigin = ReflectionClassOrigin.Static;

		// component
		[ORKEditorLayout("classOrigin", ReflectionClassOrigin.Component, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin origin;

		// selected data
		[ORKEditorLayout("classOrigin", ReflectionClassOrigin.SelectedData, endCheckGroup=true, autoInit=true)]
		public FormulaSelectedData selectedData;

		// class
		[ORKEditorHelp("Class Name", "The name of the class that contains the field/property.", "")]
		[ORKEditorInfo(expandWidth=true, separator=true)]
		public string className = "";

		public FormulaGetFieldValue field = new FormulaGetFieldValue();

		public FieldValueStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.className != "" && this.field.fieldName != "")
			{
				if(ReflectionClassOrigin.Component == this.classOrigin)
				{
					Combatant combatant = this.origin.GetCombatant(call);
					if(combatant != null && combatant.GameObject != null)
					{
						Component comp = ComponentHelper.Get(combatant.GameObject, this.className);
						if(comp != null)
						{
							object tmp = this.field.GetValue(comp, this.className, false, call);
							if(tmp is float)
							{
								ValueHelper.UseOperator(ref call.result, (float)tmp, this.formulaOperator);
							}
							else if(tmp is int)
							{
								ValueHelper.UseOperator(ref call.result, (int)tmp, this.formulaOperator);
							}
						}
					}
				}
				else if(ReflectionClassOrigin.Static == this.classOrigin)
				{
					object tmp = this.field.GetValue(null, this.className, true, call);
					if(tmp is float)
					{
						ValueHelper.UseOperator(ref call.result, (float)tmp, this.formulaOperator);
					}
					else if(tmp is int)
					{
						ValueHelper.UseOperator(ref call.result, (int)tmp, this.formulaOperator);
					}
				}
				else if(ReflectionClassOrigin.SelectedData == this.classOrigin)
				{
					List<object> list = SelectedDataHelper.GetClass(this.selectedData.GetSelectedData(call), this.className);

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							object tmp = this.field.GetValue(list[i], this.className, false, call);
							if(tmp is float)
							{
								ValueHelper.UseOperator(ref call.result, (float)tmp, this.formulaOperator);
							}
							else if(tmp is int)
							{
								ValueHelper.UseOperator(ref call.result, (int)tmp, this.formulaOperator);
							}
						}
					}
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " " + this.className + "." + this.field.fieldName;
		}
	}
}
