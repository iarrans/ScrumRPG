
using UnityEngine;

namespace ORKFramework
{
	public class FloatFader
	{
		protected bool fading = false;

		protected Function ease;

		protected float start = 0;

		protected float distance = 0;

		protected float time = 0;

		protected float time2 = 0;

		public FloatFader(EaseType interpolation, float time)
		{
			this.ease = Interpolate.Ease(interpolation);
			this.time2 = time;
		}

		public virtual bool Fading
		{
			get { return this.fading; }
			set { this.fading = value; }
		}

		public virtual void Start(float start, float end)
		{
			this.start = start;
			this.distance = end - start;
			this.time = 0;
			this.fading = true;
		}

		public virtual void Fade(ref float value, float t)
		{
			this.time += t;
			value = Interpolate.Ease(this.ease, this.start, this.distance, this.time, this.time2);

			if(this.time >= this.time2)
			{
				this.fading = false;
			}
		}
	}
}
