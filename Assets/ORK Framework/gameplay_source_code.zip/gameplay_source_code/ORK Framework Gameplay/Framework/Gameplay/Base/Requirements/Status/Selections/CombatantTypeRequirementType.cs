﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Combatant Type", "The combatant must or mustn't be of the selected combatant type.", "")]
	public class CombatantTypeRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Combatant Type", "Select the combatant type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.CombatantType)]
		public int combatantTypeID = 0;

		[ORKEditorHelp("Use Sub-Types", "The sub-types of the defined combatant type will also be checked.", "")]
		[ORKEditorInfo(indent=true)]
		public bool useSubTypes = false;

		[ORKEditorHelp("Is Combatant Type", "The combatant must be the selected combatant type.\n" +
			"If disabled, the combatant mustn't be the selected combatant type.", "")]
		public bool isCombatantType = true;

		public CombatantTypeRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.combatantTypeID);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.isCombatantType == ((combatant.TypeID == this.combatantTypeID) || 
				(this.useSubTypes && 
					ORK.CombatantTypes.Get(combatant.TypeID).IsSubTypeOf(this.combatantTypeID)));
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{

		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{

		}
	}
}
