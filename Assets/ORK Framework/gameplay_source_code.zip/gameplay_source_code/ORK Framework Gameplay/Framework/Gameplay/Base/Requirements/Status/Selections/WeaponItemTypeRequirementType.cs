﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Weapon Item Type", "A weapon of the selected item type must or mustn't be equipped.", "")]
	public class WeaponItemTypeRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Item Type", "Select the item type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.ItemType)]
		public int itemTypeID = 0;

		[ORKEditorHelp("Use Sub-Types", "The sub-types of the defined item type will also be checked.", "")]
		[ORKEditorInfo(indent=true)]
		public bool useSubTypes = false;

		[ORKEditorHelp("Is Equipped", "A weapon of the defined item type must be equipped on the combatant.\n" +
			"If disabled, a weapon of the defined item type mustn't be equipped.", "")]
		public bool isEquipped = true;

		[ORKEditorHelp("Check Equipment Part", "Check if a weapon of the defined item type is equipped on a defined equipment part.\n" +
			"If disabled, checks if a weapon of the defined item type is equipped on any part.", "")]
		public bool checkEquipmentPart = false;

		[ORKEditorHelp("Equipment Part", "Select the equipment part you want to check.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("checkEquipmentPart", true, endCheckGroup=true)]
		public int equipmentPartID = 0;

		public WeaponItemTypeRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.itemTypeID);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.Equipment.IsTypeEquipped(EquipSet.Weapon, this.useSubTypes, this.itemTypeID,
				this.checkEquipmentPart ? this.equipmentPartID : -1) == this.isEquipped;
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null &&
				(combatant.Bestiary.IsComplete ||
				combatant.Bestiary.status.equipment))
			{
				return this.Check(combatant);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Equipment.Changed += notify.EquipmentChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Equipment.Changed -= notify.EquipmentChanged;
		}
	}
}
