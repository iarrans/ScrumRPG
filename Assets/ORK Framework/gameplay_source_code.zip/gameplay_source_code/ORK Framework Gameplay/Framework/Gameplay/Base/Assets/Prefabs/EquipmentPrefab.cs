﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class EquipmentPrefab : BaseData
	{
		// prefab
		public ItemPrefab itemPrefab = new ItemPrefab();

		[ORKEditorHelp("Prefab View Prefab ", "The prefab used to display this equipment in prefab view portraits.\n" +
			"Select none to use the 'Equipment Prefab' in prefab view portraits.", "")]
		public AssetSource<GameObject> prefabViewPrefab = new AssetSource<GameObject>();


		// equipment viewer prefab
		[ORKEditorHelp("Viewer Prefab ", "The prefab used by 'Equipment Viewers'.\n" +
			"'Equipment Viewers' can display currently equipped equipment on the scene object of a combatant.\n" +
			"Select none to not display this equipment in 'Equipment Viewers'.", "")]
		[ORKEditorInfo(separator=true, labelText="Equipment Viewer Prefab")]
		public AssetSource<GameObject> viewerPrefab = new AssetSource<GameObject>();

		[ORKEditorHelp("Viewer Prefab View Prefab", "The prefab used by 'Equipment Viewers' when displayed in prefab view portraits.\n" +
			"Select none to use the 'Viewer Prefab' in prefab view portraits.", "")]
		public AssetSource<GameObject> prefabViewViewerPrefab = new AssetSource<GameObject>();

		[ORKEditorHelp("Viewer Name", "Define the name used for the spawned viewer prefab.\n" +
			"Leave empty to not name the prefab (i.e. the default name for spawned objects " +
			"will be used, e.g. 'Prefab(Clone)').", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("viewerPrefab", null, elseCheckGroup=true, setDefault=true, defaultValue="")]
		public string viewerName = "";

		[ORKEditorHelp("Position Offset", "Offset (in local space) added to the position of the equipment viewer.\n" +
			"The offset is also added to the default prefab, if no viewer prefab is used.", "")]
		public Vector3 viewerPosOff = Vector3.zero;

		[ORKEditorHelp("Rotation Offset", "Offset added to the rotation of the equipment viewer.\n" +
			"The offset is also added to the default prefab, if no viewer prefab is used.", "")]
		public Vector3 viewerRotOff = Vector3.zero;

		[ORKEditorHelp("Local Rotation", "Use the rotation offset as local rotation of the prefab.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool viewerLocalRotation = false;


		// viewer material
		[ORKEditorHelp("Viewer Material", "'Equipment Viewers' can change the material used " +
			"by a renderer attached to the same game object or a child object specified in the equipment viewer.\n" +
			"Select none to not change the renderer's material.", "")]
		[ORKEditorInfo(separator=true, labelText="Equipment Viewer Material")]
		public AssetSource<Material> viewerMaterial = new AssetSource<Material>();

		[ORKEditorHelp("Prefab View Material", "The material used by 'Equipment Viewers' when displayed in prefab view portraits.\n" +
			"Select none to use the 'Viewer Material' in prefab view portraits.", "")]
		public AssetSource<Material> prefabViewMaterial = new AssetSource<Material>();

		public EquipmentPrefab()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.itemPrefab.Upgrade(data, "prefab", "spawnOffset");
			this.prefabViewPrefab.Upgrade(data, "prefabViewPrefab");
			this.viewerPrefab.Upgrade(data, "viewerPrefab");
			this.prefabViewViewerPrefab.Upgrade(data, "prefabViewViewerPrefab");
			this.viewerMaterial.Upgrade(data, "viewerMaterial");
			this.prefabViewMaterial.Upgrade(data, "prefabViewMaterial");
		}

		public GameObject CreateViewerPrefab(Transform parent, bool isPrefabView)
		{
			GameObject prefab = null;
			if(isPrefabView)
			{
				prefab = this.prefabViewViewerPrefab;
			}
			if(prefab == null)
			{
				prefab = this.viewerPrefab;
			}
			if(prefab != null)
			{
				GameObject instance = UnityWrapper.Instantiate(prefab);

				if(parent != null)
				{
					if(this.viewerLocalRotation)
					{
						instance.transform.position = parent.TransformPoint(this.viewerPosOff);
						instance.transform.SetParent(parent);
						instance.transform.localEulerAngles = this.viewerRotOff;
					}
					else
					{
						instance.transform.SetPositionAndRotation(
							parent.TransformPoint(this.viewerPosOff),
							Quaternion.Euler(parent.eulerAngles + this.viewerRotOff));
						instance.transform.SetParent(parent);
					}
				}

				if(this.viewerName != "")
				{
					instance.name = this.viewerName;
				}
				return instance;
			}
			return null;
		}

		public Material GetViewerMaterial(bool isPrefabView)
		{
			Material material = null;
			if(isPrefabView &&
				material == null)
			{
				material = this.prefabViewMaterial;
			}
			if(material == null)
			{
				material = this.viewerMaterial;
			}
			return material;
		}
	}
}
