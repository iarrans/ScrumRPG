﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Is Choosing", "The combatant must or mustn't be choosing an action (e.g. displaying the battle menu).", "")]
	public class IsChoosingRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Is Choosing", "The combatant must be choosing an action (e.g. when the battle menu is displayed).\n" +
			"If disabled, the combatant mustn't be choosing an action.", "")]
		public bool isChoosing = true;

		public IsChoosingRequirementType()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.Actions.IsChoosing == this.isChoosing;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Actions.ChoosingStateChanged += notify.CombatantChoosingStateChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Actions.ChoosingStateChanged -= notify.CombatantChoosingStateChanged;
		}
	}
}
