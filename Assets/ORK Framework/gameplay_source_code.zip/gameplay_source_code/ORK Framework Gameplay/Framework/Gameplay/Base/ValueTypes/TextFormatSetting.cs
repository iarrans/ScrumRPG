﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TextFormatSetting : BaseData
	{
		[ORKEditorHelp("Text Color", "The color used for the text.", "")]
		[ORKEditorInfo(ORKDataType.Color)]
		public int colorID = 0;


		// shadow
		[ORKEditorHelp("Show Shadow", "A shadow is displayed for the text.", "")]
		[ORKEditorInfo(separator=true, labelText="Shadow Settings")]
		public bool showShadow = false;

		[ORKEditorHelp("Shadow Color", "The color used for the text shadow.", "")]
		[ORKEditorInfo(ORKDataType.Color)]
		[ORKEditorLayout("showShadow", true)]
		public int shadowColorID = 1;

		[ORKEditorHelp("Shadow Offset", "The offset of the shadow to the text.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public Vector2 shadowOffset = new Vector2(1, 1);


		// outline
		[ORKEditorHelp("Show Outline", "An outline is displayed around the text.", "")]
		[ORKEditorInfo(separator=true, labelText="Outline Settings")]
		[ORKEditorLayout("gui:newui")]
		public bool showOutline = false;

		[ORKEditorHelp("Outline Color", "The color used for the text outline.", "")]
		[ORKEditorInfo(ORKDataType.Color)]
		[ORKEditorLayout("showOutline", true)]
		public int outlineColorID = 1;

		[ORKEditorHelp("Outline Offset", "The offset of the outline to the text.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public Vector2 outlineOffset = new Vector2(1, 1);


		// font
		[ORKEditorHelp("Font", "Select the font that will be used.\n" +
			"The default font will be used if none is selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Font Settings")]
		public AssetSource<Font> font = new AssetSource<Font>();

		[ORKEditorHelp("Font Size", "The font size that will be used.", "")]
		[ORKEditorLimit(0, false)]
		public int fontSize = 20;

		[ORKEditorHelp("Font Style", "Select the font style that will be used.", "")]
		public FontStyle fontStyle = FontStyle.Normal;

		public TextFormatSetting()
		{

		}

		public TextFormatSetting(int colorID, int shadowColorID)
		{
			this.colorID = colorID;
			this.outlineColorID = shadowColorID;
			this.showShadow = this.shadowColorID >= 0;
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.font.Upgrade(data, "font");
		}

		public void SetTextStyle(GUIStyle textStyle)
		{
			Font font = this.font;
			if(font != null)
			{
				textStyle.font = font;
			}
			textStyle.fontSize = this.fontSize;
			textStyle.fontStyle = this.fontStyle;
		}


		/*
		============================================================================
		Color functions
		============================================================================
		*/
		public Color GetTextColor()
		{
			return ORK.Colors.Get(this.colorID).color;
		}

		public Color GetShadowColor()
		{
			return ORK.Colors.Get(this.shadowColorID).color;
		}

		public Color GetOutlineColor()
		{
			return ORK.Colors.Get(this.outlineColorID).color;
		}


		/*
		============================================================================
		Static text colors
		============================================================================
		*/
		public static TextFormatSetting Default
		{
			get { return new TextFormatSetting(0, 1); }
		}
	}
}
