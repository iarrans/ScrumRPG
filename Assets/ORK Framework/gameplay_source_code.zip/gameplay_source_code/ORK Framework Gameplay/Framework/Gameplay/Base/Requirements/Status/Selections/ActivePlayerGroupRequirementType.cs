﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Active Player Group", "The combatant must or mustn't be in the active player group (i.e. player controlled).", "")]
	public class ActivePlayerGroupRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("In Active Player Group", "The combatant must be in the active player group.\n" +
			"If disabled, the combatant mustn't be in the active player group.", "")]
		public bool inActivePlayerGroup = true;

		public ActivePlayerGroupRequirementType()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.IsPlayerControlled() == this.inActivePlayerGroup;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.GroupChanged += notify.CombatantGroupChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.GroupChanged -= notify.CombatantGroupChanged;
		}
	}
}
