﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class NegateInputKey : BaseData
	{
		[ORKEditorHelp("Input Key", "Select the input key that will be used as input for this input key.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int inputKeyID = 0;

		[ORKEditorHelp("Negate Input", "Negate the input key's input when checking if the input has occured.\n" +
			"E.g. when using an input key that has valid input when 'Shift' is held, " +
			"this can be used to allow this input to only be used when 'Shift' isn't held.", "")]
		public bool negate = false;

		public NegateInputKey()
		{

		}

		public bool CheckInput()
		{
			return this.negate ?
				!ORK.InputKeys.Get(this.inputKeyID).GetButton() :
				ORK.InputKeys.Get(this.inputKeyID).GetButton();
		}

		public float GetAxis()
		{
			return ORK.InputKeys.Get(this.inputKeyID).GetAxis();
		}
	}
}
