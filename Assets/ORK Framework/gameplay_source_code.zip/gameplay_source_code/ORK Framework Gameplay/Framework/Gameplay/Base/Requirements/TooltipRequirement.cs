﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TooltipRequirement : BaseData
	{
		[ORKEditorHelp("Has Equip Durability", "Select if the tooltip has to be an equipment that uses durability:\n" +
			"- Yes: The tooltip is an equipment using durability.\n" +
			"- No: The tooltip isn't an equipment using durability.\n" +
			"- Ignore: The type of tooltip is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider hasEquipDurability = Consider.Ignore;

		[ORKEditorHelp("Is Passive Ability", "Select if the tooltip has to be a passive ability:\n" +
			"- Yes: The tooltip is a passive ability.\n" +
			"- No: The tooltip isn't a passive ability.\n" +
			"- Ignore: The type of tooltip is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider isPassiveAbility = Consider.Ignore;

		[ORKEditorHelp("Has Ability Use Count", "Select if the tooltip has to be an ability that uses use count:\n" +
			"- Yes: The tooltip is an ability using use count.\n" +
			"- No: The tooltip isn't an ability using use count.\n" +
			"- Ignore: The type of tooltip is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider hasAbilityUseCount = Consider.Ignore;

		[ORKEditorHelp("Has Reuse Time/Turns", "Select if the tooltip has to be an ability or item using reuse time/turns:\n" +
			"- Yes: The tooltip is an ability or item using reuse time/turns.\n" +
			"- No: The tooltip isn't an ability or item using reuse time/turns.\n" +
			"- Ignore: The type of tooltip is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider hasReuse = Consider.Ignore;


		// variable conditions
		[ORKEditorHelp("Use Tooltip Variables", "Use variables of the displayed tooltip.\n" +
			"E.g. when displaying a combatant, this'll use object variables of the combatant.\n" +
			"E.g. when displaying an item, this'll use item variables of the item.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Conditions")]
		public bool useTooltipVariables = false;

		public VariableCondition condition = new VariableCondition();

		public TooltipRequirement()
		{

		}

		public bool Check(IContentSimple tooltip)
		{
			if(tooltip is PreviewSelection)
			{
				tooltip = ((PreviewSelection)tooltip).Content;
			}

			// equip durability
			if(Consider.Yes == this.hasEquipDurability)
			{
				EquipShortcut equip = tooltip as EquipShortcut;
				if(equip == null ||
					equip.Durability == -1)
				{
					return false;
				}
			}
			else if(Consider.No == this.hasEquipDurability)
			{
				EquipShortcut equip = tooltip as EquipShortcut;
				if(equip != null &&
					equip.Durability != -1)
				{
					return false;
				}
			}

			// passive ability
			if(Consider.Yes == this.isPassiveAbility)
			{
				AbilityShortcut ability = AbilityShortcut.GetAbilityShortcut(tooltip);
				if(ability == null ||
					!ability.IsPassive)
				{
					return false;
				}
			}
			else if(Consider.No == this.isPassiveAbility)
			{
				AbilityShortcut ability = AbilityShortcut.GetAbilityShortcut(tooltip);
				if(ability != null &&
					ability.IsPassive)
				{
					return false;
				}
			}

			// ability use count
			if(Consider.Yes == this.hasAbilityUseCount)
			{
				AbilityShortcut ability = AbilityShortcut.GetAbilityShortcut(tooltip);
				if(ability == null ||
					!ability.HasUseCount)
				{
					return false;
				}
			}
			else if(Consider.No == this.hasAbilityUseCount)
			{
				AbilityShortcut ability = AbilityShortcut.GetAbilityShortcut(tooltip);
				if(ability != null &&
					ability.HasUseCount)
				{
					return false;
				}
			}

			// reuse time/turns
			if(Consider.Yes == this.hasReuse)
			{
				IReuseTime reuse = tooltip as IReuseTime;
				if(reuse == null ||
					reuse.IsReuseTime(EndAfter.None))
				{
					return false;
				}
			}
			else if(Consider.No == this.hasReuse)
			{
				IReuseTime reuse = tooltip as IReuseTime;
				if(reuse != null &&
					!reuse.IsReuseTime(EndAfter.None))
				{
					return false;
				}
			}

			// variables
			if(this.condition.Has)
			{
				VariableHandler handler = this.GetUsedVariableHandler(tooltip);
				if(handler == null ||
					!this.condition.CheckVariables(handler))
				{
					return false;
				}
			}
			return true;
		}

		private VariableHandler GetUsedVariableHandler(IContentSimple tooltip)
		{
			if(this.useTooltipVariables)
			{
				return VariableHandler.GetHandler(tooltip);
			}
			else
			{
				return ORK.Game.Variables;
			}
		}
	}
}
