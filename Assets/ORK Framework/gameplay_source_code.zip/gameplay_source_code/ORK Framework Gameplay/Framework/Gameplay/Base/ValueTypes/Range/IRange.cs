﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IRange
	{
		bool IsInfinity
		{
			get;
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		float GetInRangeDistance(Combatant combatant);

		float GetOutOfRangeDistance(Combatant combatant);

		IRange GetInRange(Combatant combatant);

		IRange GetOutOfRange(Combatant combatant);

		Vector3 GetAngledPosition(Combatant combatant, float angle, bool localSpace, HorizontalPlaneType horizontalPlane);


		/*
		============================================================================
		In range functions
		============================================================================
		*/
		bool InRange(Combatant combatant, Combatant target);

		bool InRange(Vector3 position, Combatant combatant);

		bool InRange(Vector3 position, Combatant combatant, float range);

		bool InRange(Vector3 position, Combatant combatant, bool ignoreRadius, float range);

		bool InRange(Vector3 position, Vector3 position2);


		/*
		============================================================================
		Out of range functions
		============================================================================
		*/
		bool OutOfRange(Combatant combatant, Combatant target);

		bool OutOfRange(Vector3 position, Combatant combatant);

		bool OutOfRange(Vector3 position, Combatant combatant, float range);

		bool OutOfRange(Vector3 position, Vector3 position2);


		/*
		============================================================================
		In range status functions
		============================================================================
		*/
		void CheckInRangeStatus(Combatant combatant, Combatant target, bool invert, ref bool inRangeStatus);

		void CheckInRangeStatus(Vector3 position, Combatant combatant, bool invert, ref bool inRangeStatus);

		void CheckInRangeStatus(Vector3 position, Vector3 position2, bool invert, ref bool inRangeStatus);
	}
}
