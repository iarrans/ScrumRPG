﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DifficultyCheck : BaseData
	{
		[ORKEditorHelp("Check Type", "The difficulty (level) is determined by the ID of the difficulty, e.g. ID 0 is less than ID 1, ID 3 is greater than ID 2.\n" +
			"Checks if the game's difficulty is equal, not equal, less or greater than the defined difficulty.\n" +
			"Range inclusive checks if the game's difficulty is between two defined difficulties, including them.\n" +
			"Range exclusive checks if the game's difficulty is between two defined difficulties, excluding them.\n" +
			"Approximately checks if the difficulty is equal to the defined difficulty.", "")]
		public ValueCheckType type = ValueCheckType.IsEqual;

		[ORKEditorHelp("Difficulty", "Select the difficulty to check for.", "")]
		[ORKEditorInfo(ORKDataType.Difficulty)]
		public int difficulty = 0;

		[ORKEditorHelp("Difficulty 2", "Select the difficulty to check for (upper limit).", "")]
		[ORKEditorInfo(ORKDataType.Difficulty)]
		[ORKEditorLayout(new string[] { "type", "type" } ,
			new System.Object[] { ValueCheckType.RangeInclusive, ValueCheckType.RangeExclusive },
			needed=Needed.One, endCheckGroup=true)]
		public int difficulty2 = 0;

		public DifficultyCheck()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("check"))
			{
				ValueCheck.UpgradeOldType(data, "check", ref this.type);
			}
			if(data.Contains<int>("id"))
			{
				data.Get("id", ref this.difficulty);
				data.Get("id2", ref this.difficulty2);
			}
		}

		public bool Check()
		{
			return ValueHelper.CheckValue(ORK.Game.Difficulty, this.difficulty, this.difficulty2, this.type);
		}

		public override string ToString()
		{
			return this.type.ToString() + " " +
				ORK.Difficulties.GetName(this.difficulty) +
				(ValueCheckType.RangeInclusive == this.type || ValueCheckType.RangeExclusive == this.type ?
					" ~ " + ORK.Difficulties.GetName(this.difficulty2) : "");
		}
	}
}
