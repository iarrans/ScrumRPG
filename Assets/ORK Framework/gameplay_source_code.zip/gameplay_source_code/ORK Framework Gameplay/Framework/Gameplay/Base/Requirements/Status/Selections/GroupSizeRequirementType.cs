﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Group Size", "The combatant's group size will be compared to a defined value.", "")]
	public class GroupSizeRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Check Battle Group", "Check the battle group size.\n" +
			"If disabled, the whole group size (i.e. all members) will be checked.", "")]
		public bool battleGroup = true;

		public ValueCheck check = new ValueCheck();

		public GroupSizeRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("groupSize"))
			{
				this.check.UpgradeInt(data, "groupSizeComparison", "groupSize");
			}
			else
			{
				this.check.UpgradeInt(data, "comparison", "size");
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.check.Check(
				this.battleGroup ? combatant.Group.BattleSize : combatant.Group.Size,
				combatant);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.GroupChanged += notify.CombatantGroupChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.GroupChanged -= notify.CombatantGroupChanged;
		}
	}
}
