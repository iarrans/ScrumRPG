﻿
using ORKFramework;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("In Grid Formation", "Checks if a combatant's group currently is in any or a defined grid formation, " +
		"or checks if a combatant is part of a formation.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Grid Formation")]
	public class InGridFormationStep : BaseFormulaCheckStep
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		[ORKEditorHelp("Check Combatant", "Checks if a combatant is part of a formation.", "")]
		[ORKEditorInfo(separator=true)]
		public bool checkCombatant = false;


		// formation
		[ORKEditorHelp("Any Formation", "Checks if the combatant's group is in any grid formation.", "")]
		[ORKEditorLayout("checkCombatant", false)]
		public bool anyFormation = true;

		[ORKEditorHelp("Grid Formation", "Select the grid formation that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridFormation)]
		[ORKEditorLayout("anyFormation", false, endCheckGroup=true, endGroups=2)]
		public int formationID = 0;

		public InGridFormationStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null)
			{
				if(this.checkCombatant)
				{
					if(combatant.Group.InGridFormation &&
						combatant.Group.GridFormation.IsInFormation(combatant))
					{
						return this.next;
					}
				}
				else if(combatant.Group.InGridFormation &&
					(this.anyFormation || combatant.Group.GridFormation.IsFormation(this.formationID)))
				{
					return this.next;
				}
			}

			return this.nextFail;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() + (this.checkCombatant ? ": In Formation" :
				(this.anyFormation ? ": Any" : ": " + ORK.BattleGridFormations.GetName(this.formationID)));
		}
	}

	[ORKEditorHelp("Is Grid Formation Leader", "Checks if a combatant is the leader of a grid formation.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Grid Formation")]
	public class IsGridFormationLeaderStep : BaseFormulaCheckStep
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public IsGridFormationLeaderStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null &&
				combatant.Group.InGridFormation &&
				combatant.Group.GridFormation.Leader == combatant)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText();
		}
	}

	[ORKEditorHelp("In Grid Formation Position", "Checks if a combatant is on the assigned grid formation position cell.\n" +
		"The formation leader is always in formation position.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Grid Formation")]
	public class InGridFormationPositionStep : BaseFormulaCheckStep
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();

		public InGridFormationPositionStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null &&
				combatant.Group.InGridFormation &&
				combatant.Group.GridFormation.IsInPosition(combatant))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText();
		}
	}

	[ORKEditorHelp("Grid Formation Finished", "Checks if all combatants reached their grid formation position.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Grid Formation")]
	public class GridFormationFinishedStep : BaseFormulaCheckStep
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// settings
		[ORKEditorHelp("Only Filled Positions", "Only positions that have a combatant assigned will be checked.\n" +
			"If disabled, an empty position will result in failure.", "")]
		[ORKEditorInfo(separator=true)]
		public bool onlyFilled = true;

		[ORKEditorHelp("Check Rotation", "Checks if the combatant's rotation matches the rotation defined by the position " +
			"(e.g. matching the leader's rotatin).\n" +
			"If disabled, rotations are ignored.", "")]
		public bool checkRotation = false;

		[ORKEditorHelp("Check Grid Distance", "Only positions where the combatant is " +
			"a defined grid distance away from the cell will be checked.\n" +
			"If the combatant is farther away, the position will be ignored.", "")]
		public bool checkGridDistance = false;

		[ORKEditorInfo(separator=true, labelText="Distance")]
		[ORKEditorLayout("checkGridDistance", true, endCheckGroup=true, autoInit=true)]
		public FormulaFloat distance;

		public GridFormationFinishedStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null &&
				combatant.Group.InGridFormation &&
				combatant.Group.GridFormation.PositionsFilled(this.onlyFilled, this.checkRotation,
					(int)(this.checkGridDistance ? this.distance.GetValue(call) : -1)))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText();
		}
	}

	[ORKEditorHelp("Grid Formation Possible", "Checks if a combatant group's formation is possible " +
		"or a defined grid formation is possible at a combatant's cell.\n" +
		"A formation isn't possible if one of the position cells is blocked or invalid (outside the grid)." +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Grid Formation")]
	public class GridFormationPossibleStep : BaseFormulaCheckStep
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// settings
		[ORKEditorHelp("Use Current Formation", "Uses the combatant group's current formation for the check.\n" +
			"The check fails if the combatant's group isn't in formation.\n"+
			"If disabled, a defined grid formation is used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useCurrentFormation = true;

		[ORKEditorHelp("Grid Formation", "Select the grid formation that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridFormation)]
		[ORKEditorLayout("useCurrentFormation", false, endCheckGroup=true)]
		public int formationID = 0;

		public GridFormationPossibleStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);

			if(combatant != null)
			{
				if(this.useCurrentFormation)
				{
					if(combatant.Group.InGridFormation &&
						combatant.Group.GridFormation.IsFormationPossible())
					{
						return this.next;
					}
				}
				else if(ORK.BattleGridFormations.Get(this.formationID).IsFormationPossible(combatant))
				{
					return this.next;
				}
			}

			return this.nextFail;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() + (this.useCurrentFormation ? ": Current" :
				": " + ORK.BattleGridFormations.GetName(this.formationID)); ;
		}
	}
}
