﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Grid Move Range", "The combatant's grid move range will be compared to a defined value.", "")]
	public class GridMoveRangeRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Max Grid Move Range", "Check the combatant's maximum grid move range.\n" +
			"If disabled, the current grid move range will be checked.", "")]
		public bool maxGridMoveRange = false;

		public ValueCheck check = new ValueCheck();

		public GridMoveRangeRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.check.UpgradeFloat(data, "comparison", "value");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.check.Check(
				this.maxGridMoveRange ? combatant.Battle.GridMoveRangeMax : combatant.Battle.GridMoveRange,
				combatant);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Battle.GridMoveRangeChanged += notify.CombatantGridMoveRangeChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Battle.GridMoveRangeChanged -= notify.CombatantGridMoveRangeChanged;
		}
	}
}
