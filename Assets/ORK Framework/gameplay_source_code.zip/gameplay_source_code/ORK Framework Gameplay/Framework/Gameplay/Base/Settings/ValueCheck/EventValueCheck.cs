﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class EventValueCheck : BaseData
	{
		[ORKEditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than the defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		public ValueCheckType type = ValueCheckType.IsEqual;

		[ORKEditorInfo("Check Value", "The value used for the check.\n" +
			"In range inclusive/exclusive checks, this is the lower limit.", "",
			endFoldout=true)]
		public EventFloat value = new EventFloat();

		[ORKEditorInfo("Check Value 2", "The value used for the check (upper limit).", "",
			endFoldout=true)]
		[ORKEditorLayout(new string[] { "type", "type" } ,
			new System.Object[] { ValueCheckType.RangeInclusive, ValueCheckType.RangeExclusive },
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat value2;

		public EventValueCheck()
		{

		}

		public bool Check(int checkValue, BaseEvent baseEvent)
		{
			return ValueHelper.CheckValue(checkValue,
				(int)this.value.GetValue(baseEvent),
				this.value2 != null ? (int)this.value2.GetValue(baseEvent) : 0,
				this.type);
		}

		public bool Check(float checkValue, BaseEvent baseEvent)
		{
			return ValueHelper.CheckValue(checkValue,
				this.value.GetValue(baseEvent),
				this.value2 != null ? this.value2.GetValue(baseEvent) : 0.0f,
				this.type);
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return this.type.ToString() + " " +
				this.value.GetInfoText() +
				(ValueCheckType.RangeInclusive == this.type || ValueCheckType.RangeExclusive == this.type ?
					" ~ " + this.value2.GetInfoText() : "");
		}


		/*
		============================================================================
		Upgrade functions
		============================================================================
		*/
		public void UpgradeEventFloat(DataObject data, string typeName, string valueName)
		{
			if(data.Contains<int>(typeName))
			{
				this.value.SetData(data.GetFile(valueName));

				ValueCheck.UpgradeOldType(data, typeName, ref this.type);
			}
		}

		public void UpgradeEventFloat(DataObject data, string typeName, string valueName, string value2Name)
		{
			if(data.Contains<int>(typeName))
			{
				ValueCheck.UpgradeOldTypeVariable(data, typeName, ref this.type);

				this.value.SetData(data.GetFile(valueName));
				if(ValueCheckType.RangeInclusive == this.type ||
					ValueCheckType.RangeExclusive == this.type)
				{
					this.value2 = new EventFloat();
					this.value2.SetData(data.GetFile(value2Name));
				}

			}
		}

		public void UpgradeEventInteger(DataObject data, string typeName, string valueName)
		{
			if(data.Contains<int>(typeName))
			{
				this.value.UpgradeFromEventInteger(data.GetFile(valueName));

				ValueCheck.UpgradeOldType(data, typeName, ref this.type);
			}
		}

		public void UpgradeEventInteger(DataObject data, string typeName, string valueName, string value2Name)
		{
			if(data.Contains<int>(typeName))
			{
				ValueCheck.UpgradeOldTypeVariable(data, typeName, ref this.type);

				this.value.UpgradeFromEventInteger(data.GetFile(valueName));
				if(ValueCheckType.RangeInclusive == this.type ||
					ValueCheckType.RangeExclusive == this.type)
				{
					this.value2 = new EventFloat();
					this.value2.UpgradeFromEventInteger(data.GetFile(value2Name));
				}

			}
		}
	}
}
