
using UnityEngine;
using System.Collections.Generic;
using System.Text;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Distance", "The distance between user and target is used.", "")]
	[ORKNodeInfo("Position")]
	public class DistanceStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;


		// distance
		[ORKEditorHelp("Ignore Height Distance", "Height differences to the target are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		[ORKEditorInfo(separator=true)]
		public bool ignoreHeightDistance = false;

		[ORKEditorHelp("Ignore Radius", "The box radius settings of the combatants will be ignored when calculating the distance.", "")]
		public bool ignComRad = false;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		public DistanceStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("ignY"))
			{
				data.Get("ignY", ref this.ignoreHeightDistance);
			}
		}

		public override int Calculate(FormulaCall call)
		{
			ValueHelper.UseOperator(ref call.result,
				call.user.Object.DistanceTo(call.target, this.ignoreHeightDistance,
					this.ignComRad, this.horizontalPlane),
				this.formulaOperator);
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString();
		}
	}

	[ORKEditorHelp("Check Distance", "The distance between user and target is checked with " +
		"the current value of the formula or a defined value.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckDistanceStep : BaseFormulaCheckStep
	{
		// distance
		[ORKEditorHelp("Ignore Height Distance", "Height differences to the target are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		public bool ignoreHeightDistance = false;

		[ORKEditorHelp("Ignore Radius", "The box radius settings of the combatants will be ignored when calculating the distance.", "")]
		public bool ignComRad = false;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();


		// check
		[ORKEditorInfo(separator=true)]
		public FormulaValueCheck check = new FormulaValueCheck();

		public CheckDistanceStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("ignY"))
			{
				data.Get("ignY", ref this.ignoreHeightDistance);
			}
			this.check.UpgradeFormulaFloat(data, "check", "value", "value2");
			if(data.Contains<bool>("useCurrent"))
			{
				bool tmp = false;
				data.Get("useCurrent", ref tmp);
				if(tmp)
				{
					this.check.value.type = FormulaFloatType.CurrentValue;
				}
				if(ValueCheckType.RangeInclusive == this.check.type ||
					ValueCheckType.RangeExclusive == this.check.type)
				{
					tmp = false;
					data.Get("useCurrent2", ref tmp);
					if(tmp)
					{
						this.check.value2.type = FormulaFloatType.CurrentValue;
					}
				}
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(this.check.Check(
				call.user.Object.DistanceTo(call.target, this.ignoreHeightDistance,
					this.ignComRad, this.horizontalPlane),
				call))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.GetInfoText();
		}
	}

	[ORKEditorHelp("Grid Distance", "The grid distance between user and target is used.", "")]
	[ORKNodeInfo("Position")]
	public class GridDistanceStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;


		// distance
		[ORKEditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		[ORKEditorInfo(separator=true)]
		public bool blockDiagonalDistance1 = false;

		[ORKEditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		public bool ignoreSizeCells = false;

		public GridDistanceStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			ValueHelper.UseOperator(ref call.result,
				this.ignoreSizeCells ?
					call.user.Grid.Cell.CubeCoord.Distance(
						call.target.Grid.Cell.CubeCoord, this.blockDiagonalDistance1) :
					call.user.Grid.GetLowestDistance(
						call.target, this.blockDiagonalDistance1),
				this.formulaOperator);
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString();
		}
	}

	[ORKEditorHelp("Check Grid Distance", "The distance on a battle grid between user and target is checked with a defined value.\n" +
		"Neighbouring cells have a distance of 1, a cell between is distance of 2, etc.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckGridDistanceStep : BaseFormulaCheckStep
	{
		[ORKEditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		public bool blockDiagonalDistance1 = false;

		[ORKEditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		public bool ignoreSizeCells = false;


		// check
		[ORKEditorInfo(separator=true)]
		public FormulaValueCheck check = new FormulaValueCheck();

		public CheckGridDistanceStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.check.UpgradeFormulaFloat(data, "check", "value", "value2");
			if(data.Contains<bool>("useCurrent"))
			{
				bool tmp = false;
				data.Get("useCurrent", ref tmp);
				if(tmp)
				{
					this.check.value.type = FormulaFloatType.CurrentValue;
				}
				if(ValueCheckType.RangeInclusive == this.check.type ||
					ValueCheckType.RangeExclusive == this.check.type)
				{
					tmp = false;
					data.Get("useCurrent2", ref tmp);
					if(tmp)
					{
						this.check.value2.type = FormulaFloatType.CurrentValue;
					}
				}
			}
		}

		public override int Calculate(FormulaCall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Grid.Cell != null &&
				call.target.Grid.Cell != null &&
				this.ignoreSizeCells ?
					this.check.Check(
						call.user.Grid.Cell.CubeCoord.Distance(call.target.Grid.Cell.CubeCoord, this.blockDiagonalDistance1),
						call) :
					call.user.Grid.CheckDistance(call.target, this.blockDiagonalDistance1,
						(int)this.check.value.GetValue(call),
						(int)(this.check.value2 != null ? this.check.value2.GetValue(call) : 0),
						this.check.type, null))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.GetInfoText();
		}
	}

	[ORKEditorHelp("Is Grid Cell Diagonal", "Checks if user and target are diagonal to each other ('Square' grids only).\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class IsGridCellDiagonalStep : BaseFormulaCheckStep
	{
		[ORKEditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		public bool ignoreSizeCells = false;

		public IsGridCellDiagonalStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(ORK.Battle.Grid != null &&
				ORK.Battle.SystemSettings.gridSettings.IsSquare &&
				call.user.Grid.Cell != null &&
				call.target.Grid.Cell != null &&
				this.ignoreSizeCells ?
					CubeCoord.IsSquareDiagonal(call.user.Grid.Cell.CubeCoord, call.target.Grid.Cell.CubeCoord) :
					call.user.Grid.CheckDiagonal(call.target))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}
	}

	[ORKEditorHelp("Angle", "The angle between user and target (-180 - 180) is used.", "")]
	[ORKNodeInfo("Position")]
	public class AngleStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;


		// angle
		[ORKEditorHelp("Use Direction", "The angle between the forward directions of user and target will be calculated.\n" +
			"E.g. the result will be 0 if both are looking into the same direction, -180/180 if they look into opposite directions.\n" +
			"If disabled, the angle between the positions will be calculated.\n" +
			"E.g. the result will be 0 if the user looks directly at the target, -180/180 if he looks away from the target.", "")]
		[ORKEditorInfo(separator=true)]
		public bool direction = false;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		[ORKEditorHelp("From Target", "The angle is calculated from target to user.\n" +
			"If disabled, the angle is calculated from user to target.", "")]
		[ORKEditorLayout("direction", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool fromTarget = false;

		public AngleStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			float value = 0;
			if(call.user.GameObject != null && call.target.GameObject != null)
			{
				if(this.direction)
				{
					value = VectorHelper.HorizontalDirectionAngle(call.user.GameObject.transform,
						call.target.GameObject.transform, this.horizontalPlane);
				}
				else if(this.fromTarget)
				{
					value = VectorHelper.HorizontalAngle(call.target.GameObject.transform,
						call.user.GameObject.transform.position, this.horizontalPlane);
				}
				else
				{
					value = VectorHelper.HorizontalAngle(call.user.GameObject.transform,
						call.target.GameObject.transform.position, this.horizontalPlane);
				}
			}
			ValueHelper.UseOperator(ref call.result, value, this.formulaOperator);
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + (this.direction ? " Direction" : "") + (this.fromTarget ? " from Target" : "");
		}
	}

	[ORKEditorHelp("Check Angle", "The angle between user and target is checked with " +
		"the current value of the formula or a defined value.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckAngleStep : BaseFormulaCheckStep
	{
		// angle
		[ORKEditorHelp("Use Direction", "The angle between the forward directions of user and target will be calculated.\n" +
			"E.g. the result will be 0 if both are looking into the same direction, -180/180 if they look into opposite directions.\n" +
			"If disabled, the angle between the positions will be calculated.\n" +
			"E.g. the result will be 0 if the user looks directly at the target, -180/180 if he looks away from the target.", "")]
		public bool direction = false;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		[ORKEditorHelp("From Target", "The angle is calculated from target to user.\n" +
			"If disabled, the angle is calculated from user to target.", "")]
		[ORKEditorLayout("direction", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool fromTarget = false;


		// check
		[ORKEditorInfo(separator=true, warning="Angle has to be between -180 and 180")]
		public FormulaValueCheck check = new FormulaValueCheck();

		public CheckAngleStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.check.UpgradeFormulaFloat(data, "check", "value", "value2");
			if(data.Contains<bool>("useCurrent"))
			{
				bool tmp = false;
				data.Get("useCurrent", ref tmp);
				if(tmp)
				{
					this.check.value.type = FormulaFloatType.CurrentValue;
				}
				if(ValueCheckType.RangeInclusive == this.check.type ||
					ValueCheckType.RangeExclusive == this.check.type)
				{
					tmp = false;
					data.Get("useCurrent2", ref tmp);
					if(tmp)
					{
						this.check.value2.type = FormulaFloatType.CurrentValue;
					}
				}
			}
		}

		public override int Calculate(FormulaCall call)
		{
			float tmpVal = 0;
			if(call.user.GameObject != null && call.target.GameObject != null)
			{
				if(this.direction)
				{
					tmpVal = VectorHelper.HorizontalDirectionAngle(call.user.GameObject.transform,
						call.target.GameObject.transform, this.horizontalPlane);
				}
				else if(this.fromTarget)
				{
					tmpVal = VectorHelper.HorizontalAngle(call.target.GameObject.transform,
						call.user.GameObject.transform.position, this.horizontalPlane);
				}
				else
				{
					tmpVal = VectorHelper.HorizontalAngle(call.user.GameObject.transform,
						call.target.GameObject.transform.position, this.horizontalPlane);
				}
			}
			if(this.check.Check(tmpVal, call))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.GetInfoText() +
				(this.direction ? " Direction" : "") +
				(this.fromTarget ? " from Target" : "");
		}
	}

	[ORKEditorHelp("Check Orientation", "Checks the orientation from user to target (e.g. if the target is in front of the user).\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckOrientationStep : BaseFormulaCheckStep
	{
		[ORKEditorHelp("Orientation", "Select the orientation that'll be checked for:\n" +
			"- None: The orientation is ignored.\n" +
			"- Front: The target has to be in front of the user.\n" +
			"- Back: The target has to be in the back of the user.\n" +
			"- Left: The target has to be left of the user.\n" +
			"- Right: The target has to be right of the user.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true)]
		public Orientation orientation = Orientation.Front;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		[ORKEditorHelp("From Target", "The orientation is checked from target to user.\n" +
			"If disabled, the orientation is checked from user to target.", "")]
		public bool fromTarget = false;

		public CheckOrientationStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Orientation check = Orientation.None;
			if(call.user.GameObject != null && call.target.GameObject != null)
			{
				if(this.fromTarget)
				{
					check = VectorHelper.GetOrientation(call.target.GameObject.transform,
						call.user.GameObject.transform, this.horizontalPlane);
				}
				else
				{
					check = VectorHelper.GetOrientation(call.user.GameObject.transform,
						call.target.GameObject.transform, this.horizontalPlane);
				}
			}
			if(Orientation.None == this.orientation ||
				this.orientation == check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.orientation + (this.fromTarget ? ", from Target" : "");
		}
	}

	[ORKEditorHelp("Check Grid Cell Type", "Checks if a combatant is currently on a cell of a defined grid cell type.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckGridCellTypeStep : BaseFormulaCheckStep
	{
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();


		// grid cell type
		[ORKEditorHelp("Grid Cell Type", "Select the grid cell type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridCellType, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Grid Cell Type", "Adds a grid cell type that will be used.", "",
			"Remove", "Removes the grid cell type.", "", isHorizontal=true, noRemoveCount=1)]
		public int[] gridCellTypeID = new int[1];

		public CheckGridCellTypeStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			Combatant combatant = this.origin.GetCombatant(call);
			if(ORK.Battle.Grid != null &&
				combatant != null &&
				BattleGridHelper.IsCellType(combatant.Grid.Cell, this.gridCellTypeID))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			StringBuilder builder = new StringBuilder();
			builder.Append(this.origin.GetInfoText()).Append(": ");

			for(int i = 0; i < this.gridCellTypeID.Length; i++)
			{
				if(i > 0)
				{
					builder.Append(", ");
				}
				builder.Append(ORK.BattleGridCellTypes.GetName(this.gridCellTypeID[i]));
			}
			return builder.ToString();
		}
	}

	[ORKEditorHelp("Check Height Differences", "Checks if the target is above or below the user.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckHeightDifferencesStep : BaseFormulaCheckStep
	{
		public HeightDifferenceCheck heightCheck = new HeightDifferenceCheck();

		public CheckHeightDifferencesStep()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.heightCheck.Check(call.user, call.target))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.heightCheck.GetInfoText();
		}
	}
}
