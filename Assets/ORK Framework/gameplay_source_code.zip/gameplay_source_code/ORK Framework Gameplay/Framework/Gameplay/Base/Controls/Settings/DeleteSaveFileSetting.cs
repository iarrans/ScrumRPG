﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DeleteSaveFileSetting : BaseData
	{
		// delete key
		[ORKEditorHelp("Delete Key", "Select the input key used to delete the currently selected save file.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int deleteKey = 0;

		[ORKEditorHelp("Delete Audio", "Select which audio clip of the GUI box will be played when deleting a safe file.", "")]
		public GUIBoxAudioType audioType = GUIBoxAudioType.Accept;

		[ORKEditorHelp("Delete Fail Audio", "Select which audio clip of the GUI box will be played when deleting fails " +
			"(e.g. no save file selected).", "")]
		public GUIBoxAudioType failAudioType = GUIBoxAudioType.Fail;


		// delete question
		[ORKEditorHelp("Use Question Dialogue", "Use a question dialogue to allow the player to accept deleting the save file.", "")]
		[ORKEditorInfo("Delete File Question", "Optionally show a dialogue asking the player if the file should be deleted.\n" +
			"Use the '%' text code to show the file number.", "")]
		public bool useQuestion = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useQuestion", true, endCheckGroup=true)]
		public QuestionChoice question = new QuestionChoice();


		// in-game
		private Notify callback;

		private int lastFileIndex = -1;

		public DeleteSaveFileSetting()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("deleteKeyID"))
			{
				data.Get("deleteKeyID", ref this.deleteKey);
			}
		}

		public bool UseKey(GUIBox origin, int fileIndex, Notify callback)
		{
			if(ORK.InputKeys.Get(this.deleteKey).GetButton() &&
				(!this.useQuestion || !this.question.IsOpen))
			{
				if(ORK.SaveGame.FileExists(fileIndex))
				{
					if(origin != null)
					{
						origin.Audio.Play(this.audioType);
					}
					if(this.useQuestion)
					{
						this.callback = callback;
						this.lastFileIndex = fileIndex;
						this.question.Show(ORK.SaveGame.GetFileNumberText(this.lastFileIndex), this.QuestionClosed);
					}
					else
					{
						ORK.SaveGame.DeleteFile(fileIndex);
						if(callback != null)
						{
							callback();
						}
						return true;
					}
				}
				else if(origin != null)
				{
					origin.Audio.Play(this.failAudioType);
				}
			}
			return false;
		}

		public void QuestionClosed(bool accepted)
		{
			if(accepted)
			{
				ORK.SaveGame.DeleteFile(this.lastFileIndex);
				if(this.callback != null)
				{
					this.callback();
				}
			}
		}
	}
}
