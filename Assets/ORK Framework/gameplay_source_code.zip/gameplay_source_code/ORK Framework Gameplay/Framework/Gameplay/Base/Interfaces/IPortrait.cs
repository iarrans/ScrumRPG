﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IPortrait
	{
		/*
		============================================================================
		Properties
		============================================================================
		*/
		Texture Image
		{
			get;
		}

		bool UseAlphaMask
		{
			get;
		}

		bool OwnPortraitPosition
		{
			get;
		}

		PortraitPosition PortraitPosition
		{
			get;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		Material GetMaterial();

		void Init();

		void Clear();
	}
}
