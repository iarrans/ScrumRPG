
using System;

namespace ORKFramework
{
	public class DifficultyFaction : BaseData
	{
		[ORKEditorHelp("Faction", "Select the faction that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;
		
		
		// status values
		[ORKEditorHelp("Status Multiplier", 
			"The initial status values of all members of this faction will be multiplied by this numbers.\n"+
			"Only 'Normal' and 'Experience' type status values can be set.", "")]
		[ORKEditorInfo(separator=true, labelText="Status Multipliers")]
		[ORKEditorArray(ORKDataType.StatusValue, "type", StatusValueType.Consumable, negateLimit=true, 
			defaultAddValue=1)]
		public float[] statusMultiplier = ArrayHelper.CreateArray<float>(ORK.StatusValues.Count, 1);
		
		
		// attack attributes
		[ORKEditorHelp("Attack Attribute Multiplier", 
			"The initial attack attributes of all members of this faction will be multiplied by this numbers.", "")]
		[ORKEditorInfo(separator=true, labelText="Attack Attributes Multipliers")]
		[ORKEditorArray(ORKDataType.AttackAttributes, defaultAddValue=1)]
		public float[] atkAttrMultiplier = ArrayHelper.CreateArray<float>(ORK.AttackAttributes.Count, 1);
		
		
		// defence attributes
		[ORKEditorHelp("Defence Attribute Multiplier", 
			"The initial defence attributes of all members of this faction will be multiplied by this numbers.", "")]
		[ORKEditorInfo(separator=true, labelText="Defence Attributes Multipliers")]
		[ORKEditorArray(ORKDataType.DefenceAttributes, defaultAddValue=1)]
		public float[] defAttrMultiplier = ArrayHelper.CreateArray<float>(ORK.DefenceAttributes.Count, 1);
		
		public DifficultyFaction()
		{
			
		}
	}
}
