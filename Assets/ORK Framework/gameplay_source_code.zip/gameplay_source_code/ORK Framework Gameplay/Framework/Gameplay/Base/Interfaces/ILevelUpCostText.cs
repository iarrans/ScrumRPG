﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface ILevelUpCostText
	{
		string GetLevelUpCostString(Combatant combatant);
	}
}
