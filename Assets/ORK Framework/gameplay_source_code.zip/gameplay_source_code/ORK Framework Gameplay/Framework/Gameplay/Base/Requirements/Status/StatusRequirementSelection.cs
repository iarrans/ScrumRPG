﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	public class StatusRequirementSelection : BaseData
	{
		[ORKEditorHelp("Status Needed", "Select which type of status will be checked:", "")]
		[ORKEditorInfo(settingBaseType=typeof(BaseStatusRequirementType), settingAutoSetup="settings")]
		public string type = typeof(StatusValueRequirementType).ToString();

		public BaseStatusRequirementType settings = new StatusValueRequirementType();

		public StatusRequirementSelection()
		{

		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(this.settings == null ||
				!this.settings.IsType(this.type))
			{
				DataObject data = this.settings != null ?
					this.settings.GetData() : null;
				object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
					this.type, typeof(BaseStatusRequirementType));
				if(tmpSettings is BaseStatusRequirementType)
				{
					this.settings = (BaseStatusRequirementType)tmpSettings;
					this.settings.SetData(data);
				}
				else
				{
					this.settings = new StatusValueRequirementType();
					this.settings.SetData(data);
					this.type = this.settings.GetType().ToString();
				}
			}
		}

		public override void SetData(DataObject data)
		{
			//base.SetData(data);

			if(data.Contains<int>("statusNeeded"))
			{
				int tmp = 0;
				data.Get("statusNeeded", ref tmp);

				if(tmp == 0)
				{
					this.settings = new StatusValueRequirementType();
				}
				else if(tmp == 1)
				{
					this.settings = new StatusEffectRequirementType();
				}
				else if(tmp == 2)
				{
					this.settings = new AttackAttributeRequirementType();
				}
				else if(tmp == 3)
				{
					this.settings = new DefenceAttributeRequirementType();
				}
				else if(tmp == 4)
				{
					this.settings = new LevelRequirementType();
				}
				else if(tmp == 5)
				{
					this.settings = new AbilityRequirementType();
				}
				else if(tmp == 6)
				{
					this.settings = new ClassRequirementType();
				}
				else if(tmp == 7)
				{
					this.settings = new DeathRequirementType();
				}
				else if(tmp == 8)
				{
					this.settings = new WeaponRequirementType();
				}
				else if(tmp == 9)
				{
					this.settings = new ArmorRequirementType();
				}
				else if(tmp == 10)
				{
					this.settings = new CombatantRequirementType();
				}
				else if(tmp == 11)
				{
					this.settings = new GroupLeaderRequirementType();
				}
				else if(tmp == 12)
				{
					this.settings = new GroupSizeRequirementType();
				}
				else if(tmp == 13)
				{
					this.settings = new InventoryRequirementType();
				}
				else if(tmp == 14)
				{
					this.settings = new StatusEffectTypeRequirementType();
				}
				else if(tmp == 15)
				{
					this.settings = new WeaponItemTypeRequirementType();
				}
				else if(tmp == 16)
				{
					this.settings = new ArmorItemTypeRequirementType();
				}
				else if(tmp == 17)
				{
					this.settings = new CombatantTypeRequirementType();
				}
				else if(tmp == 18)
				{
					this.settings = new InBattleRequirementType();
				}
				else if(tmp == 19)
				{
					this.settings = new InActionRequirementType();
				}
				else if(tmp == 20)
				{
					this.settings = new IsCastingRequirementType();
				}
				else if(tmp == 21)
				{
					this.settings = new IsChoosingRequirementType();
				}
				else if(tmp == 22)
				{
					this.settings = new TurnStateRequirementType();
				}
				else if(tmp == 23)
				{
					this.settings = new GridMoveRangeRequirementType();
				}
				else if(tmp == 24)
				{
					this.settings = new ResearchTreeRequirementType();
				}
				else if(tmp == 25)
				{
					this.settings = new ResearchItemRequirementType();
				}
				else if(tmp == 26)
				{
					this.settings = new AITypeRequirementType();
				}
				else if(tmp == 27)
				{
					this.settings = new AIBehaviourRequirementType();
				}
				else if(tmp == 28)
				{
					this.settings = new AIRulesetRequirementType();
				}
				else if(tmp == 29)
				{
					this.settings = new AIBehaviourSlotCountRequirementType();
				}
				else if(tmp == 30)
				{
					this.settings = new AIRulesetSlotCountRequirementType();
				}
				else if(tmp == 31)
				{
					this.settings = new ActionBarRequirementType();
				}
				else if(tmp == 32)
				{
					this.settings = new IsResearchingRequirementType();
				}

				this.settings.SetData(data);
				this.type = this.settings.GetType().ToString();
			}
			else
			{
				data.Get("type", ref this.type);

				if(this.settings == null ||
					!this.settings.IsType(this.type))
				{
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
					this.type, typeof(BaseStatusRequirementType));
					if(tmpSettings is BaseStatusRequirementType)
					{
						this.settings = (BaseStatusRequirementType)tmpSettings;
					}
					else
					{
						this.settings = new StatusValueRequirementType();
						this.type = this.settings.GetType().ToString();
					}
				}
				this.settings.SetData(data.GetFile("settings"));
			}
		}
	}
}
