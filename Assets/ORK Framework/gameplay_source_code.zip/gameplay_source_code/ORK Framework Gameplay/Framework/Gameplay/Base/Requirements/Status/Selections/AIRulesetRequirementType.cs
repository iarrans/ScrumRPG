﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("AI Ruleset", "A defined AI ruleset must or mustn't be equipped on an AI ruleset slot.", "")]
	public class AIRulesetRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("AI Ruleset", "Select the AI ruleset that will be used.", "")]
		[ORKEditorInfo(ORKDataType.AIRuleset)]
		public int rulesetID = 0;

		[ORKEditorHelp("Is Equipped", "The AI ruleset must be equipped in one of the combatant's AI slots.\n" +
			"If disabled, the AI ruleset mustn't be equipped.", "")]
		public bool isEquipped = true;

		public AIRulesetRequirementType()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("selectionID"))
			{
				data.Get("selectionID", ref this.rulesetID);
				data.Get("aiEquipped", ref this.isEquipped);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.AI.IsAIRulesetEquipped(this.rulesetID) == this.isEquipped;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.AI.Changed += notify.CombatantAIChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.AI.Changed -= notify.CombatantAIChanged;
		}
	}
}
