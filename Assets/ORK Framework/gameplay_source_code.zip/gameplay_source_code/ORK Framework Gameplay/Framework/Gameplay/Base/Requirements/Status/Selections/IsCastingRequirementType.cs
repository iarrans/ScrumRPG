﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Requirements
{
	[ORKEditorSettingInfo("Is Casting", "The combatant must or mustn't be casting an action.", "")]
	public class IsCastingRequirementType : BaseStatusRequirementType
	{
		[ORKEditorHelp("Is Casting", "The combatant must be casting an action.\n" +
			"If disabled, the combatant mustn't be casting an action.", "")]
		public bool isCasting = true;

		public IsCastingRequirementType()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.Actions.IsCasting == this.isCasting;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Actions.CastingStateChanged += notify.CombatantCastingStateChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Actions.CastingStateChanged -= notify.CombatantCastingStateChanged;
		}
	}
}
